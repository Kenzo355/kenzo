<?php
// local_api.php
require_once('vendor/autoload.php');
require_once(ABSPATH . 'wp-load.php'); // لاستخدام وظائف ووردبريس

use GuzzleHttp\Client;
use Symfony\Component\DomCrawler\Crawler;

header('Content-Type: application/json');

// التحقق من وجود معلمة slug
if (!isset($_GET['slug']) || empty($_GET['slug'])) {
    echo json_encode(['error' => 'Missing slug parameter']);
    exit;
}

$slug = urldecode($_GET['slug']);
$domain = parse_url($slug, PHP_URL_HOST);

// قائمة النطاقات المسموحة
$allowed_domains = [
    'xsanime.com',
    'tuktukcinma.cam',
    'arabseed.sbs',
    'arlionz.vip',
    // أضف بقية النطاقات هنا
];

if (!in_array($domain, $allowed_domains)) {
    echo json_encode(['error' => 'Domain not allowed']);
    exit;
}

// التخزين المؤقت لمدة ساعة
$cache_key = 'api_cache_' . md5($slug);
if ($cached_data = get_transient($cache_key)) {
    echo json_encode($cached_data);
    exit;
}

$client = new Client([
    'timeout' => 15,
    'headers' => [
        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    ]
]);

try {
    $response = $client->get($slug);
    $html = $response->getBody()->getContents();
    
    $crawler = new Crawler($html);
    
    // استخراج البيانات حسب النطاق
    $data = [];
    switch ($domain) {
        case 'xsanime.com':
            $data = [
                'title' => $crawler->filter('h1.entry-title')->text(),
                'story' => $crawler->filter('div.post-content')->text(),
                'downloads' => $crawler->filter('a.download-link')->each(function ($node) {
                    return [
                        'url' => $node->attr('href'),
                        'quality' => $node->filter('.quality-tag')->text()
                    ];
                }),
                'poster' => $crawler->filter('div.poster img')->attr('src')
            ];
            break;
            
        case 'tuktukcinma.cam':
            $data = [
                'title' => $crawler->filter('h1.movie-title')->text(),
                'downloads' => $crawler->filter('a.dl-link')->each(function ($node) {
                    return [
                        'server' => $node->attr('data-server'),
                        'url' => $node->attr('href')
                    ];
                }),
                'story' => $crawler->filter('div.movie-desc')->text()
            ];
            break;
            
        // أضف حالات أخرى للمواقع الأخرى
    }

    // معالجة الصور
    if (isset($data['poster'])) {
        $image_url = $data['poster'];
        $upload_dir = wp_upload_dir();
        $image_name = sanitize_file_name(basename($image_url));
        $image_path = $upload_dir['path'] . '/' . $image_name;
        
        try {
            $image_response = $client->get($image_url);
            file_put_contents($image_path, $image_response->getBody());
            $data['local_poster'] = $upload_dir['url'] . '/' . $image_name;
        } catch (Exception $e) {
            $data['image_error'] = $e->getMessage();
        }
    }

    set_transient($cache_key, $data, HOUR_IN_SECONDS);
    echo json_encode($data);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Failed to fetch data',
        'details' => $e->getMessage()
    ]);
}