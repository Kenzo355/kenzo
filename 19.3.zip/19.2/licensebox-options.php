<?php if(!defined('ABSPATH')){ exit; }

function SetDataScrapePageASLC()
{
	add_menu_page( "EasyScrap V 1.9.2", "EasyScrap V 1.9.2", 'edit_posts', 'KENZODataScraper', 'KENZODataScraper');
}
add_action( 'admin_menu', 'SetDataScrapePageASLC' );

function SetDataScrapePageASLCXS()
{
	add_menu_page( "EasyScrap XSAnime V 1.9.2", "EasyScrap XSAnime V 1.9.2", 'edit_posts', 'KENZODataScraperXS', 'KENZODataScraperXS');
}
add_action( 'admin_menu', 'SetDataScrapePageASLCXS' );

function KENZODataScraper(){ ?>
	<div class="wrap">
		<h1>EasyScrap V 1.9.2 Scraping Tool- Settings</h1>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$("#StartGenrate").click(function(event) {
					event.preventDefault();
					$.ajax({
						url: '<?=plugin_dir_url( __FILE__ ) ?>Fetch.php',
						type: 'POST',
						data: {valueText: $("textarea[name=urls]").val()},
					})
					.done(function() {
						console.log("Data Scraped successfully By EasyScrap Scraping Tool");
					})
				});
			});
		</script>
		<div style="display: table;width: 600px;margin: 30px auto;" class="all">
			<textarea placeholder="Put ArabSeed - XSAnime - Arblionz - TukTukCinema - URLs Here Every URL In A Line V 1.9.2" dir="ltr" name="urls"></textarea>
			<div class="container">
				<button id="btn">
					<p id="btnText">Submit</p>
					<div class="check-box">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
							<path fill="transparent" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
						</svg>
					</div>
				</button>
			</div>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$("#btn").click(function(event) {
						event.preventDefault();
						$.ajax({
							url: '<?=plugin_dir_url( __FILE__ ) ?>Fetch.php',
							type: 'POST',
							data: {valueText: $("textarea[name=urls]").val()},
						})
						.done(function() {
							console.log("Data Scraped successfully By EasyScrap Scraping Tool");
						})
					});
				});
				const btn = document.querySelector("#btn");
				const btnText = document.querySelector("#btnText");

				btn.onclick = () => {
					btnText.innerHTML = "Thanks";
					btn.classList.add("active");
				};
			</script>
		</div>

		<h1>SupporteD Sites By [   MovizOne   ]</h1>
		<div id="multi" class="multi-tombutton">
			<button onclick='window.location = "https://m.arabseed.sbs/main/"'>ArabSeed</button>
			<button onclick='window.location = "https://w.cima4up.link"'>Cima4UP</button>
			<button onclick='window.location = "https://w.arlionz.vip/"'>ArabLionz</button>
			<button onclick='window.location = "https://e.lodynet.ink/"'>Lody Net</button>
			<button onclick='window.location = "https://mycima.fun/"'>MyCima</button>
			<button onclick='window.location = "https://w.tuktukcinema.net/"'>TukTukCinema</button>
			<button onclick='window.location = "https://MovizOne/contact"'>next update +5 new sites</button>
		</div>

		<style type="text/css">
			/* احتفظ بأنماط CSS كما هي */
			body{text-align:center}*{text-align:center}wrap{text-align:center}textarea{width:100%;height:150px;text-align:center;padding:12px 20px;box-sizing:border-box;border:2px solid #ff0003;border-radius:4px;background-color:#ec13135e;font-size:16px;resize:none}input#StartGenrate{display:table;margin:13px auto;width:150px;text-align:center;line-height:40px;height:40px;background:#0073aa;color:#fff;border:0;cursor:pointer;border-radius:10px}@font-face{font-family:Cyber;src:url(https://assets.codepen.io/605876/Blender-Pro-Bold.otf);font-display:swap}*{box-sizing:border-box}body{display:flex;align-items:center;flex-direction:column;justify-content:center;min-height:100vh;font-family:Cyber,sans-serif}body .cybr-btn+.cybr-btn{margin-top:2rem}.cybr-btn{--primary:hsl(var(--primary-hue), 85%, calc(var(--primary-lightness, 50) * 1%));--shadow-primary:hsl(var(--shadow-primary-hue), 90%, 50%);--primary-hue:0;--primary-lightness:50;--color:hsl(0, 0%, 100%);--font-size:26px;--shadow-primary-hue:180;--label-size:9px;--shadow-secondary-hue:60;--shadow-secondary:hsl(var(--shadow-secondary-hue), 90%, 60%);--clip:polygon(0 0, 100% 0, 100% 100%, 95% 100%, 95% 90%, 85% 90%, 85% 100%, 8% 100%, 0 70%);--border:4px;--shimmy-distance:5;--clip-one:polygon(0 2%, 100% 2%, 100% 95%, 95% 95%, 95% 90%, 85% 90%, 85% 95%, 8% 95%, 0 70%);--clip-two:polygon(0 78%, 100% 78%, 100% 100%, 95% 100%, 95% 90%, 85% 90%, 85% 100%, 8% 100%, 0 78%);--clip-three:polygon(0 44%, 100% 44%, 100% 54%, 95% 54%, 95% 54%, 85% 54%, 85% 54%, 8% 54%, 0 54%);--clip-four:polygon(0 0, 100% 0, 100% 0, 95% 0, 95% 0, 85% 0, 85% 0, 8% 0, 0 0);--clip-five:polygon(0 0, 100% 0, 100% 0, 95% 0, 95% 0, 85% 0, 85% 0, 8% 0, 0 0);--clip-six:polygon(0 40%, 100% 40%, 100% 85%, 95% 85%, 95% 85%, 85% 85%, 85% 85%, 8% 85%, 0 70%);--clip-seven:polygon(0 63%, 100% 63%, 100% 80%, 95% 80%, 95% 80%, 85% 80%, 85% 80%, 8% 80%, 0 70%);font-family:Cyber,sans-serif;color:var(--color);cursor:pointer;background:0 0;text-transform:uppercase;font-size:var(--font-size);outline:transparent;letter-spacing:2px;position:relative;font-weight:700;border:0;min-width:300px;height:75px;line-height:75px;transition:background .2s}.cybr-btn:hover{--primary:hsl(var(--primary-hue), 85%, calc(var(--primary-lightness, 50) * 0.8%))}.cybr-btn:active{--primary:hsl(var(--primary-hue), 85%, calc(var(--primary-lightness, 50) * 0.6%))}.cybr-btn:after,.cybr-btn:before{content:'';position:absolute;top:0;left:0;right:0;bottom:0;clip-path:var(--clip);z-index:-1}.cybr-btn:before{background:var(--shadow-primary);transform:translate(var(--border),0)}.cybr-btn:after{background:var(--primary)}.cybr-btn__tag{position:absolute;padding:1px 4px;letter-spacing:1px;line-height:1;bottom:-5%;right:5%;font-weight:400;color:#000;font-size:var(--label-size)}.cybr-btn__glitch{position:absolute;top:calc(var(--border) * -1);left:calc(var(--border) * -1);right:calc(var(--border) * -1);bottom:calc(var(--border) * -1);background:var(--shadow-primary);text-shadow:2px 2px var(--shadow-primary),-2px -2px var(--shadow-secondary);clip-path:var(--clip);animation:glitch 2s infinite;display:none}.cybr-btn:hover .cybr-btn__glitch{display:block}.cybr-btn__glitch:before{content:'';position:absolute;top:calc(var(--border) * 1);right:calc(var(--border) * 1);bottom:calc(var(--border) * 1);left:calc(var(--border) * 1);clip-path:var(--clip);background:var(--primary);z-index:-1}@keyframes glitch{0%{clip-path:var(--clip-one)}2%,8%{clip-path:var(--clip-two);transform:translate(calc(var(--shimmy-distance) * -1%),0)}6%{clip-path:var(--clip-two);transform:translate(calc(var(--shimmy-distance) * 1%),0)}9%{clip-path:var(--clip-two);transform:translate(0,0)}10%{clip-path:var(--clip-three);transform:translate(calc(var(--shimmy-distance) * 1%),0)}13%{clip-path:var(--clip-three);transform:translate(0,0)}14%,21%{clip-path:var(--clip-four);transform:translate(calc(var(--shimmy-distance) * 1%),0)}25%{clip-path:var(--clip-five);transform:translate(calc(var(--shimmy-distance) * 1%),0)}30%{clip-path:var(--clip-five);transform:translate(calc(var(--shimmy-distance) * -1%),0)}35%,45%{clip-path:var(--clip-six);transform:translate(calc(var(--shimmy-distance) * -1%))}40%{clip-path:var(--clip-six);transform:translate(calc(var(--shimmy-distance) * 1%))}50%{clip-path:var(--clip-six);transform:translate(0,0)}55%{clip-path:var(--clip-seven);transform:translate(calc(var(--shimmy-distance) * 1%),0)}60%{clip-path:var(--clip-seven);transform:translate(0,0)}100%,31%,61%{clip-path:var(--clip-four)}}.cybr-btn:nth-of-type(2){--primary-hue:260} :root { --border-size: 0.125rem; --duration: 250ms; --font-family: monospace; --color-primary: white; --color-secondary: black; --color-tertiary: dodgerblue; --shadow: rgba(0, 0, 0, 0.1); --space: 1rem; } * { box-sizing: border-box; } .multi-tombutton#multi { display: flex; width: 100%; box-shadow: var(--shadow) 4px 4px; margin: 15px 0 354px; } .multi-tombutton#multi button { flex-grow: 1; cursor: pointer; position: relative; padding: calc(var(--space) / 1.125) var(--space) var(--space); border: var(--border-size) solid black; color: var(--color-secondary); background-color: var(--color-primary); font-size: 1.5rem; font-family: var(--font-family); text-transform: uppercase; text-shadow: var(--shadow) 2px 2px; transition: flex-grow var(--duration) var(--ease); } .multi-tombutton#multi button + button { border-left: var(--border-size) solid black; margin-left: calc(var(--border-size) * -1); } .multi-tombutton#multi button:hover, .multi-tombutton#multi button:focus { flex-grow: 2; color: white; outline: none; text-shadow: none; background-color: var(--color-secondary); } .multi-tombutton#multi button:focus { outline: var(--border-size) dashed var(--color-primary); outline-offset: calc(var(--border-size) * -3); } .multi-tombutton#multi:hover button:focus:not(:hover) { flex-grow: 1; color: var(--color-secondary); background-color: var(--color-primary); outline-color: var(--color-tertiary); } .multi-tombutton#multi button:active { transform: translateY(var(--border-size)); } @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap'); .container{ width: 100%; display: flex; justify-content: center; align-items: center; } button#btn{ width: 270px; height: 80px; border: none; outline: none; background: #2f2f2f; color: #fff; font-size: 22px; border-radius: 40px; text-align: center; box-shadow: 0 6px 20px -5px rgba(0,0,0,0.4); position: relative; overflow: hidden; cursor: pointer; } .check-box{ width: 80px; height: 80px; border-radius: 40px; box-shadow: 0 0 12px -2px rgba(0,0,0,0.5); position: absolute; top: 0; right: -40px; opacity: 0; } .check-box svg{ width: 40px; margin: 20px; } svg path{ stroke-width: 3; stroke: #fff; stroke-dasharray: 34; stroke-dashoffset: 34; stroke-linecap: round; } .active{ background: #ff2b75; transition: 1s; } .active .check-box{ right: 0; opacity: 1; transition: 1s; } .active p{ margin-right: 125px; transition: 1s; } .active svg path{ stroke-dashoffset: 0; transition: 1s; transition-delay: 1s; } p#btnText { font-size: 23px; display: block; margin-block-start: 1em; margin-block-end: 1em; margin-inline-start: 0px; margin-inline-end: 0px; } textarea { width: 100%; height: 150px; text-align: center; padding: 12px 20px; box-sizing: border-box; border: 2px solid #2f2f2f; border-radius: 4px; background-color: #50575e61; font-size: 16px; resize: none; }
		</style>
	</div>
<?php }

function KENZODataScraperXS(){ ?>
	<div class="wrap">
		<h1>EasyScrap V 1.9.2 Scraping Tool- Settings</h1>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$("#StartGenrate").click(function(event) {
					event.preventDefault();
					$.ajax({
						url: '<?=plugin_dir_url( __FILE__ ) ?>Fetch.php',
						type: 'POST',
						data: {valueText: $("textarea[name=urls]").val()},
					})
					.done(function() {
						console.log("Data Scraped successfully By EasyScrap Scraping Tool");
					})
				});
			});
		</script>
		<div style="display: table;width: 600px;margin: 30px auto;" class="all">
			<textarea placeholder=" XSAnime ONLY- URLs Here Every URL In A Line V 1.9.2" dir="ltr" name="urls"></textarea>
			<div class="container">
				<button id="btn">
					<p id="btnText">Submit</p>
					<div class="check-box">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50">
							<path fill="transparent" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
						</svg>
					</div>
				</button>
			</div>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$("#btn").click(function(event) {
						event.preventDefault();
						$.ajax({
							url: '<?=plugin_dir_url( __FILE__ ) ?>XSFetch.php',
							type: 'POST',
							data: {valueText: $("textarea[name=urls]").val()},
						})
						.done(function() {
							console.log("Data Scraped successfully By EasyScrap Scraping Tool");
						})
					});
				});
				const btn = document.querySelector("#btn");
				const btnText = document.querySelector("#btnText");

				btn.onclick = () => {
					btnText.innerHTML = "Thanks";
					btn.classList.add("active");
				};
			</script>
		</div>

		<h1>SupporteD Sites By [   MovizOne   ]</h1>
		<div id="multi" class="multi-tombutton">
			<button onclick='window.location = "https://v.xsanime.com/"'>XSAmine</button>
			<button onclick='window.location = "https://MovizOne/contact"'>next update +6 new sites</button>
		</div>

		<style type="text/css">
			/* احتفظ بأنماط CSS كما هي */
			body{text-align:center}*{text-align:center}wrap{text-align:center}textarea{width:100%;height:150px;text-align:center;padding:12px 20px;box-sizing:border-box;border:2px solid #ff0003;border-radius:4px;background-color:#ec13135e;font-size:16px;resize:none}input#StartGenrate{display:table;margin:13px auto;width:150px;text-align:center;line-height:40px;height:40px;background:#0073aa;color:#fff;border:0;cursor:pointer;border-radius:10px}@font-face{font-family:Cyber;src:url(https://assets.codepen.io/605876/Blender-Pro-Bold.otf);font-display:swap}*{box-sizing:border-box}body{display:flex;align-items:center;flex-direction:column;justify-content:center;min-height:100vh;font-family:Cyber,sans-serif}body .cybr-btn+.cybr-btn{margin-top:2rem}.cybr-btn{--primary:hsl(var(--primary-hue), 85%, calc(var(--primary-lightness, 50) * 1%));--shadow-primary:hsl(var(--shadow-primary-hue), 90%, 50%);--primary-hue:0;--primary-lightness:50;--color:hsl(0, 0%, 100%);--font-size:26px;--shadow-primary-hue:180;--label-size:9px;--shadow-secondary-hue:60;--shadow-secondary:hsl(var(--shadow-secondary-hue), 90%, 60%);--clip:polygon(0 0, 100% 0, 100% 100%, 95% 100%, 95% 90%, 85% 90%, 85% 100%, 8% 100%, 0 70%);--border:4px;--shimmy-distance:5;--clip-one:polygon(0 2%, 100% 2%, 100% 95%, 95% 95%, 95% 90%, 85% 90%, 85% 95%, 8% 95%, 0 70%);--clip-two:polygon(0 78%, 100% 78%, 100% 100%, 95% 100%, 95% 90%, 85% 90%, 85% 100%, 8% 100%, 0 78%);--clip-three:polygon(0 44%, 100% 44%, 100% 54%, 95% 54%, 95% 54%, 85% 54%, 85% 54%, 8% 54%, 0 54%);--clip-four:polygon(0 0, 100% 0, 100% 0, 95% 0, 95% 0, 85% 0, 85% 0, 8% 0, 0 0);--clip-five:polygon(0 0, 100% 0, 100% 0, 95% 0, 95% 0, 85% 0, 85% 0, 8% 0, 0 0);--clip-six:polygon(0 40%, 100% 40%, 100% 85%, 95% 85%, 95% 85%, 85% 85%, 85% 85%, 8% 85%, 0 70%);--clip-seven:polygon(0 63%, 100% 63%, 100% 80%, 95% 80%, 95% 80%, 85% 80%, 85% 80%, 8% 80%, 0 70%);font-family:Cyber,sans-serif;color:var(--color);cursor:pointer;background:0 0;text-transform:uppercase;font-size:var(--font-size);outline:transparent;letter-spacing:2px;position:relative;font-weight:700;border:0;min-width:300px;height:75px;line-height:75px;transition:background .2s}.cybr-btn:hover{--primary:hsl(var(--primary-hue), 85%, calc(var(--primary-lightness, 50) * 0.8%))}.cybr-btn:active{--primary:hsl(var(--primary-hue), 85%, calc(var(--primary-lightness, 50) * 0.6%))}.cybr-btn:after,.cybr-btn:before{content:'';position:absolute;top:0;left:0;right:0;bottom:0;clip-path:var(--clip);z-index:-1}.cybr-btn:before{background:var(--shadow-primary);transform:translate(var(--border),0)}.cybr-btn:after{background:var(--primary)}.cybr-btn__tag{position:absolute;padding:1px 4px;letter-spacing:1px;line-height:1;bottom:-5%;right:5%;font-weight:400;color:#000;font-size:var(--label-size)}.cybr-btn__glitch{position:absolute;top:calc(var(--border) * -1);left:calc(var(--border) * -1);right:calc(var(--border) * -1);bottom:calc(var(--border) * -1);background:var(--shadow-primary);text-shadow:2px 2px var(--shadow-primary),-2px -2px var(--shadow-secondary);clip-path:var(--clip);animation:glitch 2s infinite;display:none}.cybr-btn:hover .cybr-btn__glitch{display:block}.cybr-btn__glitch:before{content:'';position:absolute;top:calc(var(--border) * 1);right:calc(var(--border) * 1);bottom:calc(var(--border) * 1);left:calc(var(--border) * 1);clip-path:var(--clip);background:var(--primary);z-index:-1}@keyframes glitch{0%{clip-path:var(--clip-one)}2%,8%{clip-path:var(--clip-two);transform:translate(calc(var(--shimmy-distance) * -1%),0)}6%{clip-path:var(--clip-two);transform:translate(calc(var(--shimmy-distance) * 1%),0)}9%{clip-path:var(--clip-two);transform:translate(0,0)}10%{clip-path:var(--clip-three);transform:translate(calc(var(--shimmy-distance) * 1%),0)}13%{clip-path:var(--clip-three);transform:translate(0,0)}14%,21%{clip-path:var(--clip-four);transform:translate(calc(var(--shimmy-distance) * 1%),0)}25%{clip-path:var(--clip-five);transform:translate(calc(var(--shimmy-distance) * 1%),0)}30%{clip-path:var(--clip-five);transform:translate(calc(var(--shimmy-distance) * -1%),0)}35%,45%{clip-path:var(--clip-six);transform:translate(calc(var(--shimmy-distance) * -1%))}40%{clip-path:var(--clip-six);transform:translate(calc(var(--shimmy-distance) * 1%))}50%{clip-path:var(--clip-six);transform:translate(0,0)}55%{clip-path:var(--clip-seven);transform:translate(calc(var(--shimmy-distance) * 1%),0)}60%{clip-path:var(--clip-seven);transform:translate(0,0)}100%,31%,61%{clip-path:var(--clip-four)}}.cybr-btn:nth-of-type(2){--primary-hue:260} :root { --border-size: 0.125rem; --duration: 250ms; --font-family: monospace; --color-primary: white; --color-secondary: black; --color-tertiary: dodgerblue; --shadow: rgba(0, 0, 0, 0.1); --space: 1rem; } * { box-sizing: border-box; } .multi-tombutton#multi { display: flex; width: 100%; box-shadow: var(--shadow) 4px 4px; margin: 15px 0 354px; } .multi-tombutton#multi button { flex-grow: 1; cursor: pointer; position: relative; padding: calc(var(--space) / 1.125) var(--space) var(--space); border: var(--border-size) solid black; color: var(--color-secondary); background-color: var(--color-primary); font-size: 1.5rem; font-family: var(--font-family); text-transform: uppercase; text-shadow: var(--shadow) 2px 2px; transition: flex-grow var(--duration) var(--ease); } .multi-tombutton#multi button + button { border-left: var(--border-size) solid black; margin-left: calc(var(--border-size) * -1); } .multi-tombutton#multi button:hover, .multi-tombutton#multi button:focus { flex-grow: 2; color: white; outline: none; text-shadow: none; background-color: var(--color-secondary); } .multi-tombutton#multi button:focus { outline: var(--border-size) dashed var(--color-primary); outline-offset: calc(var(--border-size) * -3); } .multi-tombutton#multi:hover button:focus:not(:hover) { flex-grow: 1; color: var(--color-secondary); background-color: var(--color-primary); outline-color: var(--color-tertiary); } .multi-tombutton#multi button:active { transform: translateY(var(--border-size)); } @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap'); .container{ width: 100%; display: flex; justify-content: center; align-items: center; } button#btn{ width: 270px; height: 80px; border: none; outline: none; background: #2f2f2f; color: #fff; font-size: 22px; border-radius: 40px; text-align: center; box-shadow: 0 6px 20px -5px rgba(0,0,0,0.4); position: relative; overflow: hidden; cursor: pointer; } .check-box{ width: 80px; height: 80px; border-radius: 40px; box-shadow: 0 0 12px -2px rgba(0,0,0,0.5); position: absolute; top: 0; right: -40px; opacity: 0; } .check-box svg{ width: 40px; margin: 20px; } svg path{ stroke-width: 3; stroke: #fff; stroke-dasharray: 34; stroke-dashoffset: 34; stroke-linecap: round; } .active{ background: #ff2b75; transition: 1s; } .active .check-box{ right: 0; opacity: 1; transition: 1s; } .active p{ margin-right: 125px; transition: 1s; } .active svg path{ stroke-dashoffset: 0; transition: 1s; transition-delay: 1s; } p#btnText { font-size: 23px; display: block; margin-block-start: 1em; margin-block-end: 1em; margin-inline-start: 0px; margin-inline-end: 0px; } textarea { width: 100%; height: 150px; text-align: center; padding: 12px 20px; box-sizing: border-box; border: 2px solid #2f2f2f; border-radius: 4px; background-color: #50575e61; font-size: 16px; resize: none; }
		</style>
	</div>
<?php }