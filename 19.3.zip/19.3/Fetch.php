<?
/*
PowerdBY: KENZO
*/define('WP_USE_THEMES', false);
$URI = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $URI[0] . 'wp-load.php' );
require_once( ABSPATH . 'wp-admin/includes/post.php' );
require 'vendor/autoload.php';
$value = $_POST["valueText"];
$URLS = @explode("\n", $value);
function getstring($a,$b,$c){
$y = explode($b,$a);
$x = explode($c,$y[1]);
return $x[0];
}
foreach (array_reverse($URLS) as $slug) {

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////


if (strpos($slug, "xsanime.com/movie/")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1XSAnime/movies.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $TITLE . " تحميل و مشاهدة انمي باعلي جودة يوتيوب جديد 2022 اخر اصدار  حصري  علي اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->downloads;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->downloads;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "Ribbon", "HD 1080");
update_post_meta($id, "age_meta", "+10");
update_post_meta($id, "runtime", "120 دقيقة");
update_post_meta($id, "status", "now");
wp_set_post_terms($id, "انمي 1080", "quality");
wp_set_post_terms($id, "الصين واليابان", "country");
wp_set_post_terms($id, "ياباني وصيني", "language");
update_post_meta($id, "selary", $url_api->selary2);
if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
update_post_meta($id, "released", array_values($years));
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

elseif (strpos($slug, "xsanime.com/japan_d_anime")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1XSAnime/episode.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$escritor = $url_api->escritor;
$selary = $url_api->selary;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $TITLE . " تحميل و مشاهدة انمي باعلي جودة يوتيوب جديد 2022 اخر اصدار  حصري  علي اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->downloads;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->downloads;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
if (isset($url_api->number) && !empty($url_api->number)) {
update_post_meta($id, "number", $url_api->number);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "Ribbon", "HD 1080");
update_post_meta($id, "age_meta", "+10");
update_post_meta($id, "runtime", "45 دقيقة");
update_post_meta($id, "status", "now");
wp_set_post_terms($id, "انمي 1080", "quality");
wp_set_post_terms($id, "الصين واليابان", "country");
wp_set_post_terms($id, "ياباني وصيني", "language");
update_post_meta($id, "selary", $url_api->selary2);
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}

if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}

if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
wp_set_post_terms($id, array_values($selary), "selary");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
update_post_meta($id, "released", $years);
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

elseif (strpos($slug, "xsanime.com/cartoon_d_series_animes")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1XSAnime/episode.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$escritor = $url_api->escritor;
$selary = $url_api->selary;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $TITLE . " تحميل و مشاهدة انمي باعلي جودة يوتيوب جديد 2022 اخر اصدار  حصري  علي اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->downloads;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->downloads;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
if (isset($url_api->number) && !empty($url_api->number)) {
update_post_meta($id, "number", $url_api->number);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "Ribbon", "HD 1080");
update_post_meta($id, "age_meta", "+10");
update_post_meta($id, "runtime", "45 دقيقة");
update_post_meta($id, "status", "now");
wp_set_post_terms($id, "انمي 1080", "quality");
wp_set_post_terms($id, "الصين واليابان", "country");
wp_set_post_terms($id, "ياباني وصيني", "language");
update_post_meta($id, "selary", $url_api->selary2);
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}

if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}

if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
wp_set_post_terms($id, array_values($selary), "selary");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
update_post_meta($id, "released", $years);
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

elseif (strpos($slug, "xsanime.com/episode")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1XSAnime/episode.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$escritor = $url_api->escritor;
$selary = $url_api->selary;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $TITLE . " تحميل و مشاهدة انمي باعلي جودة يوتيوب جديد 2022 اخر اصدار  حصري  علي اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->downloads;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->downloads;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
if (isset($url_api->number) && !empty($url_api->number)) {
update_post_meta($id, "number", $url_api->number);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "Ribbon", "HD 1080");
update_post_meta($id, "age_meta", "+10");
update_post_meta($id, "runtime", "45 دقيقة");
update_post_meta($id, "status", "now");
wp_set_post_terms($id, "انمي 1080", "quality");
wp_set_post_terms($id, "الصين واليابان", "country");
wp_set_post_terms($id, "ياباني وصيني", "language");
update_post_meta($id, "selary", $url_api->selary2);
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}

if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}

if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
wp_set_post_terms($id, array_values($selary), "selary");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
update_post_meta($id, "released", $years);
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
if (strpos($slug, "arabseed")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/ArabSeedScrap/api.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$story = $url_api->story;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $story . " تحميل مباشر  و مشاهدة باعلي جودة يوتيوب جديد 2022 اخر اصدار حصري علي  اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->downloads;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->downloads;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
update_post_meta($id, "selary", $url_api->selary2);
if (isset($url_api->number_en) && !empty($url_api->number_en)) {
update_post_meta($id, "number", $url_api->number_en);

}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
update_post_meta($id, "selary", $url_api->selary2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}
if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
if (strpos($slug, "arlionz")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1ArabLionzNewScrap/api.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$story = $url_api->story;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $story . " تحميل مباشر  و مشاهدة باعلي جودة يوتيوب جديد 2022 اخر اصدار حصري علي  اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->downloads;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->downloads;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
update_post_meta($id, "selary", $url_api->selary2);
if (isset($url_api->number_en) && !empty($url_api->number_en)) {
update_post_meta($id, "number", $url_api->number_en);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}

if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
if (strpos($slug, "alarabclub")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1AlarabClub/api.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$story = $url_api->story;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $story . " تحميل مباشر  و مشاهدة باعلي جودة يوتيوب جديد 2022 اخر اصدار حصري علي  اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->downloads;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->downloads;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
update_post_meta($id, "selary", $url_api->selary2);
if (isset($url_api->number_en) && !empty($url_api->number_en)) {
update_post_meta($id, "number", $url_api->number_en);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}

if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
if (strpos($slug, "cima4u")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1C4U/api.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$story = $url_api->story;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $story . " تحميل مباشر  و مشاهدة باعلي جودة يوتيوب جديد 2022 اخر اصدار حصري علي  اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->downloads;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->downloads;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
update_post_meta($id, "selary", $url_api->selary2);
if (isset($url_api->number_en) && !empty($url_api->number_en)) {
update_post_meta($id, "number", $url_api->number_en);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}

if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/حلقه/',$url_api->title) || preg_match('/حلقه/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'حلقه')));
wp_set_object_terms($id, $Selaryname, "selary");
update_post_meta($id, "number", $url_api->number_en);
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
update_post_meta($id, "number", $url_api->number_en);
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
update_post_meta($id, "number", $url_api->number_en);
}
}
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
if (strpos($slug, "lodynet")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1LodyNetNewScrap/api.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$story = $url_api->story;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$keyword = $url_api->keywords;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $story . " تحميل مباشر و مشاهدة باعلي جودة يوتيوب جديد 2022 اخر اصدار حصري علي  علي اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->download;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->download;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
update_post_meta($id, "selary", $url_api->selary2);
if (isset($url_api->number_en) && !empty($url_api->number_en)) {
update_post_meta($id, "number", $url_api->number_en);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}
if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($keyword)) {
wp_set_post_terms($id, array_values($keyword), "post_tag");
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
if (strpos($slug, "cima4up")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1Cima4UPNewScrap/api.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$story = $url_api->story;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$keyword = $url_api->keywords;
$knownas = $url_api->knownas;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . '' . $knownas . 'معروف ايضا باسم  مشاهدة  مباشرة اون لاين وتحميل ' . $story . " تحميل مباشر و مشاهدة باعلي جودة يوتيوب جديد  2022 اخر اصدار حصري علي  علي اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->download;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->download;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
update_post_meta($id, "selary", $url_api->selary2);
if (isset($url_api->number_en) && !empty($url_api->number_en)) {
update_post_meta($id, "number", $url_api->number_en);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}
if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($keyword)) {
wp_set_post_terms($id, array_values($keyword), "post_tag");
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
if (strpos($slug, "tuktukcinema")) {
$url_api = json_decode(file_get_contents("http://localhost:10005/api.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$story = $url_api->story;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$keyword = $url_api->keywords;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $story . " تحميل مباشر و مشاهدة باعلي جودة يوتيوب جديد 2022 اخر اصدار حصري علي  علي اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->download;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->download;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
update_post_meta($id, "selary", $url_api->selary2);
if (isset($url_api->number_en) && !empty($url_api->number_en)) {
update_post_meta($id, "number", $url_api->number_en);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}
if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($keyword)) {
wp_set_post_terms($id, array_values($keyword), "post_tag");
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
if (strpos($slug, "mycima")) {
$url_api = json_decode(file_get_contents("https://api-easyscrap.online/1MyCimaNewScrap/api.php?slug=".$slug));
$TITLE = str_replace("مشاهدة", "", $url_api->title);
if (!post_exists( $TITLE ) && !strpos($TITLE, "كامل") && !empty($TITLE)) {
$years = $url_api->release_year;
$language = $url_api->language;
$story = $url_api->story;
$quality = $url_api->quality;
$genre = $url_api->genre;
$nation = $url_api->nation;
$production = $url_api->production;
$rate = $url_api->rate;
$Ribbon = $url_api->Ribbon;
$actors = $url_api->actors;
$keyword = $url_api->keywords;
$escritor = $url_api->escritor;
$ServersWatch = [];
$i = 1;
$daownARR = [];
$post_content = 'مشاهدة  ' . $TITLE . ' مشاهدة  مباشرة اون لاين وتحميل ' . $story . " تحميل مباشر و مشاهدة باعلي جودة يوتيوب جديد 2022 اخر اصدار حصري علي  علي اكثر من سيرفر";
$ServersNew = [];
$DOWNNew = [];
$id = wp_insert_post(array("post_title" => $TITLE, "post_content" =>$post_content, "post_type" => "post", "post_status" => "publish", "post_author" => 1 ,"post_category" => $cat_ID));
$code = '';
$name = '';
$watch = $url_api->watch;
$i = 1;
foreach ($watch as $NUM => $key) {
$ServersNew[] = $key;
}
$down = $url_api->download;
$i = 1;
foreach ($down as $NUM => $key) {
$DOWNNew[] = $key;
}
$DownloadServers = [];
$downloads = $url_api->download;
$downName = ""; $DownURL = ""; $i = 1;
foreach ($downloads as $NUM => $key) {
$downName = explode(".", str_replace("www.", "", parse_url($key)["host"]))[0];
$DownURL = $key;
$DownloadServers[] = ["name" => $downName , "link" => $DownURL];
}
wp_set_object_terms($id, $url_api->category[0], "category");
update_post_meta($id, "home", implode("on"));
update_post_meta($id, "watchlist", implode("\n", $ServersNew));
update_post_meta($id, "downloadslist", implode("\n", $DOWNNew));
update_post_meta($id, "watch_servers_list", implode("\n", $ServersNew));
update_post_meta($id, "download_links_list", implode("\n", $DOWNNew));
update_post_meta($id, "selary", $url_api->selary2);
if (isset($url_api->number_en) && !empty($url_api->number_en)) {
update_post_meta($id, "number", $url_api->number_en);
}
if (isset($url_api->number_en2) && !empty($url_api->number_en2)) {
update_post_meta($id, "number", $url_api->number_en2);
wp_set_object_terms($id, $url_api->selary2, "selary");
}
if (!empty($url_api->story)) {
update_post_meta( $id, "story", $url_api->story );
}
if (!empty($runtime)) {
update_post_meta($id, "runtime", $runtime);
}
if (!empty($Ribbon)) {
update_post_meta($id, "Ribbon", $Ribbon);
}
if (!empty($rate)) {
update_post_meta($id, "imdbRating", $rate);
}
if (!empty($keyword)) {
wp_set_post_terms($id, array_values($keyword), "post_tag");
}
if (!empty($actors)) {
wp_set_post_terms($id, array_values($actors), "actor");
}
if (!empty($quality)) {
wp_set_post_terms($id, array_values($quality), "quality");
}
if (!empty($production)) {
wp_set_post_terms($id, array_values($production), "production");
}
if (!empty($nation)) {
wp_set_post_terms($id, array_values($nation), "country");
}
if (!empty($genre)) {
wp_set_post_terms($id, array_values($genre), "genre");
}
if (!empty($years)) {
wp_set_post_terms($id, array_values($years), "release-year");
}
if (!empty($language)) {
wp_set_post_terms($id, array_values($language), "language");
}
$poster = $url_api->poster;
$image_url = $poster;
if (!empty($poster)) {
$post_id = $id;
$upload_dir = wp_upload_dir();
$image_data = wp_remote_fopen($image_url);
$filename = basename($image_url);
$filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
if (wp_mkdir_p($upload_dir["path"])) {
$file = $upload_dir["path"] . "/" . $filename;
} else {
$file = $upload_dir["basedir"] . "/" . $filename;
}
file_put_contents($file, $image_data);
$wp_filetype = wp_check_filetype($filename, NULL);
$attachment = array("post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit");
$attach_id = wp_insert_attachment($attachment, $file, $post_id);
require_once ABSPATH . "wp-admin/includes/image.php";
$attach_data = wp_generate_attachment_metadata($attach_id, $file);
wp_update_attachment_metadata($attach_id, $attach_data);
set_post_thumbnail( $post_id, $attach_id );
}
if(preg_match('/الحلقه/',$url_api->title) || preg_match('/الحلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مشاهدة', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/مسلسل/',$url_api->title) || preg_match('/حلقة/',$url_api->title))
{
$Selaryname = trim(strip_tags(@getstring($url_api->title, 'مسلسل', 'الحلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
if(preg_match('/انمي/',$url_api->title) || preg_match('/انمي/',$url_api->title))
{
$Selaryname = "انمي " . trim(strip_tags(@getstring($url_api->title, 'انمي', 'حلقة')));
wp_set_object_terms($id, $Selaryname, "selary");
}
}
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
}
?>
<pre dir="ltr"><?php print_r($url_api) ?></pre>
