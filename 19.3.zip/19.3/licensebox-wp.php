<?php
/*
 * Plugin Name: KENZO
 * Plugin URI:  MovizOne
 * Description: اضافة لسحب كل البيانات من مواقع الافلام المدعومه فقط سواء كانت افلام او حلقات مسلسلات
 * Version:     1.9.2
 * Author:      KENZO [MovizOne]
 * Author URI:  MovizOne
 * License:     Premium Multi-purpose Plugins
 * License URI: https://MovizOne/
 * Text Domain: KENZODataScraper
 * Domain Path: /lang
 * Requires at least: 5
 * Requires PHP: 7.1
 *
 */
if(!defined('ABSPATH')){
	exit;
}

include 'licensebox-options.php';