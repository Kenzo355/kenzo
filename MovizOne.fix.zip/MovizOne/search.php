<?php

(new ThemeContext())->Search(get_search_query(), get_option("SearchNumeric"));

?>
