<?php

$res = " نتائج البحث";
if (isset($_GET["cat"])) {
    $res .= "/قسم  " . str_replace(",", " ", $_GET["cat"]);
}
if (isset($_GET["yr"])) {
    $res .= "/عام " . str_replace(",", " ", $_GET["yr"]);
}
if (isset($_GET["qlty"])) {
    $res .= "/جودة " . str_replace(",", " ", $_GET["qlty"]);
}
if (isset($_GET["mpa"])) {
    $res .= "/فئة عمرية  " . str_replace(",", " ", $_GET["mpa"]);
}
if (isset($_GET["gnr"])) {
    $res .= "/نوع  " . str_replace(",", " ", $_GET["gnr"]);
}
if (isset($_GET["ntn"])) {
    $res .= "/دولة  " . str_replace(",", " ", $_GET["ntn"]);
}
echo "<div class=\"isFilterInArchive\"></div><div class=\"MaltyFimls advsearchpage\"><div class=\"SectionTitle\"><div class=\"container\"><h2>";
echo "<span>" . $res . "</span>";
echo "</h2></div></div>";
$args = ["post_type" => "post", "posts_per_page" => 35, "fields" => "ids"];
$args["tax_query"] = ["relation" => "and"];
if (isset($_GET["cat"])) {
    $args["tax_query"]["category"]["taxonomy"] = "category";
    $args["tax_query"]["category"]["field"] = "name";
    $args["tax_query"]["category"]["terms"] = explode(",", $_GET["cat"]);
}
if (isset($_GET["yr"])) {
    $args["tax_query"]["release-year"]["taxonomy"] = "release-year";
    $args["tax_query"]["release-year"]["field"] = "name";
    $args["tax_query"]["release-year"]["terms"] = explode(",", $_GET["yr"]);
}
if (isset($_GET["qlty"])) {
    $args["tax_query"]["quality"]["taxonomy"] = "quality";
    $args["tax_query"]["quality"]["field"] = "name";
    $args["tax_query"]["quality"]["terms"] = explode(",", $_GET["qlty"]);
}
if (isset($_GET["mpa"])) {
    $args["tax_query"]["mpaa"]["taxonomy"] = "mpaa";
    $args["tax_query"]["mpaa"]["field"] = "name";
    $args["tax_query"]["mpaa"]["terms"] = explode(",", $_GET["mpa"]);
}
if (isset($_GET["gnr"])) {
    $args["tax_query"]["genre"]["taxonomy"] = "genre";
    $args["tax_query"]["genre"]["field"] = "name";
    $args["tax_query"]["genre"]["terms"] = explode(",", $_GET["gnr"]);
}
if (isset($_GET["ntn"])) {
    $args["tax_query"]["nation"]["taxonomy"] = "nation";
    $args["tax_query"]["nation"]["field"] = "name";
    $args["tax_query"]["nation"]["terms"] = explode(",", $_GET["ntn"]);
}
echo "<ul class=\"masterUlIn\">      <textarea style=\"display: none\">";
echo json_encode($args);
echo "</textarea>\n      <input type=\"hidden\" class=\"pagenum\" value=\"2\">\n    <div class=\"load\">";
$posts = get_posts($args);
if (!empty($posts)) {
    foreach ($posts as $post) {
        (new ThemeContext())->filmBlock($post);
    }
} else {
    echo "<h2>عفوا ! لا توجد نتائج للبحث</h2>";
}
echo "</div><div class=\"nextprevbtn\"><span class=\"next\">التالي</span><span class=\"prev\">السابق</span></div></ul></div>";

?>