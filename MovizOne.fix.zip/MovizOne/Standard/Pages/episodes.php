<?php

echo "\n";
wp_reset_query();
echo "<div class=\"archiveTitle\">\n    <h1 class=\"title\">";
the_title();
echo "</h1>\n  </div>\n  <section class=\"MasterArchiveSection loadFilter\">\n  \n      <div class=\"MasterLoadMore allBlocks\" data-loading=\"false\">\n        ";
$paged = isset($_GET["offset"]) ? $_GET["offset"] : 1;
global $post;
global $wp_rewrite;
$query = new WP_Query(["post_type" => "post", "posts_per_page" => 20, "fields" => "ids", "meta_query" => [["key" => "number", "value" => "0", "compare" => ">"]], "paged" => $paged]);
if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();
        (new ThemeContext())->filmBlock($post);
    }
}
(new ThemeContext())->ArchivePagination($query, $wp_rewrite);
echo "      </div>\n  </section>";

?>