<?php

global $wp;
echo "<section class=\"MasterArchiveSection loadFilter\" >\n    <div class=\"SectionTitle\">\n      <div class=\"container\">\n        <h2>\n          <span>";
the_title();
echo "</span>\n          <span>";
the_content();
echo "</span>\n        </h2>\n      </div>\n    </div>\n    <div class=\"MasterLoadMore allBlocks\" data-loading=\"false\">\n      ";
$offset = isset($_GET["offset"]) && $_GET["offset"] != 1 ? ($_GET["offset"] - 1) * 40 : 0;
$args = ["taxonomy" => "movseries"];
$movseries = array_slice(get_categories($args), $offset, 40);
echo "        ";
foreach ($movseries as $ser) {
    list($firstID) = get_posts(["post_type" => "post", "posts_per_page" => 1, "ignore_sticky_posts" => 1, "fields" => "ids", "movseries" => $ser->slug]);
    $imgSrc = wp_get_attachment_url(get_post_thumbnail_id($firstID));
    echo "\n            <div class=\"MovieItem\">\n                <a title=\"";
    echo $ser->name;
    echo "\" href=\"";
    echo get_term_link($ser);
    echo "\">\n                  <div class=\"FrontBlock\">\n                    ";
    if (get_term_meta($ser->term_id, "image", 1)) {
        echo "                      <img src=\"";
        echo get_term_meta($ser->term_id, "image", 1);
        echo "\">\n                    ";
    } else {
        echo "                      <img src=\"";
        echo $imgSrc;
        echo "\">\n                    ";
    }
    echo " \n                    <div class=\"TitleBlock\">";
    echo $ser->name;
    echo "</div>\n                  </div>\n                  <div class=\"BackBlock\">\n                    <ul class=\"BarBlock\">\n                        ";
    $rate = get_post_meta($firstID, "imdbRating", true);
    if (!empty($rate)) {
        echo "                            <li class=\"category\" title=\"\" data-herf=\"\">\n                              <i class=\"fas fa-star \"></i><span>";
        echo get_post_meta($firstID, "imdbRating", true);
        echo "</span>\n                            </li>   \n                        ";
    }
    echo "                      ";
    if (get_the_terms($firstID, "genre", "")) {
        echo "                        ";
        foreach (array_slice(is_array(get_the_terms($firstID, "genre", "")) ? get_the_terms($firstID, "genre", "") : araay(), 0, 1) as $genre) {
            echo "                            <li class=\"category two\" title=\"";
            echo $genre->name;
            echo "\" data-herf=\"";
            echo get_term_link($genre);
            echo "\">\n                              <i class=\"fas fa-star \"></i><span>";
            echo $genre->name;
            echo "</span>\n                            </li>\n                        ";
        }
        echo "                      ";
    }
    echo "                    </ul>\n                    <div class=\"ContentBlock\" title=\"قصة  ";
    echo $ser->name;
    echo "\" alt=\"قصة  ";
    echo $ser->name;
    echo "\">";
    echo wp_trim_words(get_post($firstID)->post_content, 12, " [ .. ] ");
    echo "</div>\n                  </div>\n                </a>\n            </div>\n      ";
}
echo "\n      ";
(new ThemeContext())->TaxPagination($args);
echo "    </div>\n</section>";

?>