
$(document).ready(function(){
    var HomeURL = 'https://moviz.one';

	$('.HomeSlider').show();
    var ImagesChanging = function(){
        setTimeout(function(){
            $('[data-src]').each(function(index){
                let that = $(this);
                if( ($(window).scrollTop() + $(window).height()) > $(this).offset().top + 100 ) {
                    $(this).attr('src', $(this).data('src'));
                    $('.MovieItem>a').css('opacity',1)
                }
            });
        },300);
    };

    $(window).on('scroll', ImagesChanging);
    $(window).on('resize', ImagesChanging);
    // Load Events
    $(window).on('load', ImagesChanging);

    // Ajax Handlers Events
    $(window).ajaxSuccess(ImagesChanging);
    
    let xxx = 0;
    $(window).on('scroll',function(){
    	if ($(this).scrollTop() > 10 && xxx == 0) {
    		xxx = 1;

			$('[data-style]').each(function(index){
                $(this).attr('style', $(this).data('style'));
            });
            $('[data-src2]').each(function(index){
                $(this).attr('src', $(this).data('src2'));
            });
    		$.ajax({
    			type:'POST',
    			url:adminAjax,
    			data:{
    				action:'load_chat',
    			},
    			success:function(data){
    				$('.chatBox').append(data);
    			}
    		})
    		if( $('.WatchServers').length > 0 ){
    		    $('ul.WatchServers>li:nth-child(1)').click();
    		}

    		
    		if( $('.trailer-box222').length > 0 ){
    		    
	    	    $.ajax({
    			type:'POST',
    			url:adminAjax,
    			data:{
    				action:'load_trailer',
    				id: $('.trailer-box').data('id')
    			},
    			success:function(data){
    				$('.trailer-box').append(data);
    				$('.trl').show();
    			}
    		})
    		    
    		}
    	}
    })

	if( $('#ytbg').length > 0 ) {
		$('#ytbg').youtube_background();
	}

  	$('.bodyContainer').addClass('loaded');

  	$('iframe').attr('referrerpolicy','no-referrer');
	   if ($('.curUlr').length > 0) {
	   		var url  = $('.curUlr').data('url');
		   if (url.includes("key")) {
		   		$('.pagination li').each(function(){
		   			if ($(this).find('a').length > 0) {
		   				var str = url.split('/?key=')[0];
		   				var key = url.split('/?key=')[1];
		   				var off = $(this).find('a').text();
		   				$(this).find('a').attr('href', str+'/?key='+key+'&offset='+off);	
		   			}
		   		})
		   }
		}

	   if ($('.taxcat').length > 0) {
	   		var url  = $('.taxcat').data('url');
		   if (url.includes("taxcat")) {
		   		$('.pagination li').each(function(){
		   			if ($(this).find('a').length > 0) {
		   				var str = url.split('/?taxcat=')[0];
		   				var off = $(this).find('a').text();
		   				$(this).find('a').attr('href', str+'&offset='+off);	
		   			}
		   		})
		   }
		}



		   	   
	   if ( $('.genresCat').length > 0 ) {
		   var url  = window.location.href.split('&offset')[0];
		   if (url.includes("gnr")) {
		   		$('.pagination li').each(function(){
		   			if ($(this).find('a').length > 0) {
		   				var numpage = $(this).text();
		   				var str = $(this).find('a').attr('href').split('&offset')[0];
		   				$(this).find('a').attr('href', str.replace('/?page','&offset')+'&offset='+numpage );	
		   			}
		   		})


		   }

   			setTimeout(function(){
			 if ($('.pagination .current').parent().next().length > 0) {
		   	 	$('a.next').attr('href',$('.pagination .current').parent().next().find('a').attr('href'));
		   	 }

		   	 if ($('.pagination .current').parent().prev().length > 0) {
		   	 	$('.pagination .prebtn a.prev').attr('href',$('.pagination .current').parent().prev().find('a').attr('href'));
		   	 }
   			},700)
	   }

	  var url  = window.location.href;
	   if (url.includes("/filter")) {
	  		url = url.split('?offset')[0]
          	$('.pagination li').each(function(){
	   			if ($(this).find('a').length > 0) {
		   			var numpage = $(this).text();
	   				var str = $(this).find('a').attr('href').split('?offset')[0];
	   				$(this).find('a').attr('href', str.replace('?page','?offset')+'?offset='+numpage );	
	   			}
	   		})
	   		setTimeout(function(){
			 if ($('.pagination .current').parent().next().length > 0) {
		   	 	$('a.next').attr('href',$('.pagination .current').parent().next().find('a').attr('href'));
		   	 }

		   	 if ($('.pagination .current').parent().prev().length > 0) {
		   	 	$('.pagination .prebtn a.prev').attr('href',$('.pagination .current').parent().prev().find('a').attr('href'));
		   	 }
   			},700)
	   }


	  var url  = window.location.href;
	   if (url.includes("?filter")) {
	  		url = url.split('&offset')[0]
          	$('.pagination li').each(function(){
	   			if ($(this).find('a').length > 0) {
		   			var numpage = $(this).text();
	   				$(this).find('a').attr('href', url.replace('?page','?offset')+'&offset='+numpage );	
	   			}
	   		})
   			setTimeout(function(){
			 if ($('.pagination .current').parent().next().length > 0) {
		   	 	$('a.next').attr('href',$('.pagination .current').parent().next().find('a').attr('href'));
		   	 }

		   	 if ($('.pagination .current').parent().prev().length > 0) {
		   	 	$('.pagination .prebtn a.prev').attr('href',$('.pagination .current').parent().prev().find('a').attr('href'));
		   	 }
   			},700)
	   }


     var url  = window.location.href;
	   if (url.includes("search")) {
	  		url = url.split('?offset')[0]
          	$('.pagination li').each(function(){
	   			if ($(this).find('a').length > 0) {
		   			var numpage = $(this).text();
	   				var str = $(this).find('a').attr('href').split('?offset')[0];
	   				$(this).find('a').attr('href', str.replace('?page','?offset')+'/page/'+numpage );	
	   			}
	   		})
			setTimeout(function(){
		   		if ($('.pagination li.active').next().length > 0) {
				    $('.pagination li:last-child a').attr('href',$('.pagination .active').next().find('a').attr('href'));
				 }
				 if ($('.pagination li.active').prev().length > 0) {
				    $('.prebtn a').attr('href',$('.pagination li.active').prev().find('a').attr('href'));
				 }
			},700)

	   }



	   if (Page == true) {
		var str  = window.location.href;
		var res = str.split('net/')[1];
		var pageurl = HomeURL +'/'+res;
		var pageurl = pageurl.split('?offset')[0];
	   	 $('.pagination li').each(function(){
   			if ($(this).find('a').length > 0) {
   				var str = $(this).find('a').attr('href');
   				var numpage = $(this).text();
   				$(this).find('a').attr('href', pageurl+'?offset='+numpage );	
   			}
   		})
	   	setTimeout(function(){
	   		 if ($('.pagination .current').parent().next().length > 0) {
		   	 	$('a.next').attr('href',$('.pagination .current').parent().next().find('a').attr('href'));
		   	 }
		   	 if ($('.current').parent().prev().length > 0) {
		   	 	$('.prebtn a').attr('href',$('.pagination .current').parent().prev().find('a').attr('href'));
		   	 }
	   	},7000)
	   }

   	   	   
	   	   
	   	   $('.nextprevbtn .next').click(function(e){
	   	   	$.ajax({

	   	   		type:'POST',
	   	   		url:adminAjax,
	   	   		data:{
	   	   			action:'customsssss',
	   	   			num : $('.pagenum').val(),
	   	   			args : $('.masterUlIn').find('textarea').val()
	   	   		},
	   	   		success:function(data){
	   	   			$('.pagenum').val( parseInt($('.pagenum').val())+1 );
   	   			   $('.load').html(data);
	   	   		}
	   	   	})
			
   	   })
	   	   var firstclick = 0;
	    $('.nextprevbtn .prev').click(function(e){
	    	
	          if ($('.pagenum').val() != 0) {
		   	   	$.ajax({
		   	   		type:'POST',
		   	   		url:adminAjax,
		   	   		data:{
		   	   			action:'customsssss',
		   	   			num : $('.pagenum').val(),
		   	   			args : $('.masterUlIn').find('textarea').val()
		   	   		},
		   	   		success:function(data){
			          $('.pagenum').val(parseInt($('.pagenum').val()) - 1);
	   	   			   $('.load').html(data);
		   	   		}
		   	   	})
	   	   }
			
   	   })
	


	if ($('.loadTabsInSeries').length > 0) {
		setTimeout(function(){
         		$.ajax({
         			type:'POST',
         			url:adminAjax,
         			data:{
         				action:'getTabsInsSeries',
         				id:$('.loadTabsInSeries').data('id'),
         				slug:$('.loadTabsInSeries').data('slug'),
         				parent:$('.loadTabsInSeries').data('parent'),
         			},
         			success:function(data){
         			$('.loadTabsInSeries').after(data);	

     					var loadedbyScroll = false;
						var off = 50;
				     	$(window).on('scroll',function(){
				         	if ($(this).scrollTop() > $('.searchFilter').offset().top - 700 && loadedbyScroll ==false) {
				         		loadedbyScroll = true;
				         		$.ajax({
				         			type:'POST',
				         			url:adminAjax,
				         			data:{
				         				action:'getMoreByScroll',
				         				slug:$('.getMoreByScroll').data('slug'),
				         				offset:off
				         			},
				         			success:function(data){
				         			$('.getMoreByScroll .row').append(data);	
				         			loadedbyScroll = false;
				         			off = off + 50;
				         			}
				         		})
				         	}
				         })


         			}
         		})
         },2000)
	}
     if ($('.pagination li').length == 0) {
     	$('.pagination').remove();
     }
	var strng = window.location.href;
    if (strng.includes("gn")) {
    	$('.pagination li').each(function(){
    		if ($(this).find('a').length > 0) {
    			var str = $(this).find('a').attr('href');
    			str = str.replace('/?page', '&offset');
    			$(this).find('a').attr('href',str);
    		}
    		
    	})
    }
   $('.logBtn >div').click(function(){
   	$(this).addClass('active').siblings().removeClass('active');
   	$($(this).data('class')).show().siblings().hide();
   })
  $('.trkBox').click(function(){
  	$('.trFrame').addClass('active')
  })
    $('.trFrame span').click(function(){
  	$('.trFrame').removeClass('active');
  	$('.trFrame iframe').attr('src',$('.trFrame iframe').attr('src'))
  })
   if ($(window).width() < 767 ) {
	   	$(window).on('scroll',function(){
	   		if ($(this).scrollTop() > $('.fixed-header').offset().top + $('.fixed-header').height()) {
	   			$('.menu-header.fixed').addClass('active');
	   		}else {
	   			$('.menu-header.fixed').removeClass('active');
	   		}
	   	})
   }

   $('.searchIcon').click(function(){
   	if ($(this).find('i').hasClass('fa-search')) {
   		$(this).find('i').attr('class','fa fa-times');
   	}else {
   		$(this).find('i').attr('class','fa fa-search');
   	}
   	$('.fixedSearch.forFixed').toggleClass('active');
   })

	
   if ($('.isFilterInArchive').length > 0) {
	    $('.pagination li').each(function(){
	        if ($(this).find('a').length > 0) {
	        var link = $(this).find('a').attr('href');
	    
	        link = link.replace('/?page=','&offset=');
	        $(this).find('a').attr('href',link);
	        }
	    })
	}


     $('body').on('click','.tabs li',function(){
     	$(this).addClass('active').siblings().removeClass('active');
     	$( $(this).data('class') ).show().siblings().hide();
     })
	    $('.showAllEpisodes').click(function(){
	    	$('.allepcont').slideToggle(200);
	    })
		if ($('.iframeHolder').length > 0 ) {
			$('body,html').animate({
				scrollTop:$('.novideo').offset().top
			},100)
			$('.iframeHolder').addClass('maxH')
		}

	   $('.allseasons div').click(function(){
	   	$(this).addClass('active').siblings().removeClass('active');
         $.ajax({
         	type:'POST',
         	url:adminAjax,
         	data:{
         		action:'getSeasonsertax',
         		slug:$(this).data('slug')
         	},
         	success:function(data){
         		$('.allepcont .row').html(data);
         	}
         })
	   })

		$(window).on('scroll',function(){
			if ($(this).scrollTop() > $('.footerTop').offset().top - 800 ) {
				$('.chaticon').addClass('active');
			}else {
				$('.chaticon').removeClass('active');

			}
		})
	$('.comment').click(function(){
	
	  $('.commentBox').slideToggle(200);
	})
	var form = $('.CommentsFormInner');
	$('.SubmitComment button').click(function(e){
	    e.preventDefault();
	    $('.NoCommentsFound').remove();
	    var alerts = 0;
	    form.find('.alerts').html('');
	    form.find('.necessary').removeClass('necessary');
	    if( ISUserLoggedIN == true ) {
	        var Data = {
	            "action":'AddComment',
	            "type":'عضو',
	            "name":form.find('input[name="yourname"]').val(),
	            "email":form.find('input[name="email"]').val(),
	            "message":form.find('textarea').val(),
	            "postID":form.data('id'),
	            "parent":form.data('parent'),
	        };
	        if( form.find('textarea').val() == '' ) {
	            alerts++;
	            form.find('textarea').addClass('necessary');
	        }
	    }else {
	        var Data = {
	            "action":'AddComment',
	            "type":'عضو',
	            "name":form.find('[name="yourname"]').val(),
	            "email":form.find('[name="email"]').val(),
	            "message":form.find('textarea').val(),
	            "postID":form.data('id'),
	            "parent":form.data('parent'),
	        };
	        if( form.find('textarea').val() == '' ) {
	            alerts++;
	            form.find('textarea').addClass('necessary');
	        }
	        if( form.find('[name="yourname"]').val() == '' ) {
	            alerts++;
	            form.find('[name="yourname"]').addClass('necessary');
	        }
	        if( form.find('[name="email"]').val() == '' ) {
	            alerts++;
	            form.find('[name="email"]').addClass('necessary');
	        }
	    }
	    if( alerts > 0 ) {
	        form.find('.alerts').append('<div class="alert alert-danger">يرجي ملأ الحقول المطلوبة (*)</div>');
	    }else {


	        form.addClass('loading');
	        form.append('<div class="loader"><div class="wrapper__two"><div class="rect rect__one"></div><div class="rect rect__two"></div><div class="rect rect__three"></div><div class="rect rect__four"></div></div></div>');

	         $.ajax({
	            type:'POST',
	            url: adminAjax,
	            data:Data,
	            success: function(msg) {
	                form.removeClass('loading');
	                form.find('.loader').remove();
	                form.trigger("reset");
	                if( form.data('parent') == '0' ) {
	                    $('.CommentsListInner').prepend(msg);
	                }else {
	                    $('#comment-'+form.data('parent')).after('<ul class="ChildComments">'+msg+'</ul>');
	                }
	            }
	        });
	         
	    }
	    
	})
	function ReplyComment(btn) {
	    $('form.CommentsFormInner').attr('data-parent', $(btn).data('comment'));
	    $('.ReplyCommentPreview').remove();
	    $('.CommentsSender').append('<div class="ReplyCommentPreview">'
	        +'<h2>'
	        +'<i class="fas fa-reply"></i>'
	        +'<em>رد علي</em> <span>'+$(btn).parent().parent().find('.NameArea > span').text()+'</span>'
	        +'</h2>'
	        +'<p>'+$(btn).parent().parent().find('.CommentContent').text()+'</p>'
	        +'</div>');
	    $('form.CommentsFormInner > .CommentsSender textarea').focus();
	}
	function LoadMoreComments(el) {
	    var Eleme = $(el);
	    Eleme.hide();
	    Eleme.after('<div class="LoadingCommentsArea"><div class="loader"><div class="wrapper__two"><div class="rect rect__one"></div><div class="rect rect__two"></div><div class="rect rect__three"></div><div class="rect rect__four"></div></div></div></div>');
	}
     //////////////////////////////////////////////////////////////
     $('.uploadFile input[type="file"]').on('change',function(e){
        var url = $(this).data('url');
        var fd = new FormData();
        var files = $(this)[0].files[0];
        fd.append('file',files);

        fd.append('action','uploadImage');
        $('.imageprofile').append('<div class="loaderii"><div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>');
        $.ajax({
          type:'POST',
          url:url,
          contentType: false,
          processData: false,
          data:fd,
          success:function(msg){
            $('.imageprofile').html(msg);
          }
        })
    })
     ////////////////////////////////////////////////////
   $('.serdowns').click(function(){
   	$('.seriesTab').slideToggle(200);
   })
   var clicked  = 0 ;
  	$('body').on('click','.like,.dislike',function(){
      let rate = $(this).attr('class');
      let id = $(this).attr('data-id');
      if (rate == 'like') {
  		if( $(this).attr('id') == 'likeColor' ){
  			$(this).removeAttr('id');
  		}else {
  			$(this).attr('id','likeColor');
  		}
      }else {

		if( $(this).attr('id') == 'dislikeColor' ){
  			$(this).removeAttr('id');
  		}else {
  			$(this).attr('id','dislikeColor');
  		}
      }
      if(clicked == 0){
      	clicked = 1;
	      $.ajax({
	        type:'POST',
	        url:adminAjax,
	        dataType:'json',
	        data:{
	          action:'rateFilm',
	          rate:rate,
	          id:id
	        },
	        success:function(data){
	        	clicked = 0;
	          // ggood
	          $.each(data, function(i, item) {
	             if( i == 'likes') {
	              $('.like strong').html(item);
	             }
	              if( i == 'dislikes') {
	              $('.dislike strong').html(item);
	             }
	          });
	        }
	      })
	  }
   })




   $('.seasonlist').click(function(){
   	$('.seasons').slideToggle(200);
   })
	$('body').on('click','.addtomylist.uselo',function(){
         if( $(this).data('lt') == 'inb' ){
			 if($(this).hasClass('inblock')){
				$(this).addClass('difcolor').removeClass('inblock').html('<i class="fas fa-check"></i><span>حذف من قائمتي</span>');
			 }else {
				$(this).removeClass('difcolor').addClass('inblock').html('<i class="fa-plus-square"></i><span>اضف لقائمتي</span>');
			 }
		}else{
			if ($(this).hasClass('clicked')) {
				$(this).removeClass('clicked').html('<i class="fas fa-plus-circle"></i> اضافة لقائمتي ');
			}else {
				$(this).addClass('clicked').html('<i class="fas fa-check"></i> في قائمتي');
			}
		}
		var userid = $(this).data('user');
		var id = $(this).data('id');
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'later',
				id:id,
				userid:userid
			},
			success:function(data){
				//
			}
		})
	})
  

   $('.list div').click(function(){
   	$(this).addClass('active').siblings().removeClass('active');
   	$($(this).data('id')).show().siblings().hide();
   })
	$('body').on('click','.addtomylist.notlogged',function(){
	  $('.haveToRegister').show();
	  setTimeout(function(){
	  	$('.haveToRegister').hide();
	  },1000)
	})
	$('body').on('click','.followTax.muselo',function(){
		if ($(this).hasClass('clicked')) {
			$(this).removeClass('clicked').html('متابعة ');
		}else {
			$(this).addClass('clicked').html('تمت المتابعة');
		}
		var userid = $(this).data('user');
		var id = $(this).data('id');
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'followTax',
				id:id,
				userid:userid
			},
			success:function(data){
				//
			}
		})
	})
$('body').on('click','.followTax.notlog',function(){
	  $('.haveToRegister2').show();
	  setTimeout(function(){
	  	$('.haveToRegister2').hide();
	  },1000)
	})


   $('body').on('click','section.filmbar li.next',function(){
   	  $('.netflixback').html('<div class="lds-facebook"><div></div><div></div><div></div></div>');
   	  var archive = '';
   	  if ($('.arPg').length > 0) {
   	  	archive = $('.arPg').data('tax');
   	  }
   	  console.log('test clecked')
   	  $.ajax({
   	  	type:'POST',
   	  	url:adminAjax,
   	  	dataType:'json',
   	  	data:{
   	  		action:'nextPost',
   	  		slug:$(this).data('slug'),
   	  		id:$(this).data('id'),
   	  		archive:archive
   	  	},
   	  	success:function(data){
   	  		$('.netflixback').html(data['video']);
   	  		$('.somInfo').html(data['info']);
   	  		$('.myTile').html(data['title']);
   	  		$('.randButtons').html(data['buttons']);
   			$('[data-youtube]').youtube_background();
   			var pause = 1;
		    $('.pause').on('click',function(){
			  $('.play-toggle').click();
			  console.log('test');
			  	$('.play-toggle').toggleClass('pause');
				  if (pause == 1) {
				  	$('.pause').html('<i class="far fa-play"></i>');
				  	pause = 0;
				  }else {
				  	$('.pause').html('<i class="far fa-pause"></i>');
				  	pause = 1;
				  }
			})
			var stmute = 1;
		 	var fr = 0;

		   $('.mute').on('click',function(){
			  $('button.mute-toggle').click();
			  	$('button.mute-toggle').toggleClass('muted');
				  if (stmute == 1) {
				  	$('.mute').html('<i class="fas fa-volume"></i>');
				  	stmute = 0;
				  }else {
				  	if (fr ==0 ) {
				  		fr=1;
				  	}else{
					  	$('.mute').html('<i class="fas fa-volume-mute"></i>');
				  		stmute = 1;
					  }
				  }
			})

			var z = 1;
		   $('body').on('click','.showandhide',function(){
			  if (z == 1) {
			  	$('.somInfo,.myTile').addClass('hide');
			  	$('.showandhide').html('<i class="fas fa-eye"></i>');
			  	z = 0;
			  }else {
			  	$('.somInfo,.myTile').removeClass('hide');
			  	$('.showandhide').html('<i class="fas fa-eye-slash"></i>');
			  	z=1;
			  }
			})

   	  	}
   	  })
   })



 	var stmute = 1;
 	var fr = 0;
   $('.mute').click(function(){
	  $('.mute-toggle').click();
		  if (stmute == 1) {
		  	$('.mute').html('<i class="fas fa-volume-mute"></i>');
		  	stmute = 0;
		  }else {
		  	if (fr ==0 ) {
		  		fr=1;
		  	}else{
			  	$('.mute').html('<i class="fas fa-volume"></i>');
		  		stmute = 1;
			  }
		  }
	})
  
$('.custom-links .menu-item').each(function(){
  	var tx = $(this).find('a').text();
  	$(this).find('a').html('<span>'+tx+'</span>');
  })
	var pause = 1;
	   $('.pause').on('click',function(){
		  $('.play-toggle').click();
		  console.log('test');
		  	$('.play-toggle').toggleClass('pause');
			  if (pause == 1) {
			  	$('.pause').html('<i class="far fa-play"></i>');
			  	pause = 0;
			  }else {
			  	$('.pause').html('<i class="far fa-pause"></i>');
			  	pause = 1;
			  }
		})


	var z = 1;
	   $('body').on('click','.showandhide',function(){
		  if (z == 1) {
		  	$('.somInfo,.myTile').addClass('hide');
		  	$('.showandhide').html('<i class="fas fa-eye"></i>');
		  	z = 0;
		  }else {
		  	$('.somInfo,.myTile').removeClass('hide');
		  	$('.showandhide').html('<i class="fas fa-eye-slash"></i>');
		  	z=1;
		  }
		})



	$('.login button').click(function(e){
		e.preventDefault();
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'loginmethod',
				username:$('.login input[name="username"]').val(),
				password:$('.login input[name="password"]').val(),
			},
			success:function(data){
				$('.loginCard').before(data);
			}
		})
	})


	$('.register button').click(function(e){
		e.preventDefault();
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'registermethod',
				username:$('.register input[name="username"]').val(),
				password:$('.register input[name="password"]').val(),
				email:$('.register input[name="email"]').val(),
			},
			success:function(data){
				$('.loginCard').before(data);
				if ($('.is_success').length > 0) {
					$('.login input[name="username"]').val($('.register input[name="username"]').val());
					$('.login input[name="password"]').val($('.register input[name="password"]').val());
					$('.login button').click();
				}

			}
		})
	})
setInterval(function(){
$('section.allOptions >div ul').each(function(){
 var th = $(this).attr('class');
    if( $(this).find('li.active').length > 0 ){
      $('section.searchFilter >div >div[data-class="'+th+'"]').addClass('active')
    }else {
      $('section.searchFilter >div >div[data-class="'+th+'"]').removeClass('active')

    }
})
},1000);

	if( $('.pagination ul li.prebtn').length == 0 && $('.pagination li a.prev').length == 0 ){
		$('.pagination ul').prepend('<li class="prebtn poinnone"><a href="#">السابق</a></li>');
	}
	if ($('.pagination li a.prev').length >0 ) {
		$('.pagination li a.prev').parent().addClass('prebtn');
	}

	$('body').on('click','.searchepisode button',function(){
		if ($('.searchepisode input').val() != '') {
			$.ajax({
				type:'POST',
				url:adminAjax,
				data:{
					action:'gtshrt',
					number:$('.searchepisode input').val(),
					slug:$('.searchepisode input').data('slug')
				},
				success:function(data){
					$('.searchepresult').css('display','flex').html(data);
				}
			})
		}else{
			$('.searchepresult').hide();
		}
	})

$('.prebtn a').html('السابق')
$('.pagination li:last-child a').html('التالي')
	var ix = true;
	$('.toggleShow').click(function(){
		if (ix == true) {
			ix = false;
			$('.toggleShow').find('i').attr('class','fa fa-times');
		}else {
			ix = true;
			$('.toggleShow').find('i').attr('class','fa fa-pencil');
		}
	  $('.register').toggleClass('active');
	   $('.loginCard').toggleClass('reg');
	   
	})


	$('form input').focus(function(){
	 $(this).prev().addClass('focus')
	})
	// $('form input').blur(function(){
	//  $(this).prev().removeClass('focus')
	// })
	$('ul.regBtn li').click(function(){
		$(this).addClass('active').siblings().removeClass('active')
	})
	$('.chaticon').click(function(){
		$('.chatBox').addClass('active');
	})

	$('.chatBox .close').click(function(){
		$('.chatBox').removeClass('active');
	})
     $('body').on('click','section.allOptions >div ul li',function(){
     	$(this).toggleClass('active');
     	$('.'+$(this).parent('class')+' li').each(function(){
     		if ($(this).hasClass('active')) {
     		}
     	})
     })

    if ($(window).width() > 767) {
     $('section.searchFilter >div >div > span').click(function(){
     	$('section.allOptions').slideToggle(200);
     	$.ajax({
     		type:'POST',
     		url:adminAjax,
     		data:{
     			action:'getOptionsSearch'
     		},
     		success:function(data){
     			$('section.allOptions').html(data)
     		}
     	})
     })
 }else {
     $('section.searchFilter >div >div > span').click(function(){
     	$('section.allOptions').slideDown(200);
     	var curClass = $(this).parent().data('class');
     	$('.'+curClass).show().siblings('ul').hide();
    
     })
 }

 if ($('.custom-links.owl-carousel').length > 0) {
 	$('.custom-links.owl-carousel').owlCarousel({
 		items:1,
 		loop:true,
 		rtl:true,
 		autoplay:true
 	})
 	$('ul.custom-links .owl-nav.disabled .owl-next').html('<i class="fa fa-chevron-right"></i>')
 	$('ul.custom-links .owl-nav.disabled .owl-prev').html('<i class="fa fa-chevron-left"></i>')
 }

     $('body').on('click','.startSearchNow',function(){
     	$('section.searchFilter form button').click();
     })

	$('section.searchFilter form button').click(function(e){
		e.preventDefault();
		var cats = '';
		var years = '';
		var qls = '';
		var genres = '';
		var nts = '';
		var mpaas = '';
		if ($('.category li.active').length > 0) {
            $('.category li.active').each(function(){
            	cats += $(this).data('name')+',';
            })
			$('section.searchFilter form input[name="cat"]').val( cats );
		}else {
			$('section.searchFilter form input[name="cat"]').remove();
		}

		if ($('.genre li.active').length > 0) {
	        $('.genre li.active').each(function(){
            	genres += $(this).data('name')+',';
            })
			$('section.searchFilter form input[name="gnr"]').val( genres );
		}else {
			$('section.searchFilter form input[name="gnr"]').remove();
		}

		if ($('.release-year li.active').length > 0) {
	        $('.release-year li.active').each(function(){
            	years += $(this).data('name')+',';
            })
			$('section.searchFilter form input[name="yr"]').val( years );

		}else {
			$('section.searchFilter form input[name="yr"]').remove();
		}

		if ($('.quality li.active').length > 0) {

	        $('.quality li.active').each(function(){
            	qls += $(this).data('name')+',';
            })
			$('section.searchFilter form input[name="qlty"]').val( qls );
		}else {
			$('section.searchFilter form input[name="qlty"]').remove();
		}

	   if ($('.nation li.active').length > 0) {
	        $('.nation li.active').each(function(){
            	nts += $(this).data('name')+',';
            })
			$('section.searchFilter form input[name="ntn"]').val( nts );
		}else {
			$('section.searchFilter form input[name="ntn"]').remove();
		}

	   if ($('.mpaa li.active').length > 0) {

		   $('.mpaa li.active').each(function(){
            	mpaas += $(this).data('name')+',';
            })
			$('section.searchFilter form input[name="mpa"]').val( mpaas );
		}else {
			$('section.searchFilter form input[name="mpa"]').remove();
		}

		$('section.searchFilter form').submit();
		

	})
       var loaded = false;
       $(window).on('scroll',function(){
           if(loaded == false && $(this).scrollTop() > 10){
               loaded = true;
               $.ajax({
                   type:'POST',
                   url:$('.chat').data('url'),
                   data:{
                       action:'chatBox'
                   },
                   success:function(data){
                       $('.chat').append(data);
                   }
               })
           }
       })
        if( $(".SliderBlocksSection  > ul").length > 0 ){
	  		$(".SliderBlocksSection  > ul").owlCarousel({
					rtl:true,
					stopOnHover: true,
					autoPlay: 10000,
					addClassActive: true,
					margin:15,
					navText : ['<i class="fa fa-angle-right"></i>','<i class="fa fa-angle-left"></i>'],
					loop:true,
					nav: true,
				    responsive:{
				        0:{
				            items:2,
				            nav:true
				        },
				        480:{
				            items:3,
				            nav:false
				        },
				        970:{
				            items:4,
				            nav:true,
				        },
				        1000:{
				            items:5,
				            nav:true,
				        }
				    },
		    });
	    
        }
  $('body').on('click','#profile',function(e){
  	e.preventDefault();
  	var url = $(this).data('url'),
		firstname = $('.prForm input[name="firstname"]').val(),
		lastname = $('.prForm input[name="lastname"]').val() ,
		newpassword = $('.prForm input[name="newpassword"]').val(),
		renewpassword = $('.prForm input[name="renewpassword"]').val(),
		image = $('.imageprofile img').attr('src'),
		email = $('.prForm input[name="email"]').val();
  	$.ajax({
  		type:'POST',
  		url:url,
  		data:{
  			action:'profileSetting',
			firstname:firstname,
			lastname:lastname,
			newpassword:newpassword,
			renewpassword:renewpassword,
			image:image,
			email:email,
  		},
  		success:function(data){
  			$('.UserProfile').prepend(data);
  			window.location.href = HomeURL+'/myaccount';
  		}
  	})
  })

  $('.edit').click(function(){
  	$($(this).data('class')).show();
  })

 $('body').on('click','.subs.setting form input',function(e){
     if ($(this).attr('checked') == 'checked') {
     	$(this).removeAttr('checked');
     }else {
 	 	$(this).attr('checked','checked');
     }
})
 $('body').on('click','#saveHistorySetting',function(e){
 	e.preventDefault();
 	var form = $(this).parent();
 	var stophistory = $('input[name="stophistory"]').attr('checked');
 	var removeHistory = $('input[name="removeHistory"]').attr('checked');
 	$.ajax({
 		type:'POST',
 		url:adminAjax,
 		data:{
 			action:'historySetting',
 			stophistory:stophistory,
			removeHistory:removeHistory
 		},
 		success:function(data){
 			form.before(data);
		 	setTimeout(function(){
		 		$('.successmessage').fadeOut(300).remove();
		 	},2000)
 		}
 	})
 })

  $('body').on('click','#saveNotesSetting',function(e){
 	e.preventDefault();
 	var form = $(this).parent();
 	var stopnotes = $('input[name="stopnotes"]').attr('checked');
 	var removeNotes = $('input[name="removeNotes"]').attr('checked');
 	$.ajax({
 		type:'POST',
 		url:adminAjax,
 		data:{
 			action:'notestSetting',
 			stopnotes:stopnotes,
			removeNotes:removeNotes
 		},
 		success:function(data){
 			form.before(data);
		 	setTimeout(function(){
		 		$('.successmessage').fadeOut(300).remove();
		 	},2000)
 		}
 	})
 })


 

$('.btns span').click(function(){
   $('.trailerBox').remove();
  $('body').append('<div class="trailerBox active">'+$(this).find('div').html()+'</div>');
})

if( $('section.shows').length > 0 ){
	$('body').on('click','.trailerBox',function(){
		$(this).remove();
	})
	$('.trailerBox iframe').click(function(e){
		e.stopPropagation();
	})
}


	
	if ($('ul.errors').length > 0) {
		setTimeout(function(){
			$('ul.errors').fadeOut(500);
		},3000);
	}


	$('.fixedSearch').click(function(e){
		e.stopPropagation();
	})

	$('body').click(function(){
		$('.fixedSearch input').val('');
		
		$('div#SearchListResult').hide();
	})
	$('.later.clicked').hover(function(){
		   $(this).html('<i class="fa fa-times"></i> الحذف من قائمة المشاهدة ');
	},function(){
		 $(this).html('<i class="fas fa-check"></i> تمت الاضافة الي قائمة المشاهدة');
	})

	$('.subscribe.clicked').hover(function(){
	 
	   $(this).html('<i class="fa fa-times"></i>  الغاء المتابعة ');

	},function(){
	 
	 $(this).html('<i class="fas fa-check"></i>    تمت المتابعة ');
	})


	$('ul.filters li').click(function(){
		if( !$(this).is(':last-child') ){
			$(this).addClass('active').siblings().removeClass('active');
			var name = $(this).data('name');
			var ser  = $(this).data('ser');
			$('.pagination').hide();
			$.ajax({
				type:'POST',
				url:adminAjax,
				data:{
					action:'filterTab',
					name:name,
					ser:ser
				},
				success:function(data){
					$('.allBlocks').html(data);
				}
			})
		}
	})
   if ( $('.listNotices li').length == 0 ) {
   		$('.listNotices').html('<span class="iconNotes"><i class="fal fa-bell"></i></span><h3 class="noNotifications">لا توجد اشعارات حاليا</h3>')
   }
   $('.bellIcon').click(function(){
   	$('ul.listNotices').toggleClass('active');
   	$('.bellIcon span').remove();
   	$.ajax({
   		type:'POST',
   		url:adminAjax,
   		data:{
   			action:'noticeSeen'
   		}
   	})
   })

   	$('body').on('click','.later',function(){
		if ($(this).hasClass('clicked')) {
			$(this).removeClass('clicked').html('<i class="fa fa-plus"></i> اضافة الي قائمة المشاهدة');
		}else {
			$(this).addClass('clicked').html('<i class="fas fa-check"></i> تمت الاضافة الي قائمة المشاهدة');
		}
		var userid = $(this).data('user');
		var id = $(this).data('id');
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'later',
				id:id,
				userid:userid
			},
			success:function(data){
				//
			}
		})
	})
    

    $('body').on('click','.cancelhistory',function(){
    	$(this).parent().remove();
		var userid = $(this).data('user');
		var id = $(this).data('id');
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'later',
				id:id,
				userid:userid
			},
			success:function(data){
				//
			}
		})
    })
   $('.laterNoRegister').click(function(){
   	window.location.href = $(this).data('url');
   })


	$('.subscribe').click(function(){
		       if( $(this).data('lt') == 'inb' ){
			 if($(this).hasClass('inblock')){
				$(this).addClass('difcolor').removeClass('inblock').html('<i class="fas fa-check"></i><span>حذف من  المتابعة</span>');
			 }else {
				$(this).removeClass('difcolor').addClass('inblock').html('<i class="fa-plus-square"></i><span>متابعة</span>');
			 }
		}else{
			if ($(this).hasClass('clicked')) {
			$(this).removeClass('clicked').html('<i class="fa fa-heart"></i> متابعه');
		}else {
			$(this).addClass('clicked').html('<i class="fas fa-check"></i> تمت المتابعة  ');
		}
		}


		
		var userid = $(this).data('user');
		var id = $(this).data('id');
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'subscribe',
				id:id,
				userid:userid
			},
			success:function(data){
				//
			}
		})
	})
    
    $('ul.listButtons li').click(function(){
    	$(this).addClass('active').siblings().removeClass('active');
    	
    		var id = $(this).data('id');
    		$('.leftBox').html('<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>');
    		$.ajax({
    			type:'POST',
    			url:adminAjax,
    			data:{
    				action:'myAccount',
    				id:id
    			},
    			success:function(data){
    				$('.leftBox').html(data);
    			}
    		})
    	
    })
     if( $('.filterExist').length > 0 ){
		$('.listButtons li[data-id="'+$('.filterExist').data('id')+'"]').click();
	 }
	$('body').on('click','.cancelSub',function(){
		$(this).parent().remove();
		var userid = $(this).data('user');
		var id = $(this).data('id');
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'subscribe',
				id:id,
				userid:userid
			},
			success:function(data){
				//
			}
		})
	});

    $('.overlaypost').click(function(){
    	$(this).removeClass('active');
    })

    $('.overlaypost div').click(function(e){
    	e.stopPropagation();
    })
    $(window).on('scroll',function(){
    	if($(this).scrollTop() > 10){
	    	$('img').each(function(){
		   $(this).attr('src',$(this).attr('data-src'));
		   $(this).removeAttr('data-src');
		   })
		     $('[data-style]').each(function(){
		   $(this).attr('style',$(this).attr('data-style'));
		   $(this).removeAttr('data-style');
		   });
    	}
    })

	/*AutoComplete Search*/
    var SearchListResult = $('#SearchListResult');
	$('#searchAuto').keyup(function(e){
		var that = $(this);
       setTimeout(function(){
           console.log(that.val());
   		if( that.val() != ''  ) {
			SearchListResult.show();
			$.ajax({
		        url : HomeURL+'/customsearch/searchcenter/'+that.val()+'/',
		        dataType:'json',
				success: function(data) {
				    console.log(data);
				    var elm = '';
    				$.each(data, function(i, item) {
                      elm +='<li><a href="'+item.url+'"><div class="SearchThumb"><img src="'+item.thumb+'" /></div><div class="SearchResultInner"><h1>'+item.title+'</h1></div></a></li>';
                    });
                  elm += '<a href="'+HomeURL +'/search/'+that.val()+'">مشاهدة المزيد</a>';
                	$('#SearchInnerList').html(elm);
                	SearchListResult.show();

				}
			});
		}else {
			SearchListResult.hide();
		}
       },1000)
	});

	/*ColorBox*/
	$('.colorBox a').on('click',function(e){
		e.preventDefault();
		var curStyle = $('head .mainStyle').attr('href');
		var newWord = curStyle.replace('style.css','');
		newWord = newWord.replace('white.css','');
		var color = $(this).attr('data-color');
		var stl = newWord+''+color.trim()+'.css';
		$('head .mainStyle').attr('href',stl);
		$('.colorChange').attr('class','colorChange '+color);
		$.ajax({
			type:'POST',
			url:adminAjax,
			data:{
				action:'siteColor',
				color:color
			},
			success:function(data){
				// var stl = newWord+''+data.trim()+'.css';
				// $('head .mainStyle').attr('href',stl);
			}
		})
		
	}); 
    
       if( $('.SlidesList').length > 0 ){ 
	  	var $owl = $('.SlidesList').owlCarousel({
	        autoplay: 10000,
	        nav:false,
	        dots:true,
	        loop: true,
	        items:6,
	        autoWidth:true
	
        });
	    $('.HomeSlider span.next').click(function(){
			$('.SlidesList .owl-next').click();
		});
		$('.HomeSlider span.prev').click(function(){
			$('.SlidesList .owl-prev').click();
		});

		// $('ul.SlidesList .owl-item>li').hover(function(){
		// 	$owl.trigger('refresh.owl.carousel');
		// 	$(this).addClass('extended')
		// },function(){
		// 	$owl.trigger('refresh.owl.carousel');
		// 	$(this).removeClass('extended')

		// })
	}


	if( singlePage == true){
	 
			var counter;
			function IframeLoaded() {
				$('body').attr('enable-iframe', 'yes');
			}

	        $('.TrillerOpenBtn').click(function(){
		    	$('.TrilerOverlay').addClass('active');
		    
		    });

	    	$('.TrilerOverlay > .overlayClosse , .TrilerOverlay > span.closseTriller').click(function(){
		    	$('.TrilerOverlay').removeClass('active');
		    	$('.TrilerOverlay iframe').attr('src', $('.TrilerOverlay iframe').attr('src') );
		    });

	        $('.report-post').click(function(){
		    	$('#ReportOverlay').addClass('active');
		    });
			$('#ReportOverlay > .closseTrillerRep , #ReportOverlay > .overlayClosseRep').click(function(){
		    	$('#ReportOverlay').removeClass('active');
		    });

			$('.SidebarSlider > ul > li').click(function(){
				$('.SidebarSlider > ul > li').removeClass('active');
				$(this).addClass('active');
				var filter = $(this).data('filter');
				$('.SlidesInner').html('<div class="fancy-spinner"> <div class="ring"></div> <div class="ring"></div> <div class="dot"></div> </div>');
				$.ajax({
					url: adminAjax,
					type: 'POST',
					data:{
						filter:filter,
						action:'homeFilter'
					},
					success: function(msg) {
						$('.SlidesInner').html(msg);
						$(".SlidesInner > ul").owlCarousel({
							items: 4,
							rtl: true,
							responsive: false,
							stopOnHover: true,
							autoPlay: 10000,
							addClassActive: true,
							navText : ['<i class="fa fa-angle-right"></i>','<i class="fa fa-angle-left"></i>'],
							loop:true,
					    });
					}
				});
			});

		    $('ul.SeasonsList > li a').click(function(){
		    	var serie = $(this).data('season');
		    	$('ul.SeasonsList > li a').parent().removeClass('active');
		    	$(this).parent().addClass('active');
		    	$('.EpisodesList').html('<div class="showbox"><div class="loader"> <svg class="circular" viewBox="25 25 50 50"> <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/> </svg> </div> </div>');
		    	$.ajax({
		    		url:adminAjax,
					data:{
						serie:serie,
						action:'EpisodesList'
					},
					type:'POST',
					success: function(msg) {
						$('.EpisodesList').html(msg);
					}
		    	});
		    	return false;
		    });

	        var loadedmore = $('.MainRelated');
		   	var offset = 18;
		    $('.MoreLoaded').on('click',function(){
		      var id = $(this).data('id');
		      loadedmore.append('<div class="masterloadingajax" style="min-height:300px"><div class="loaderLoaded"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div></div>');
		      $.ajax({
		        type:'POST',
		        url:adminAjax,
		        data:{
	        	  action:'Espoblock',
		          "id":id ,
		          "offset":offset,
		        },
		        success:function(data){
		          $('.MainRelated .masterloadingajax').remove();
		          if(data == '' ){
		            loadedmore.append('<h2 class="noMorePosts">لا يوجد نتائج اخري</h2>'); 
		          }else {
		            loadedmore.append(data);
		            loadsonglast = false;
		            offset = offset + 20;
		          }
		        }
		      });
		    });

		    $("body").on('click','.serverItem',function(){
		    	var server = $(this).data('server');
			      $(this).addClass("active").siblings().removeClass("active");
			      $.ajax({
			      	type:'POST',
			      	url:adminAjax,
			      	data:{
			      		action:'getServer',
			      		server:server
			      	},
			      	success:function(data){
			      		$(".iframeHolder").html(data);
			      		 $('iframe').attr('referrerpolicy','no-referrer');
			      	}
			      })
		    });
         
         $('body').on('click','ul.episodesAside li',function(){
         	var id   = $(this).data('id');
         	$(this).addClass('active').siblings().removeClass('active');
         	$.ajax({
     			type:'POST',
         		url:adminAjax,
         		data:{
         			action:'infoLoad',
         			id:id,
         		},
         		success:function(data){
         			$('.infoLoad').html(data);
         		}
         	});
         	$.ajax({
         		type:'POST',
         		url:adminAjax,
         		data:{
         			action:'getFullWatchServers',
         			id:id,
         		},
         		success:function(data){
         			$('.loadAjaxInfo').html(data);
         			$('body,html').animate({
         				scrollTop:0
         			},1000);
         			$(".WatchServers > li.serverItem:first-of-type").addClass('active').click();
         		}
         	})
         })

         $('.seasons span').click(function(){
         	$(this).addClass('active').siblings().removeClass('active');
         	var slug = $(this).data('slug');
         	var txt = $(this).text();
         	$.ajax({
         		type:'POST',
         		url:adminAjax,
         		data:{
         			slug:slug,
         			action:'getSeasons',
         		},
         		success:function(data){
         			$('.epCont').html(data);
         			$('ul.episodesAside h2').html('حلقات '+txt);
         		}
         	})
         })
         
         $('.lightOff').click(function(){
         	$('.overlay,#EmbedCode').addClass('active');
            $(this).hide();
            $('.lightOn').show();
         })
		   
        $('body').on('click','.overlay',function(){
         	$('.overlay,#EmbedCode').removeClass('active');
         	  	var txt  = $('.lightOff').text();
         	 $('.lightOff').show();
         	 $('.lightOn').hide();
     	})
     	    $('body').on('click','.lightOn',function(){
         	$('.overlay,#EmbedCode').removeClass('active');
         	  	var txt  = $('.lightOff').text();
         	 $('.lightOff').show();
         	 $('.lightOn').hide();
     	})
	}
   
   if(mobile == true) {

	   	$('.mobileMenu .sub-menu').parent().find('>a').click(function(e){
	   		e.preventDefault();
	   		$(this).parent().find('ul').slideToggle(200);
	   	})

	   	$('.MenuToggle').click(function(){
	   		$('.mobileMenu,.overlay_Menu').addClass('active');
	   	})
	   
	   $('.overlay_Menu').click(function(){
	   		$('.mobileMenu,.overlay_Menu').removeClass('active');
	   })
  

   }
         

    $('.trl').on('click',function(){
    	$('.trailer-box').slideDown(300);
    	$('body,html').animate({
    		scrollTop:0
    	},1000)
    })     
    $('.close-trl').on('click',function(){
    	$('.trailer-box').slideUp(300);
    	$('.trailer-box iframe').attr('src',$('.trailer-box iframe').attr('src'))
    })  
});