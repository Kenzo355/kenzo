<?php

if (isset($_GET["sercat"])) {
    echo "\n  <section class=\"MasterArchiveSection loadFilter ArcArc\">\n       <ul class=\"sercat\">\n        ";
    foreach (get_categories(["taxonomy" => "sercat", "hide_empty" => 0]) as $sercat) {
        echo "           <li><a href=\"";
        echo get_term_link($obj);
        echo "?sercat=";
        echo $sercat->slug;
        echo "\">";
        echo $sercat->name;
        echo "</a></li>\n        ";
    }
    echo "      </ul>\n      <div class=\"archiveTitle\">\n        ";
    $name = $_GET["sercat"] == "all" ? "احدث  المسلسلات" : str_replace("-", " ", $_GET["sercat"]);
    echo "        <h1>";
    echo $name;
    echo "</h1>\n      </div>\n   \n      <div class=\"MasterLoadMore allBlocks\" data-loading=\"false\">\n        ";
    $offset = isset($_GET["offset"]) && $_GET["offset"] != 1 ? ($_GET["offset"] - 1) * 40 : 0;
    $args = ["taxonomy" => "series", "parent" => 0, "meta_key" => "time", "orderby" => "meta_value_num", "order" => "DESC", "meta_query" => [["key" => "sercat", "value" => $name, "compare" => "="]]];
    if ($_GET["sercat"] == "all") {
        $args = ["taxonomy" => "series", "hide_empty" => 0, "meta_key" => "time", "orderby" => "meta_value_num", "order" => "DESC", "parent" => 0];
    }

    (new ThemeContext())->TaxPagination($args);
    echo "      </div>\n  </section>\n      ";
  }



?>
