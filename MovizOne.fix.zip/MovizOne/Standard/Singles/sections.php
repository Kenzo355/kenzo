<?php

echo "\t";
wp_reset_query();
$PostsPerPage = 30;
$paged = isset($_GET["offset"]) ? $_GET["offset"] : 1;
$args = ["post_type" => "post", "paged" => $paged, "posts_per_page" => $PostsPerPage, "fields" => "ids", "tax_query" => ["relation" => "AND"]];
if (get_post_meta($post->ID, "filteringby", true) == "imdb") {
    $args["orderby"] = "meta_value_num";
    $args["meta_key"] = "imdbRating";
} else {
    if (get_post_meta($post->ID, "filteringby", true) == "views") {
        $args["orderby"] = "meta_value_num";
        $args["meta_key"] = "views";
    } else {
        if (get_post_meta($post->ID, "filteringby", true) == "ratings") {
            $args["orderby"] = "meta_value_num";
            $args["meta_key"] = "ratings_average";
        } else {
            if (get_post_meta($post->ID, "filteringby", true) == "pin") {
                $args["meta_key"] = "pin";
            }
        }
    }
}
if (get_post_meta($post->ID, "category", 1) != "") {
    $args["cat"] = get_post_meta($post->ID, "category", 1);
}
if (get_post_meta($post->ID, "series", true) != "") {
    $args["tax_query"][] = ["taxonomy" => "series", "terms" => get_post_meta($post->ID, "series", true), "field" => "term_id", "include_children" => true, "operator" => "IN"];
}
if (get_post_meta($post->ID, "movseries", true) != "") {
    $args["tax_query"][] = ["taxonomy" => "movseries", "terms" => get_post_meta($post->ID, "movseries", true), "field" => "term_id", "include_children" => true, "operator" => "IN"];
}
if (get_post_meta($post->ID, "genre", true) != "") {
    $args["tax_query"][] = ["taxonomy" => "genre", "terms" => get_post_meta($post->ID, "genre", true), "field" => "term_id", "include_children" => true, "operator" => "IN"];
}
if (get_post_meta($post->ID, "quality", true) != "") {
    $args["tax_query"][] = ["taxonomy" => "quality", "terms" => get_post_meta($post->ID, "quality", true), "field" => "term_id", "include_children" => true, "operator" => "IN"];
}
if (get_post_meta($post->ID, "language", true) != "") {
    $args["tax_query"][] = ["taxonomy" => "language", "terms" => get_post_meta($post->ID, "language", true), "field" => "term_id", "include_children" => true, "operator" => "IN"];
}
echo "<section class=\"MasterArchiveSection loadFilter\" >\n  <div class=\"SectionTitle\">\n\t  <div class=\"container\">\n\t    <h2>\n\t      <span>";
echo $post->post_title;
echo "</span>\n\t      <span>";
echo get_post_meta($post->ID, "desc", 1);
echo "</span>\n\t    </h2>\n\t  </div>\n\t</div>\n\t<div class=\"MasterLoadMore allBlocks\" data-loading=\"false\">\n\t\t";
global $wp_rewrite;
$wp_query = new WP_Query();
$wp_query->query($args);
while ($wp_query->have_posts()) {
    $wp_query->the_post();
    echo "      \t\t";
    $this->filmBlock($post);
    echo "      ";
}
echo "      <div class=\"pagination\">\n      \t ";
$this->ArchivePagination($wp_query, $wp_rewrite);
echo "      </div>\n\t</div>\n</section>\n\n";

?>