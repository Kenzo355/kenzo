<?php

wp_reset_query();
$instance = new ThemeContext();
$title = get_the_title();
$link = get_the_permalink();
$is_logged = is_user_logged_in() ? true : false;
$categories = get_the_terms($post->ID, "category", "");
$series = get_the_terms($post->ID, "series", "");
$movseries = get_the_terms($post->ID, "movseries", "");
$genres = get_the_terms($post->ID, "genre", "");
$qualities = get_the_terms($post->ID, "quality", "");
$years = get_the_terms($post->ID, "release-year", "");
$countries = get_the_terms($post->ID, "country", "");
$ages = get_the_terms($post->ID, "mpaa", "");
$directors = get_the_terms($post->ID, "director", "");
$actors = get_the_terms($post->ID, "actor", "");
$writers = get_the_terms($post->ID, "writers", "");
$tags = get_the_terms($post->ID, "post_tag", "");
$series_slug = $instance->series_slug($post);
$thumb = get_the_post_thumbnail_url();
$trailer = get_post_meta($post->ID, "Trailer", 1);
$number = get_post_meta($post->ID, "number", 1);
$film = $number == "" ? " لفيلم " : " المسلسل";
$servers = $instance->get_server(get_post_meta($post->ID, "servers", 1));
$newServers = $instance->get_new_server(get_post_meta($post->ID, "watchlist", true));
$downloads = get_post_meta($post->ID, "downloads", 1);
$download_links_list = $instance->get_down_server(get_post_meta($post->ID, "downloadslist", true));
$cls = get_query_var("watch", false) !== false ? "novideo" : "";
$delimiter = "<i class=\"fal fa-chevron-left\"></i>";
$moshahda = get_post_meta($post->ID, "moshahda", true);
$runtime = get_post_meta($post->ID, "runtime", 1);
$imdb_id = get_post_meta($post->ID, "imdb_id", 1);
$imdb_rate = get_post_meta($post->ID, "imdbRating", 1);
$ribbon = get_post_meta($post->ID, "ribbon", 1);
if ($is_logged) {
    $subscribes = (int) get_user_meta(wp_get_current_user()->ID, "subscribes", 1);
}
$mpaa_title = "مستوي المشاهدة  :";
$actor_title = "بطولة : ";
$writer_ttile = "كتابة : ";
$director_title = "اخراج : ";
$year_title = "موعد الصدور  :";
$quality_title = $number == "" ? "جودة الفيلم : " : "جودة الحلقات : ";
$lang_title = $number != "" ? "لغة المسلسل : " : "لغة الفيلم : ";
$country_title = $number != "" ? "دولة المسلسل : " : "دولة الفيلم : ";
$runtime_title = $number == "" ? "توقيت الفيلم : " : " توقيت الحلقات : ";
$instance->post_schema($post->ID);
foreach (is_array($series) ? $series : [] as $s) {
    $Schema = "serie";
    if (0 < $s->parent) {
        $HasSeasons = true;
        $SerieID = $s->parent;
        $CurrentSeason = $s->term_id;
    }
    if (isset($serie->parent) && $serie->parent == 0) {
        $CurrentSeries = $s->term_id;
    }
}
if (!empty($series)) {
    foreach ($series as $ser) {
        if ($ser->parent == 0) {
            if (!get_categories(["taxonomy" => "series", "parent" => $ser->term_id])) {
                $slug = $ser->slug;
                $sername = $ser->name;
                $serslug = $ser->slug;
                $serID = $ser->term_id;
                $fullName = "المسلسل كامل";
            }
        } else {
            $slug = $ser->slug;
            $sername = $ser->name;
            $serslug = $ser->slug;
            $serID = $ser->term_id;
            $fullName = "الموسم كامل";
        }
    }
}
$showbutton = false;
echo "<div class=\"overlaypost\"><div></div></div>";
if ($trailer != "") {
    echo "<div class=\"trailer-box trailer-box222\" data-id=\"" . $post->ID . "\">";
    echo "<span class=\"close-trl\"><i class=\"fal fa-times\"></i></span></div>";
}
echo "<div class=\"vidCont " . $cls . "\">";
if (get_query_var("watch", false) !== false) {
    echo " <div class=\"DownloadSection\">";
    if (get_option("vieon") == "yes") {
        echo "<div class=\"loadedIframe\"><div class=\"downloadBottun\"><i class=\"fas fa-play\"></i><span>اضغط هنا للمشاهدة </span></div>";
        echo "<div class=\"IMGBGSERVERS\" data-style=\"background-image: url(" . $thumb . ")\"></div>";
        echo "</div>";
        echo "<div class=\"ButtonSkip\" data-id=\"" . $post->ID . "\"><span>تخطي الاعلان  </span>";
        echo "<div class=\"InnerCount\"></div> <i class=\"fas fa-step-forward\"></i></div>";
    } else {
        echo "<div class=\"WatchServersMain\"><div class=\"MainContentNAjax\"><div class=\"loadAjaxInfo\"><div class=\"serverCont\"><section class=\"rightmaininfo\"><div class=\"list\"><div class=\"active\" data-id=\"\"><i class=\"fal fa-play\"></i><span>سيرفرات المشاهدة والتحميل</span></div>";
        if (!empty($series)) {

        }
        echo "</div><section class=\"divsCont\" ><ul class=\"WatchServers\" id=\"wch\">";
                if (!empty($newServers)) {
            $i = 0;
            foreach ($newServers as $post_server) {
                echo "<li class=\"serverItem " . ($i == 0 ? "active" : "") . "\" data-id=\"" . $post->ID . "\" data-server=\"" . $post_server["link"] . "\""  . "\" />" . $post_server["name"] . "</li> ";
                $i++;
            }
        } else {
            if (!empty($servers)) {
                foreach ($servers as $post_server) {
                    echo "<li class=\"serverItem\" data-id=\"" . $post->ID . "\" data-server=\"" . $post_server["link"] . "\">" . $post_server["name"] . "</li>  ";
                }
            }
        }
        if (function_exists("get_field") && get_field("servers")) {
            foreach (array_reverse(get_field("servers")) as $server) {
                if (get_field("servers")["name" . $K] != "") {
                    echo "<li class=\"serverItem\" data-server=\"" . get_field("servers")["server" . $K] . "\">";
                    echo "<i class=\"fal fa-video\"></i>";
                    echo get_field("servers")["name" . $K];
                    echo "<noscript style=\"display: none\">";
                    echo get_field("servers")["server" . $K];
                    echo "</noscript></li>";
                }
                $K++;
            }
        }

        echo "</ul>";

        wp_reset_query();
        ?>
        <div class="downloadBTN"><i class="fa fa-download"></i><span>سيرفرات التحميل</span> </div>
<?php
        echo "<div id=\"dwn\">";
        $servS = false;
        wp_reset_postdata();
        $hasServers = [];
        foreach (get_posts(["posts_per_page" => -1, "fields" => "ids", "post_type" => "download_servers", "meta_key" => "server_num", "orderby" => "meta_value", "order" => "ASC"]) as $post) {
            $server = get_post_meta($post, "download_server_" . get_the_ID(), true);
            if (!empty($server)) {
                $hasServers[] = get_the_ID();
            }
        }
        wp_reset_postdata();
        if (1 < count($hasServers)) {
            $servS = true;
        }
        if (isset(explode("moshahda.online/", $moshahda)[1])) {
            list($code) = explode(".html", explode("moshahda.online/", $moshahda)[1]);
        }
        if (isset($code)) {
            echo "<div class=\"specialDownload\"><div class=\"linksTukSpecial\">";
            echo "<a href=\"https://moshahda.online/" . $code . ".html?download_o\" target=\"_blank\">";
            echo "<i class=\"fa fa-star\"></i><span>Original</span><span>الجودة الاصلية</span></a>";
            echo "<a href=\"https://moshahda.online/" . $code . ".html?download_n\" target=\"_blank\">";
            echo "<i class=\"fa fa-star\"></i><span>480p</span><span>الجودة  المتوسطة</span></a>";
            echo "<a href=\"https://moshahda.online/" . $code . ".html?download_l\" target=\"_blank\">";
            echo "<i class=\"fa fa-star\"></i><span>360p</span><span>الجودة الضعيفة</span></a></div></div>";
        }
        echo "<div>";

        $downs = get_option("dwn");
        $arrayDowns = [];
        foreach ($downs as $ddd) {
            $arrayDowns[$ddd["oldname"]] = $ddd["newname"];
        }
       if(!empty(get_post_meta( $post->ID, 'downloadslist' ,1 ))){
           foreach(GetDownLoadServer(get_post_meta( $post->ID, 'downloadslist',1 )) as $key => $download){
                echo "<a target=\"_blank\" href=\"" . $download["link"] . "\" class=\"btn download_btn col-md-1\"><i class=\"fas fa-cloud-download\"></i>"; ?>
                <em><?= $download['name'] ?></em></a>
        <?php         echo "</a>";
            }
        }
        $l = 1;
        if (function_exists("get_fields") && get_field("downloads")) {
            foreach (get_field("downloads") as $server) {
                if (get_field("downloads")["name" . $l] != "") {
                    echo "<a class=\"btn download_btn col-md-1\" target=\"_blank\" href=\"" . get_field("downloads")["server" . $l] . "\"><i class=\"fas fa-cloud-download\"></i>" . get_field("downloads")["name" . $l] . "</a>";
                }
                $l++;
            }
        }
        wp_reset_postdata();
        echo "</div></div></section></section>";
        echo "<div id=\"EmbedCode\" " . (empty($number) ? "style=\"border-radius: 25px!important\"" : "") . ">";
        echo "<div class=\"iframeHolder " . ($number !== "" ? "epframe" : "") . "\">";
        if (!empty($newServers)) {
            foreach (array_slice($newServers, 0, 1) as $server) {
                echo get_option("videoAds");
            }
        }
        echo "</div>";
        echo "</div>";
        wp_reset_postdata();

        if (!empty($series)) {
            echo "<div class=\"edee\"><ul class=\"episodes-list\">";
            foreach ($series as $term) {
                if ($term->parent == 0) {
                    $childs = get_categories(["taxonomy" => "series", "parent" => $term->term_id, "hide_empty" => 0]);
                } else {
                    $termID = $term->term_id;
                }
            }
            if (!empty($childs)) {
                echo "<div class=\"seasonlist\"><i class=\"fa fa-chevron-down\"></i><span>اختر الموسم</span></div><div class=\"seasons\">";
                foreach ($childs as $ch) {
                    echo "<span class=\"" . ($ch->term_id == $termID ? "active" : "") . "\" data-slug=\"" . $ch->slug . "\">" . $ch->name . "</span>";
                }
                echo "</div>";
            }
            echo "<div class=\"active\">";
            $id = get_the_ID();
            foreach (get_posts(["post_type" => "post", "posts_per_page" => -1, "series" => $slug, "fields" => "ids"]) as $post) {
                echo "<li data-id=\"" . $post . "\" style=\"order:" . (int) get_post_meta($post, "number", 1) . "\" class=\"" . ($post == $id ? "active" : "") . "\"><a href=\"" . get_the_permalink($post) . "watch\"><span>الحلقة</span>" . get_post_meta($post, "number", 1) . "</a></li>";
            }
            echo "</div>";
            wp_reset_postdata();
            echo "</ul></div>";
        }
         echo "</div>";



        if (!empty($series)) {
            echo "<div class=\"nextAndPrvEpisodes\">";
            wp_reset_query();
            $currntepisode = $number;
            $prev = $number - 1;
            $args = ["post_type" => "post", "posts_per_page" => "1", "series" => $series_slug, "fields" => "ids", "meta_query" => [["key" => "number", "value" => $prev, "compare" => "="]]];
            if (get_posts($args) && 0 < $prev) {
                foreach (get_posts($args) as $previd) {
                    echo "<a class=\"prevep\" data-id=\"" . $previd . "\" href=\"" . get_the_permalink($previd) . "watch\">\n\t\t\t\t\t\t\t\t\t\t\t    \t<p>مشاهدة و تحميل الحلقة " . get_post_meta($previd, "number", 1) . "</p>\n\t\t\t\t\t\t\t\t\t\t\t    \t<span class=\"numep\">" . get_post_meta($previd, "number", 1) . "</span>\n\n\t\t\t\t\t\t\t\t\t\t\t    \t<span class=\"eptitle\">الحلقة السابقة</span>\n\t\t\t\t\t\t\t\t\t\t    \t</a>";
                }
            echo "<div class=\"youwatchnow\"> <p><span>تشاهد الان</span>الحلقة رقم " . $number . "</p></div>";
            wp_reset_query();
            $next = (int) ($currntepisode + 1);
            $args = ["post_type" => "post", "posts_per_page" => "1", "series" => $series_slug, "fields" => "ids", "meta_query" => [["key" => "number", "value" => $next, "compare" => "="]]];
            if (get_posts($args)) {
                foreach (get_posts($args) as $nextid) {
                    echo "<a class=\"nextep\" data-id=\"" . $nextid . "\" href=\"" . get_the_permalink($nextid) . "watch\">\n\t\t\t\t\t\t\t\t\t\t\t    \t<p>مشاهدة و تحميل الحلقة " . get_post_meta($nextid, "number", 1) . "</p>\n\t\t\t\t\t\t\t\t\t\t\t    \t<span class=\"numep\">" . get_post_meta($nextid, "number", 1) . "</span>\n\t\t\t\t\t\t\t\t\t\t\t    \t<span class=\"eptitle\">الحلقة التالية</span>\n\t\t\t\t\t\t\t\t\t\t    \t</a>";
                }
            }

                wp_reset_query();
            }
            echo "</div>";
        }
        echo "</div></div>";
        wp_reset_postdata();
        echo "</div></div>";
    }
}

echo "</div><section class=\"single\"><div class=\"contaner\"><div class=\"MainSingle\"><div class=\"left\"><div class=\"image\">";
if (!empty($ribbon)) {
    echo "<div class=\"reboon\">" . $ribbon . "</div>";
}
echo "<img data-src2=\"" . $thumb . "\">";
if (wp_is_mobile()) {
    echo "<a href=\"" . $link . "watch\" class=\"watchMob\"><i  class=\"fa fa-play\"></i></a>";
}
echo "</div><div class=\"somInfo somesingleinfo\">";

echo "<div class=\"imdbBox\"><i class=\"fa fa-star\"></i>";
echo "<span><a target=\"_blank\" href=\"https://www.imdb.com/title/" . $imdb_id . "\">IMDB</a></span>";
echo $imdb_rate;
echo "</div></div></div><div class=\"MasterSingleMeta\">";
echo "<h1 class=\"post-title\"><a href=\"" . $link . "\">" . $title . "</a></h1>";
echo "<div class=\"breadcrumbs\"><div class=\"breadcrumb clearfix\"><div id=\"mpbreadcrumbs\"><span>";
echo "<a  href=\"" . home_url() . "\">";
echo "<span>الرئيسية</span></a></span>";
echo $delimiter;
echo "<span>";
echo "<a  href=\"" . get_term_link($categories[0]) . "\">";
echo "<span>" . $categories[0]->name . "</span>";
echo "</a></span>";
if (!empty($series)) {
    foreach ($series as $ser) {
        echo $delimiter;
        if ($ser->parent == 0) {
            echo "<span>";
            echo "<a  href=\"" . get_term_link($ser) . "\">";
            echo "<span>" . $ser->name . "</span>";
            echo "</a></span>";
        }
    }
    foreach ($series as $ser) {
        echo $delimiter;
        if ($ser->parent != 0) {
            echo "<span>";
            echo "<a  href=\"" . get_term_link($ser) . "\">";
            echo "<span>" . $ser->name . "</span>";
            echo "</a></span>";
        }
    }
}
echo $delimiter;
echo "<span>";
echo "<a  href=\"" . get_the_permalink() . "\">";
echo "<span>" . $title . "</span>";
echo "</a></span></div></div></div>";
if (get_post_meta($post->ID, "story", 1) != "") {
    echo "<div class=\"story\">";
    echo "<p>" . get_post_meta($post->ID, "story", 1) . "</p>";
    echo "</div>";
}
wp_reset_query();
echo "<div class=\"MediaQueryRight\"><div class=\"catssection\">";
$instance->listTax("الانواع", $post->ID, "genre");
$instance->listTax("التصنيفات", $post->ID, "category");
if (get_the_terms($post->ID, "channel", "")) {
    $ch = [];
    foreach (get_the_terms($post->ID, "channel", "") as $term) {
        $ch[] = $term->term_id;
    }
    foreach (get_terms(["taxonomy" => "channel", "include" => $ch]) as $net) {
        echo "<li><a href=\"" . get_term_link($net) . "\">" . $net->name . "</a></li>";
    }
}
echo "</div>";
if (wp_is_mobile()) {
    echo "<div class=\"right\">";
    echo "<a class=\"watchAndDownlaod\" href=\"" . $link . "watch\">";
    echo "<i class=\"fa fa-play\"></i><span>مشاهدة و تحميل</span></a>
    ";
    if (!empty($series)) {
        foreach ($series as $ser) {
            if (get_term_meta($ser->term_id, "downloads", 1) != "") {
                echo "<div class=\"alertdownfullseries\"><a  href=\"" . get_term_link($ser) . "\">  تحميل  " . $ser->name . " كاملا برابط واحد </a></div>";
            }
        }
    }
    echo "</div>";
}
echo "<ul class=\"RightTaxContent\">";
$instance->rightList($runtime_title, $post->ID, "runtime", "fal fa-history", false);
$instance->rightList($country_title, $post->ID, "nation", "fa fa-flag");
$instance->rightList($year_title, $post->ID, "release-year", "fa fa-calendar");
$instance->rightList($actor_title, $post->ID, "actor", "fa fa-users");
$instance->rightList($writer_ttile, $post->ID, "writers", "fa fa-users");
$instance->rightList($director_title, $post->ID, "director", "fa fa-users");
$instance->rightList($quality_title, $post->ID, "quality", "fa fa-play");
$instance->rightList($lang_title, $post->ID, "language", "fa fa-language");
$instance->rightList($mpaa_title, $post->ID, "mpaa", "fa fa-check-double");
echo "</ul><article><div class=\"ContentContent\">";
echo strip_tags(get_the_content());
echo "</div></article><ul class=\"tags\">";
$instance->listTax("وسوم", $post->ID, "post_tag");
echo "</ul></div><div class=\"MediaQueryLeft\">";
if (!wp_is_mobile()) {
    echo "<div class=\"right\">";
    echo "<a class=\"watchAndDownlaod\" href=\"" . $link . "watch\">";
    echo "<i class=\"fa fa-play\"></i><span>مشاهدة و تحميل</span></a><div class=\"trl\" style=\"display:none\"><i class=\"fa fa-play\"></i><span>الاعلان</span></div>";
if(!empty(get_the_terms( $currentID, 'series' ))){ ?>
<?php if(count(get_the_terms( $currentID, 'series' )) > 1){ ?>
<?php foreach (get_the_terms($post->ID, 'series', '') as $season) { ?>
<?php if( $season->parent == 0 ) { ?>
<?php $parent = $season->term_id; ?>
<?php } ?>
<?php } ?>
<?php $series = is_array(get_the_terms( get_the_ID(), 'series' , '' )) ? get_the_terms( get_the_ID(), 'series' , '' ) : array() ?>
<?php foreach (is_array(get_categories(array('taxonomy'=>'series', 'hide_empty'=>0, 'parent'=>$parent))) ? get_categories(array('taxonomy'=>'series','hide_empty'=>0, 'parent'=>$parent)) : array() as $season) { ?>
<?php if(in_array($season->term_id, wp_list_pluck( $series,'term_id' ))){ $currentSeason = $season->term_id; } ?>
<?php } ?>
<?php }else{ ?>
<?php $currentSeason = get_the_terms($post->ID, 'series', '')[0]->term_id; ?>
<?php } ?>
<?php $dowser = is_array(get_term_meta( $currentSeason, 'downloads', 1 )) ? get_term_meta( $currentSeason, 'downloads', 1 ) : [] ?>
<?php if($dowser){ ?>
<?php echo "<div class=\"alertdownfullseries\"><a  href=\"" . get_term_link($ser) . "\">  تحميل  " . $ser->name . " كاملا   </a></div>";

            }
        }
    }
    echo "</div>";

echo "</div></div></div>";
echo get_option("Poster") != "" ? "<center>" . get_option("Poster") . "</center>" : "";
echo "<div class=\"AdIsSkiped\"></div>";
echo get_option("Poster") != "" ? "<center>" . get_option("Poster") . "</center>" : "";
echo "</div><div class=\"BorderMaster\"></div></section>";
if (!empty($movseries)) {
    foreach ($movseries as $term) {
        $termslug = $term->slug;
    }
    echo "<div class=\"separator\">";
    echo "<img data-src=\"" . get_option("titleIcon")["url"] . "\" />";
    echo "</div><div class=\"container\"> <div class=\"MaltyFimls\"><div class=\"exploreTitle\"><h1>سلاسل الافلام</h1></div><ul class=\"masterUlIn\">";
    foreach (get_posts(["post_type" => "post", "movseries" => $termslug, "fields" => "ids", "posts_per_page" => -1]) as $post) {
        $instance->filmBlock($post);
    }
    wp_reset_query();
    echo "</ul></div></div>";
}



        if ($slug != "") {
echo "    <section class=\"tabs\">\n        <ul>\n          <li class=\"active\" data-class=\".allepcont\">الحلقات  [ ";
            echo count(get_posts(["post_type" => "post", "posts_per_page" => -1, "series" => $slug, "fields" => "ids"]));
            echo " ]</li>\n          ";
            if ($parent != 0) {
                echo "            <li data-class=\".otherseasons\">المواسم</li>\n          ";
            }

            echo "          ";
            echo "          </section>\n    <section class=\"tabContents\">\n      <section class=\"allepcont getMoreByScroll\" data-slug=\"";
            echo $slug;
            echo "\">\n          <div class=\"row\">\n            ";
             $args = ["post_type" => "post", "posts_per_page" => 50, "fields" => "ids", "series" => $slug, "meta_query" => [["key" => "number", "value" => "", "compare" => ">"]]];
            foreach (get_posts($args) as $post) {
                echo "                    <a href=\"";
                echo get_the_permalink($post);
                echo "\" style=\"order:-";
                echo get_post_meta($post, "number", 1);
                echo "\">\n                        <div class=\"image\">";
                echo get_the_post_thumbnail($post);
                echo "</div>\n                      <div class=\"ep-info\">\n                        <h2>";
                echo get_the_title($post);
                echo "</h2>\n                      </div>\n                      <div class=\"epnum\"><span>الحلقة</span>";
                echo get_post_meta($post, "number", 1);
                echo "</div>\n                    </a>\n                  ";
            }
            wp_reset_query();
            echo "          </div>\n      </section>\n      <section class=\"otherseasons\" style=\"display: none\">\n             <ul class=\"exploreBlocks1\">\n              ";
            $args = ["taxonomy" => "series", "hide_empty" => 0, "parent" => $parent];
            foreach (array_slice(get_categories($args), 0, 12) as $ser) {
                list($firstID) = get_posts(["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "series" => $ser->slug]);
                echo "<div class=\"MovieItem\">";

                echo "<a  href=\"" . get_term_link($ser) . "\">";
                echo "<div class=\"FrontBlock\">";
                echo "<img data-src=\"" . get_the_post_thumbnail_url($firstID) . "\">";
                echo "<div class=\"TitleBlock\">" . $ser->name . "</div>";
                echo "</div><div class=\"BackBlock\">";
                echo "<div class=\"ContentBlock\" title=\"قصة  " . $ser->name . "\" alt=\"قصة  " . $ser->name . "\">" . wp_trim_words($ser->description, 12, " [ .. ] ");
                echo "</div></div></a></div>";
            }
            echo "              <div class=\"clearfix\"></div>\n           </ul>\n      </section>\n      <section class=\"searchEpisodes\" style=\"display: none\">\n         <div class=\"searchepisode\">\n             <input type=\"number\" data-slug=\"";
            echo $obj->slug;
            echo "  \n        </ul>\n      </section>\n      <section class=\"otherser\" style=\"display: none\">\n          <ul class=\"exploreBlocks1\">\n              ";
            $id = $parent == 0 ? $id : $parent;
            $args = ["taxonomy" => "series", "hide_empty" => 0, "orderby" => "rand", "parent" => 0, "meta_query" => [["key" => "sercat", "value" => get_term_meta($id, "sercat", 1), "compare" => "="]]];
            foreach (array_slice(get_categories($args), 0, 12) as $ser) {
                list($firstID) = get_posts(["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "series" => $ser->slug]);
                echo "<div class=\"MovieItem\">";

                echo "<a  href=\"" . get_term_link($ser) . "\">";
                echo "<div class=\"FrontBlock\">";
                echo "<img data-src=\"" . get_the_post_thumbnail_url($firstID) . "\">";
                echo "<div class=\"TitleBlock\">" . $ser->name . "</div>";
                echo "</div><div class=\"BackBlock\">";
                echo "<div class=\"ContentBlock\" title=\"قصة  " . $ser->name . "\" alt=\"قصة  " . $ser->name . "\">" . wp_trim_words($ser->description, 12, " [ .. ] ");
                echo "</div></div></a></div>";
            }
            echo "              <div class=\"clearfix\"></div>\n           </ul>\n      </section>\n    </section>\n  ";



        }




echo "<div class=\"separator\">";
echo "<img data-src=\"" . get_option("titleIcon")["url"] . "\" />";
echo "</div>";
wp_reset_query();
echo "<div class=\"HomeSlider\"> <span class=\"title\">مشاهدة عروض اخري</span><div class=\"sliderCont\"><span class=\"next\"><i class=\"fa fa-chevron-right\"></i></span><span class=\"prev\"><i class=\"fa fa-chevron-left\"></i></span><ul class=\"SlidesList owl-carousel owl-theme\">";
foreach (get_posts(["post_type" => "post", "posts_per_page" => 15, "fields" => "ids" , $tax => $slug , "cat" => $categories[0]->term_id, "orderby" => "rand"]) as $post) {
    $instance->sectionBlock($post);
}
wp_reset_query();
echo "</ul></div></div>";

?>
