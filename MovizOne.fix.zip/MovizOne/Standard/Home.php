<?php

if (!wp_is_mobile()) {
    $nums = get_option("homeslidenums") != "" ? get_option("homeslidenums") : 10;
    echo "<div class=\"HomeSlider\"> <div class=\"sliderCont\"><span class=\"next\"><i class=\"fal fa-chevron-right\"></i></span><span class=\"prev\"><i class=\"fal fa-chevron-left\"></i></span><ul class=\"SlidesList owl-carousel owl-theme\">";
    foreach (get_posts(["post_type" => "post", "posts_per_page" => $nums, "meta_key" => "pin", "fields" => "ids"]) as $post) {
        (new ThemeContext())->sliderBlock($post);
    }
    wp_reset_query();

}

echo "</div></div><div class=\"Sections\">";
 ?>


<div class="container">
<div class="filterTabs">
<div class="titleArea">
<div class="icon"></div>
<span>المضاف حديثاََ</span>
</div>

<div style="clear: both;"></div>
</div>


	<?php if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } elseif ( get_query_var('page') ) {  $paged = get_query_var('page');  } else { $paged = $_GET['page']; } ?>
		<?php query_posts( [ "post_type" => "post" , "paged" => $paged , "posts_per_page" => 42 , "meta_query" => array(array("key" => "dont_show_home" , "compare" => "NOT EXISTS")) ] ); ?>
		<?php while(have_posts()){ the_post(); ?>
			<?php
			 (new ThemeContext())->sectionBlock($post);
			?>
		<?php } ?>
	</div>

<?php


echo "</div></div>";
?>
<div class="ArchivePagination">
<?php	$prev_arrow = is_rtl() ? '→' : '←';
$next_arrow = is_rtl() ? '←' : '→';
global $wp_query, $wp_rewrite;
$pag = (empty($paged) || $paged == 0) ? 1 : $paged; $pag = $pag -1;
$ArchivePagination = array(
 'base' => @add_query_arg('paged','%#%'),
 'format' => '',
  'current' => (empty($paged)) ? 1 : $paged,
 'show_all' => false,
 'type' => 'list',

);
echo paginate_links( $ArchivePagination );

?>
</div>
