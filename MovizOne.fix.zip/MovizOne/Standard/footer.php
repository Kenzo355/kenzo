<?php

echo "<section class=\"searchFilter\"><div class=\"container\"><div class=\"catsfilter\" data-class=\"category\">";
(new ThemeContext())->Filter("category", " التصنيف");
echo "</div><div class=\"genrefilter\" data-class=\"genre\">";
(new ThemeContext())->Filter("genre", " النوع");
echo "</div><div class=\"yearfilter\" data-class=\"release-year\">";
(new ThemeContext())->Filter("release-year", "  العام");
echo "</div><div class=\"Qulaityfilter\" data-class=\"quality\">";
(new ThemeContext())->Filter("quality", "  الجودة");
echo "</div><div class=\"nationfilter\" data-class=\"nation\">";
(new ThemeContext())->Filter("nation", "  الدولة");
echo "</div><div class=\"mpaafilter\" data-class=\"mpaa\">";
(new ThemeContext())->Filter("mpaa", "  التصنيف العمري");
echo "</div>";
echo "<form method=\"GET\" action=\"" . home_url() . "/advsearch\">";
echo "<input type=\"hidden\" name=\"cat\" /><input type=\"hidden\" name=\"yr\" /><input type=\"hidden\" name=\"qlty\" /><input type=\"hidden\" name=\"ntn\" /><input type=\"hidden\" name=\"gnr\" /><input type=\"hidden\" name=\"mpa\" /><button><i class=\"fa fa-search\"></i></button></form></div></section><section class=\"allOptions\">";
if (wp_is_mobile()) {
    echo "<div class=\"container\">";
    (new ThemeContext())->optionTax("category", "catsfilter", "اختر التصنيف");
    (new ThemeContext())->optionTax("genre", "genrefilter", "اختر النوع");
    (new ThemeContext())->optionTax("release-year", "yearfilter", "اختر  العام");
    (new ThemeContext())->optionTax("quality", "Qulaityfilter", "اختر  الجودة");
    (new ThemeContext())->optionTax("nation", "nationfilter", "اختر  الدولة");
    (new ThemeContext())->optionTax("mpaa", "mpaafilter", "اختر  التصنيف العمري");
    echo "</div><div class=\"startSearchNow\">ابدأ البحث  الان</div>";
}
echo "</section><div class=\"footerTop\"><div class=\"container clearfix\"><div class=\"footerLogo\">";
echo "<img src=\"" . get_option("logo")["url"] . "\">";
echo "</div>";
echo "<div class=\"shares SocialIcons forfooter\">\n\t\t\t<ul>\n\t\t\t\t<li class=\"social-facebook\"><a href=\"" . get_option("facebook") . "\" target=\"_blank\"><i class=\"fab fa-facebook-f\"></i></a> </li>\n\t\t\t\t<li class=\"social-twitter\"> <a href=\"" . get_option("twitter") . "\" target=\"_blank\"> <i class=\"fab fa-twitter\"></i></a> </li>\n\t\t\t\t<li class=\"social-google\"> <a href=\"" . get_option("telegram") . "\"> <i class=\"fab fa-telegram-plane\"></i></a> </li>\n\t\t\t</ul>\n  \t\t</div>";
echo "</div></div><div class=\"FooterMenu\"><div class=\"container\"><div class=\"right\"><h2>روابط ممكن تهمك</h2> ";
wp_nav_menu(["theme_location" => "footer-menu", "menu_class" => "", "echo" => true, "fallback_cb" => "wp_page_menu", "before" => "", "after" => "", "link_before" => "", "link_after" => "", "items_wrap" => "<ul class=\"mainMneu2\" id=\"%1\$s\" class=\"%2\$s\">%3\$s</ul>", "depth" => 0, "walker" => ""]);


echo get_option("footer");
echo "<script src=\"https://code.jquery.com/jquery-3.5.1.min.js\"></script>\n<script type=\"text/javascript\">\n";
require get_template_directory() . "/Standard/UI/js/owl.carousel.min.js";
echo "\n\n\tvar ThemeUri  = '";
echo get_template_directory_uri();
echo "';\n\tvar adminAjax = '";
echo admin_url("admin-ajax.php");
echo "';\n\tvar HomeURL   = '";
echo home_url();
echo "';\n\tvar ISUserLoggedIN = false;\n\t";
if (is_user_logged_in()) {
    global $current_user;
    echo "var ISUserLoggedIN = true;";
    echo "var CurrentUserDisplayName = \"" . $current_user->display_name . "\";";
    echo "var CurrentUserEmail = \"" . $current_user->user_email . "\";";
}
echo "\n\t";
if (is_home()) {
    echo " \n\t\tvar homePage = true; \n\t";
} else {
    echo "\t\tvar homePage = false; \n\t";
}
echo "\t";
if (is_single()) {
    echo " \n\t\tvar singlePage  = true; \n\t\tvar postID  = '";
    echo get_the_ID();
    echo "';\n\t\tvar vieon = '";
    echo get_option("vieon");
    echo "';\n\t\tvar SeccondSkip = '";
    echo get_option("SeccondSkip") != "" ? get_option("SeccondSkip") : 5;
    echo "';\n\t\tvar youtubead = \$('noscript.youtubead').html();\n\t";
} else {
    echo "\t\tvar singlePage  = false; \n\t";
}
echo "\t";
if (is_page()) {
    echo " \n\t\tvar Page  = true; \n\t";
} else {
    echo " \n\t\tvar Page  = false; \n\t";
}
echo "\t";
if (is_archive()) {
    echo " \n\t\tvar archivePage = true; \n\t";
} else {
    echo "\t var archivePage = false;  \n\t";
}
echo "\t";
if (wp_is_mobile()) {
    echo " \n\t\tvar mobile = true; \n\t";
} else {
    echo "\t var mobile = false;  \n\t";
}
echo "\t";
$iframe = get_option("youtubead");
if ($iframe != "") {
    list($src) = explode("src=\"", $iframe);
    list($src) = explode("\"", $src);
    echo "\t\t\tvar srcIfram = '";
    echo $src;
    echo "';\n\t\t\tvar srcIframFound = true;\n\t\t";
} else {
    echo "\t\t\tvar srcIframFound = false;\n\t\t";
}
echo "\t\t\n\t\t";
if (!is_home()) {
    require get_template_directory() . "/Standard/UI/js/jquery.youtube-background.js";
}
echo "\t\t";
require get_template_directory() . "/Standard/UI/js/ycscript.js";
echo "\t\t\n\n</script>\n<style type=\"text/css\">\n.pagination li.Separator {\n\tbackground: #36373a;\n\tvertical-align: top;\n\tpadding: 5px 13px;\n\tborder-radius: 3px;\n\tmargin-top: 0px; \n\t} \n\t.pagination li {vertical-align: top; }\n   .pagination li.show + li.show + li {display: inline-block !important; }\n</style>\n\n";
if (!ISPageSpeed()) {
    wp_footer();
}

echo "</main></body></html>";
?>
<footer>
		<div class="Copyrights">
			جميع الحقوق محفوظة <a href="<?=home_url()?>"><? bloginfo('name'); ?></a>
			<a href="javascript:void(0);" onclick="$('body, html').animate({'scrollTop':0});" class="ScrollToTop"><i class="fa fa-angle-up"></i></a>
		</div>
</div>
</footer>
