<?php

global $wp;
echo "<!DOCTYPE html><html dir=\"rtl\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
if (get_query_var("watch", false) !== false) {
    echo "<meta name=\"robots\" content=\"noindex, nofollow\">";
}
echo "<meta name=\"google-site-verification\" content=\"G2W3qE0NOkVoHkBuLNSCOoDN2f3genuYNjvBPGRe0kA\" />";
if (isset(get_option("favicon")["url"])) {
    echo "<link rel=\"shortcut icon\" type=\"image/png\" href=\"" . get_option("favicon")["url"] . "\">";
}
echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0,user-scalable=0\" >";
(new ThemeContext())->Meta();
if (!ISPageSpeed()) {
    wp_head();
    (new ThemeContext())->theme_fonts();
}
echo "<style>";
if (!ISPageSpeed()) {
    require get_template_directory() . "/Standard/UI/css/fonts.css";
}
require get_template_directory() . "/style.css";
echo "</style></head><body><main class=\"bodycontainer\">";
if (wp_is_mobile()) {
    echo "<div class=\"logocenter logoMob\">";
    echo "<a href=\"" . home_url() . "\">";
    if (get_option("logo")) {
        echo "<img src=\"" . get_option("logo")["url"] . "\" title=\"" . get_bloginfo("name") . "\" alt=\"" . get_bloginfo("name") . "\">";
    }
    echo "</a></div>";
}
echo "<div class=\"headerTop\"><div class=\"container\"><div class=\"registerInfo\">";

echo "</div>";
if (!wp_is_mobile()) {
    echo "<div class=\"logocenter\">";
    echo "<a href=\"" . home_url() . "\">";
    if (get_option("logo")) {
        echo "<img src=\"" . get_option("logo")["url"] . "\" title=\"" . get_bloginfo("name") . "\" alt=\"" . get_bloginfo("name") . "\">";
    }
    echo "</a></div>";
}

echo "</div></div></div><div class=\"fixed-header\"><div class=\"container\">";
if (wp_is_mobile()) {
    echo "<div class=\"MenuToggle\"><div class=\"hamburger hamburger--slider js-hamburger\"><div class=\"hamburger-box\"><div class=\"hamburger-inner\"></div></div></div></div>";
}
echo "<div class=\"fixedSearch\">";
echo "<form action=\"" . home_url() . "\"  method=\"GET\">";
echo "<input autocomplete=\"off\" id=\"searchAuto\" type=\"text\" name=\"s\" placeholder=\"أبحث في موفيز وان\"><div id=\"SearchListResult\" style=\"display: none;\"><div id=\"SearchInnerList\"></div></div><button type=\"submit\"><i class=\"fa fa-search\"></i></button></form></div>";

echo "<div class=\"menu-header\"><ul>";
foreach (get_categories(["taxonomy" => "category", "hide_empty" => 0, "parent" => 0]) as $cat) {
    if ($cat->term_id != 1) {
    }
}
echo "</ul>";
wp_nav_menu(["theme_location" => "main-menu", "menu" => "", "container" => "", "container_class" => "", "container_id" => "", "menu_class" => "", "menu_id" => "", "echo" => true, "fallback_cb" => "wp_page_menu", "before" => "", "after" => "", "link_before" => "", "link_after" => "", "items_wrap" => "<ul id = \"%1\$s\" class = \"%2\$s\">%3\$s</ul>", "depth" => 0, "walker" => ""]);
echo "</div></div></div>";
$pg = get_option("pageHome") ? get_option("pageHome") : "eg";
echo "<center>" . get_option("header") . "</center>";
?>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-8F80ZMDJYK"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-8F80ZMDJYK');
</script>
