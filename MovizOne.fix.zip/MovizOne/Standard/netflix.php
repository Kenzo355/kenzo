<?php

echo "\n";
if (wp_is_mobile()) {
    echo "    <div class=\"vidCont\">\n    <section class=\"netflixback\">\n     \n      ";
    $iframeId = "";
    $filmYoutube = false;
    $showbutton = "";
    foreach (get_posts(["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "channel" => $obj->slug, "meta_key" => "Trailer", "orderby" => "rand"]) as $post) {
        echo " <div class=\"trkBox\">الاعلان</div>";
        echo get_the_post_thumbnail($post);
        echo "<div class=\"trFrame\"><span>x</span>" . get_post_meta($post, "Trailer", 1) . "</div>";
        $id = $post;
        $link = get_the_permalink($post);
    }
    echo "    </section>\n    ";
    if ($filmYoutube && isset($id)) {
        echo "      <h1 class=\"myTile\">\n          ";
        echo get_the_title($id);
        echo "      </h1>\n      <div class=\"somInfo\">\n          ";
        if (is_user_logged_in()) {
            if (!in_array($id, (int) get_user_meta(wp_get_current_user()->ID, "later", 1))) {
                echo "<div class=\"addtomylist uselo\" data-id=\"" . $id . "\" data-user=\"" . wp_get_current_user()->ID . "\">\n                       <i class=\"fas fa-plus-circle\"></i>اضافة لقائمتي</div>";
            } else {
                echo "<div class=\"addtomylist uselo\" data-id=\"" . $id . "\" data-user=\"" . wp_get_current_user()->ID . "\">\n                       <i class=\"fas fa-check\"></i>في قائمتي</div>";
            }
        } else {
            echo " <div class=\"addtomylist notlogged\"> <div class=\"haveToRegister\">يجب تسجيل الدخول</div> <i class=\"fas fa-plus-circle\"></i>اضافة لقائمتي</div>";
        }
        echo "          <div class=\"drt\">\n            <span>مده العرض</span>\n            <p>";
        echo get_post_meta($id, "runtime", 1);
        echo "</p>\n          </div>\n          <div class=\"imdbBox\">\n            <span>IMDB</span>\n            ";
        echo get_post_meta($id, "imdbRating", 1);
        echo "          </div>\n          <div class=\"watchMovie\">\n            <a href=\"";
        echo $link;
        echo "\"> <i class=\"far fa-play\"></i> شاهد الان مجانا\n          </a>\n        </div>\n      </div>\n      ";
    }
    echo "  </div>\n  ";
    $like = "";
    $dislike = "";
    echo "  ";
    if (isset($_COOKIE["like" . $id])) {
        $like = "likeColor";
    }
    echo "  ";
    if (isset($_COOKIE["disliked" . $id])) {
        $dislike = "dislikeColor";
    }
    echo "  ";
    if ($filmYoutube && isset($id)) {
        echo "    \n  <section class=\"filmbar\">\n      <div class=\"container\">\n          <ul class=\"randButtons\">\n            <li class=\"like\" id=\"";
        echo $like;
        echo "\" data-id=\"";
        echo $id;
        echo "\"><strong>";
        echo (int) get_post_meta($id, "like", 1);
        echo "</strong><i class=\"fal fa-thumbs-up\"></i></li>\n            <li class=\"dislike\" id=\"";
        echo $dislike;
        echo "\" data-id=\"";
        echo $id;
        echo "\"><strong>";
        echo (int) get_post_meta($id, "disliked", 1);
        echo "</strong><i class=\"fal fa-thumbs-down\"></i></li>\n             <li class=\"next\" data-id=\"";
        echo $id;
        echo "\" data-slug=\"";
        echo $obj->slug;
        echo "\"><i class=\"fal fa-forward\"></i>ضربة حظ</li>\n         \n          </ul>\n      </div>\n  </section>\n  ";
    }
    echo "\n";
} else {
    echo "  <div class=\"vidCont\">\n    <section class=\"netflixback\">\n          ";
    $iframeId = "";
    $filmYoutube = false;
    $showbutton = "";
    if (get_term_meta($obj->term_id, "url", 1)) {
        list($iframeId) = explode("?v=", get_term_meta($obj->term_id, "url", 1));
        $filmYoutube = true;
    } else {
        $filmYoutube = true;
        $args = ["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "channel" => $obj->slug, "meta_key" => "Trailer", "orderby" => "rand"];
        foreach (get_posts($args) as $post) {
            if (get_post_meta($post, "Trailer", 1) != "") {
                preg_match("/src=\"([^\"]+)\"/", get_post_meta($post, "Trailer", 1), $match);
                list($iframeId) = explode("embed/", $match[1]);
                $showbutton = true;
            }
            $id = $post;
            $link = get_the_permalink($post);
        }
    }
    if ($iframeId != "") {
        echo "              <div id=\"ytbg\" data-ytbg-mute-button=\"true\" data-ytbg-play-button=\"true\" data-ytbg-fade-in=\"true\" data-youtube=\"https://www.youtube.com/watch?v=";
        echo $iframeId;
        echo "\"></div>\n          ";
    } else {
        echo get_the_post_thumbnail($post);
    }
    echo "    </section>\n    ";
    if ($filmYoutube && isset($id)) {
        echo "      <h1 class=\"myTile\">\n          ";
        echo get_the_title($id);
        echo "      </h1>\n      <div class=\"somInfo for-normal-archive\">\n          ";
        if (is_user_logged_in()) {
            if (!in_array($id, (int) get_user_meta(wp_get_current_user()->ID, "later", 1))) {
                echo "<div class=\"addtomylist uselo\" data-id=\"" . $id . "\" data-user=\"" . wp_get_current_user()->ID . "\">\n                       <i class=\"fas fa-plus-circle\"></i>اضافة لقائمتي</div>";
            } else {
                echo "<div class=\"addtomylist uselo\" data-id=\"" . $id . "\" data-user=\"" . wp_get_current_user()->ID . "\">\n                       <i class=\"fas fa-check\"></i>في قائمتي</div>";
            }
        } else {
            echo " <div class=\"addtomylist notlogged\"> <div class=\"haveToRegister\">يجب تسجيل الدخول</div> <i class=\"fas fa-plus-circle\"></i>اضافة لقائمتي</div>";
        }
        echo "          <div class=\"drt\">\n            <span>مده العرض</span>\n            <p>";
        echo get_post_meta($id, "runtime", 1);
        echo "</p>\n          </div>\n          <div class=\"imdbBox\">\n            <span>IMDB</span>\n            ";
        echo get_post_meta($id, "imdbRating", 1);
        echo "          </div>\n          <div class=\"watchMovie\">\n            <a href=\"";
        echo $link;
        echo "\"> <i class=\"far fa-play\"></i> شاهد الان مجانا\n          </a>\n        </div>\n      </div>\n      ";
    }
    echo "  </div>\n  ";
    $like = "";
    $dislike = "";
    echo "  ";
    if (isset($_COOKIE["like" . $id])) {
        $like = "likeColor";
    }
    echo "  ";
    if (isset($_COOKIE["disliked" . $id])) {
        $dislike = "dislikeColor";
    }
    echo "  ";
    if ($filmYoutube && isset($id)) {
        echo "    \n  <section class=\"filmbar\">\n      <div class=\"container\">\n          <ul class=\"randButtons\">\n            ";
        if ($showbutton) {
            echo "              <li class=\"mute\"><i class=\"fas fa-volume\"></i></li>\n              <li class=\"pause\"><i class=\"far fa-pause\"></i></li>\n              <li class=\"showandhide\"><i class=\"fas fa-eye-slash\"></i></li>\n            ";
        }
        echo "            <li class=\"like\" id=\"";
        echo $like;
        echo "\" data-id=\"";
        echo $id;
        echo "\"><strong>";
        echo (int) get_post_meta($id, "like", 1);
        echo "</strong><i class=\"fal fa-thumbs-up\"></i></li>\n            <li class=\"dislike\" id=\"";
        echo $dislike;
        echo "\" data-id=\"";
        echo $id;
        echo "\"><strong>";
        echo (int) get_post_meta($id, "disliked", 1);
        echo "</strong><i class=\"fal fa-thumbs-down\"></i></li>\n             <li class=\"next\" data-id=\"";
        echo $id;
        echo "\" data-slug=\"";
        echo $obj->slug;
        echo "\"><i class=\"fal fa-forward\"></i>ضربة حظ</li>\n         \n          </ul>\n      </div>\n  </section>\n  ";
    }
    echo "\n";
}
echo "\n<section class=\"netflexInfo\">\n  <div class=\"container\">\n    <div class=\"netflexLogo\">\n      ";
if (get_term_meta($obj->term_id, "logo", 1)) {
    echo "          <img src=\"";
    echo get_term_meta($obj->term_id, "logo", 1);
    echo "\">\n        ";
} else {
    echo "          <img src=\"";
    echo get_option("netflexlogo")["url"];
    echo "\">\n      ";
}
echo "    </div>\n    <div class=\"netTitle\">\n      ";
if (is_user_logged_in()) {
    echo "        ";
    if (in_array($obj->term_id, (int) get_user_meta(wp_get_current_user()->ID, "follow", 1))) {
        echo "          <span class=\"followTax muselo clicked\" data-user=\"";
        echo wp_get_current_user()->ID;
        echo "\" data-id=\"";
        echo $obj->term_id;
        echo "\">تمت المتابعه</span>\n          ";
    } else {
        echo "          <span class=\"followTax muselo\" data-user=\"";
        echo wp_get_current_user()->ID;
        echo "\" data-id=\"";
        echo $obj->term_id;
        echo "\">متابعه</span>\n        ";
    }
    echo "      ";
} else {
    echo "      <span class=\"followTax notlog\"><div class=\"haveToRegister2\">يجب تسجيل الدخول</div>متابعه</span>\n      ";
}
echo "      ";
echo $obj->name;
echo "    </div>\n    <ul class=\"boxNum\">\n      <li>\n          <span>";
echo $obj->count;
echo "</span>\n          <span>موضوع</span>\n      </li>\n        \n    </ul>\n    <div class=\"linksnet\">\n        ";
if (get_categories(["taxonomy" => "channel", "parent" => $obj->term_id, "hide_empty" => 0])) {
    echo "            ";
    foreach (get_categories(["taxonomy" => "channel", "parent" => $obj->term_id, "hide_empty" => 0]) as $links) {
        echo "              <a href=\"";
        echo get_term_link($links);
        echo "\">";
        echo $links->name;
        echo "</a>\n            ";
    }
    echo "        ";
}
echo "    </div>\n  </div>\n</section>\n\n<section class=\"MasterArchiveSection loadFilter\" >\n     <ul class=\"sercat\">\n        ";
foreach (get_categories(["taxonomy" => "sercat", "hide_empty" => 0]) as $sercat) {
    echo "           <li><a href=\"";
    echo home_url();
    echo "/category/مسلسلات/?sercat=";
    echo $sercat->slug;
    echo "\">";
    echo $sercat->name;
    echo "</a></li>\n        ";
}
echo "      </ul>\n    <div class=\"SectionTitle\">\n    <div class=\"MasterLoadMore allBlocks\" data-loading=\"false\">\n        ";
if (get_term_meta($obj->term_id, "loadNetFlixSeries", 1) == "yes") {
    $offset = isset($_GET["offset"]) && $_GET["offset"] != 1 ? ($_GET["offset"] - 1) * 40 : 0;
    $args = ["taxonomy" => "series", "hide_empty" => 0, "meta_query" => [["key" => "netflex", "value" => "on", "compare" => "="]]];
    $series = array_slice(get_categories($args), $offset, 40);
    foreach ($series as $ser) {
        $firstID = get_posts(["post_type" => "post", "fields" => "ids", "posts_per_page" => 1, "ignore_sticky_posts" => 1, "series" => $ser->slug]);
        $firstID = $firstID[0];
        $imgSrc = wp_get_attachment_url(get_post_thumbnail_id($firstID));
        echo "\n              <div class=\"MovieItem\">\n                <a title=\"";
        echo $ser->name;
        echo "\" href=\"";
        echo get_term_link($ser);
        echo "\">\n                  <div class=\"FrontBlock\">\n                        ";
        if (get_term_meta($ser->term_id, "image", 1)) {
            echo "                          <img src=\"";
            echo get_term_meta($ser->term_id, "image", 1);
            echo "\">\n                        ";
        } else {
            echo "                          <img src=\"";
            echo $imgSrc;
            echo "\">\n                        ";
        }
        echo " \n                    <div class=\"TitleBlock\">";
        echo $ser->name;
        echo "</div>\n                  </div>\n                  <div class=\"BackBlock\">\n                    <ul class=\"BarBlock\">\n                        ";
        $rate = get_post_meta($firstID, "imdbRating", true);
        if (!empty($rate)) {
            echo "                            <li class=\"category\" title=\"\" data-herf=\"\">\n                              <i class=\"fas fa-star\"></i><span>";
            echo get_post_meta($firstID, "imdbRating", true);
            echo "</span>\n                            </li>   \n                        ";
        }
        echo "                      ";
        if (get_the_terms($firstID, "genre", "")) {
            echo "                        ";
            foreach (array_slice(is_array(get_the_terms($firstID, "genre", "")) ? get_the_terms($firstID, "genre", "") : araay(), 0, 1) as $genre) {
                echo "                            <li class=\"category two\" title=\"";
                echo $genre->name;
                echo "\" data-herf=\"";
                echo get_term_link($genre);
                echo "\">\n                              <i class=\"fas fa-star\"><span>";
                echo $genre->name;
                echo "</span></i>\n                            </li>\n                        ";
            }
            echo "                      ";
        }
        echo "                    </ul>\n                    <div class=\"ContentBlock\" title=\"قصة  ";
        echo $ser->name;
        echo "\" alt=\"قصة  ";
        echo $ser->name;
        echo "\">";
        echo wp_trim_words(get_the_content(), 12, " [ .. ] ");
        echo "</div>\n                  </div>\n                </a>\n             \n              </div>\n          ";
    }
    (new ThemeContext())->TaxPagination($args);
} else {
    if (get_term_meta($obj->term_id, "loadFullSeries", 1) == "yes") {
        $offset = isset($_GET["offset"]) && $_GET["offset"] != 1 ? ($_GET["offset"] - 1) * 40 : 0;
        $args = ["taxonomy" => "series", "hide_empty" => 0, "meta_query" => [["key" => "full", "value" => "on", "compare" => "="]]];
        $series = array_slice(get_categories($args), $offset, 40);
        foreach ($series as $ser) {
            $firstID = get_posts(["post_type" => "post", "fields" => "ids", "posts_per_page" => 1, "ignore_sticky_posts" => 1, "series" => $ser->slug]);
            $firstID = $firstID[0];
            $imgSrc = wp_get_attachment_url(get_post_thumbnail_id($firstID));
            echo "\n              <div class=\"MovieItem\">\n                <a title=\"";
            echo $ser->name;
            echo "\" href=\"";
            echo get_term_link($ser);
            echo "\">\n                  <div class=\"FrontBlock\">\n                        ";
            if (get_term_meta($ser->term_id, "image", 1)) {
                echo "                          <img src=\"";
                echo get_term_meta($ser->term_id, "image", 1);
                echo "\">\n                        ";
            } else {
                echo "                          <img src=\"";
                echo $imgSrc;
                echo "\">\n                        ";
            }
            echo " \n                    <div class=\"TitleBlock\">";
            echo $ser->name;
            echo "</div>\n                  </div>\n                  <div class=\"BackBlock\">\n                    <ul class=\"BarBlock\">\n                        ";
            $rate = get_post_meta($firstID, "imdbRating", true);
            if (!empty($rate)) {
                echo "                            <li class=\"category\" title=\"\" data-herf=\"\">\n                              <i class=\"fas fa-star\"></i><span>";
                echo get_post_meta($firstID, "imdbRating", true);
                echo "</span>\n                            </li>   \n                        ";
            }
            echo "                      ";
            if (get_the_terms($firstID, "genre", "")) {
                echo "                        ";
                foreach (array_slice(is_array(get_the_terms($firstID, "genre", "")) ? get_the_terms($firstID, "genre", "") : araay(), 0, 1) as $genre) {
                    echo "                            <li class=\"category two\" title=\"";
                    echo $genre->name;
                    echo "\" data-herf=\"";
                    echo get_term_link($genre);
                    echo "\">\n                              <i class=\"fas fa-star\"><span>";
                    echo $genre->name;
                    echo "</span></i>\n                            </li>\n                        ";
                }
                echo "                      ";
            }
            echo "                    </ul>\n                    <div class=\"ContentBlock\" title=\"قصة  ";
            echo $ser->name;
            echo "\" alt=\"قصة  ";
            echo $ser->name;
            echo "\">";
            echo wp_trim_words(get_the_content(), 12, " [ .. ] ");
            echo "</div>\n                  </div>\n                </a>\n              </div>\n              ";
        }
        (new ThemeContext())->TaxPagination($args);
    } else {
        if (have_posts()) {
            while (have_posts()) {
                the_post();
                (new ThemeContext())->filmBlock($post->ID);
            }
        }
        echo "<div class=\"pagination\">";
        (new ThemeContext())->oldArchive();
        echo "</div>";
    }
}
echo "   \n    </div>\n</section>\n\n<section class=\"exploresection\"><div class=\"container\">";
if (!is_user_logged_in()) {
    echo "<div class=\"exploreTitle\"><h1>اكتشف عالم الافلام و المسلسلات</h1>";
    echo "<h2>اشترك الان و ابدأ عالمك الخاص  ..  <a href=\"" . home_url() . "/register\">اشترك الان</a> </h2>";
    echo "</div>";
} else {
    echo "<div class=\"exploreTitle\"><h1>قنوات اخري</h1><h2>شاهد المزيد من القنوات .. </h2></div>";
}
echo "<ul class=\"exploreBlocks\">";
$offset = isset($_GET["offset"]) && $_GET["offset"] != 1 ? ($_GET["offset"] - 1) * 40 : 0;
$args = ["taxonomy" => "channel", "hide_empty" => 0, "meta_query" => [["key" => "hide", "value" => "on", "compare" => "!="]]];
foreach (array_slice(get_categories($args), $offset, 40) as $net) {
    (new ThemeContext())->exploreBlock($net);
}
(new ThemeContext())->TaxPagination($args);
echo "<div class=\"clearfix\"></div></ul></div></section>";

?>
