<?php

wp_reset_query();
$instance = new ThemeContext();
if ($obj->parent == 0) {
    foreach (get_categories(["taxonomy" => "series", "parent" => $obj->term_id]) as $s) {
        $sluggg = $s->slug;
    }
} else {
    $sluggg = $obj->slug;
}
$parent_title = $obj->parent != 0 ? get_term_by("term_id", $obj->parent, "series")->name : "";
$title = $parent_title . " " . $obj->name;
$link = get_term_link($obj);
list($post_id) = get_posts(["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "series" => $obj->slug]);
$imdb_id = get_post_meta($post_id, "imdb_id", 1);
$imdb_rate = get_post_meta($post_id, "imdbRating", 1);
$childs = get_categories(["taxonomy" => "series", "parent" => $obj->term_id]);
$story = get_post_meta($post_id, "story", 1);
$is_logged = is_user_logged_in() ? true : false;
$categories = get_the_terms($post_id, "category", "");
$genres = get_the_terms($post_id, "genre", "");
$qualities = get_the_terms($post_id, "quality", "");
$years = get_the_terms($post_id, "release-year", "");
$countries = get_the_terms($post_id, "country", "");
$ages = get_the_terms($post_id, "mpaa", "");
$directors = get_the_terms($post_id, "director", "");
$actors = get_the_terms($post_id, "actor", "");
$writers = get_the_terms($post_id, "writers", "");
$thumb = get_term_meta($obj->term_id, "image ", 1) != "" ? get_term_meta($obj->term_id, "image ", 1) : get_the_post_thumbnail_url($post_id);
$ribbon = get_post_meta($post_id, "ribbon", 1);
if (get_term_meta($obj->term_id, "url", 1) != "") {
    list($trailer) = explode("v=", get_term_meta($obj->term_id, "url", 1));
    $trailer = "<iframe width=\"1126\" height=\"633\" src=\"https://www.youtube.com/embed/" . $trailer . "\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>";
} else {
    $trailer = get_post_meta($post_id, "Trailer", 1);
}
$number = get_post_meta($post_id, "number", 1);
$delimiter = "<i class=\"fal fa-chevron-left\"></i>";
$mpaa_title = "مستوي المشاهدة  :";
$actor_title = "بطولة : ";
$writer_ttile = "كتابة : ";
$director_title = "اخراج : ";
$year_title = "موعد الصدور  :";
$quality_title = "جودة الحلقات : ";
$lang_title = "لغة المسلسل : ";
$country_title = "دولة المسلسل  : ";
$runtime_title = " توقيت الحلقات : ";
$delimiter = "<i class=\"fal fa-chevron-left\"></i>";
if ($trailer != "") {
    echo "<div class=\"trailer-box\"><span class=\"close-trl\"><i class=\"fal fa-times\"></i></span>";
    echo $trailer;
    echo "</div>";
}
echo "<section class=\"single\"><div class=\"contaner\"><div class=\"MainSingle\"><div class=\"left\"><div class=\"image\">";
if (!empty($ribbon)) {
    echo "<div class=\"reboon\">" . $ribbon . "</div>";
}
echo "<img src=\"" . $thumb . "\">";
if ($trailer) {
    echo "<div class=\"trl icon\"><i class=\"fa fa-play\"></i><span>مشاهدة الاعلان</span></div>";
}
echo "</div><div class=\"somInfo flex-start somesingleinfo\">";

echo "<div class=\"imdbBox\"><i class=\"fa fa-star\"></i>";
echo "<span><a target=\"_blank\" href=\"https://www.imdb.com/title/" . $imdb_id . "\">IMDB</a></span>";
echo $imdb_rate;
echo "</div></div></div><div class=\"MasterSingleMeta\">";
echo "<h1 class=\"post-title\"><a href=\"" . $link . "\">" . $title . "</a></h1>";
echo "<div class=\"breadcrumbs\"><div class=\"breadcrumb clearfix\"><div id=\"mpbreadcrumbs\"><span>";
echo "<a  href=\"" . home_url() . "\">";
echo "<span>الرئيسية</span></a></span>";
if ($obj->parent != 0) {
    echo $delimiter;
    $parent = get_term_by("term_id", $obj->parent, "series");
    echo "<span>";
    echo "<a  href=\"" . get_term_link($parent) . "\">";
    echo "<span>" . $parent->name . "</span>";
    echo "</a></span>";
}
echo $delimiter;
echo "<span>";
echo "<a  href=\"" . $link . "\">";
echo "<span>" . $title . "</span>";
echo "</a></span></div></div></div><div class=\"story\">";
echo "<p>" . $story . "</p>";
echo "</div><div class=\"MediaQueryRight\"><div class=\"catssection\">";
$instance->listTax("الانواع", $post_id, "genre");
$instance->listTax("التصنيفات", $post_id, "category");
if (get_the_terms($post_id, "channel", "")) {
    $ch = [];
    foreach (get_the_terms($post_id, "channel", "") as $term) {
        $ch[] = $term->term_id;
    }
    foreach (get_terms(["taxonomy" => "channel", "include" => $ch]) as $net) {
        echo "<li><a href=\"" . get_term_link($net) . "\">" . $net->name . "</a></li>";
    }
}
echo "</div><ul class=\"RightTaxContent\">";
$instance->rightList($runtime_title, $post_id, "runtime", "fal fa-history", false);
$instance->rightList($country_title, $post_id, "nation", "fa fa-flag");
$instance->rightList($year_title, $post_id, "release-year", "fa fa-calendar");
$instance->rightList($actor_title, $post_id, "actor", "fa fa-users");
$instance->rightList($writer_ttile, $post_id, "writers", "fa fa-users");
$instance->rightList($director_title, $post_id, "director", "fa fa-users");
$instance->rightList($quality_title, $post_id, "quality", "fa fa-play");
$instance->rightList($lang_title, $post_id, "language", "fa fa-language");
$instance->rightList($mpaa_title, $post_id, "mpaa", "fa fa-check-double");
echo "</ul><article><div class=\"ContentContent\">";
echo $story;
echo "</div></article><ul class=\"tags\">";
$instance->listTax("وسوم", $post_id, "post_tag");
echo "</ul></div><div class=\"MediaQueryLeft\">";
if (get_term_meta($obj->term_id, "downloads", 1) != "") {
    echo "<div class=\"alertdownfullseries\"> تحميل  " . $obj->name . " كاملا برابط واحد </div>";
    echo "<h2 class=\"choose-link\"><i class=\"fa fa-info\"></i>اختار رابط واحد للتحميل</h2>";
    $currentID = $post->ID; ?>
<?php if(!empty(get_the_terms( $currentID, 'series' ))){ ?>
<?php if(count(get_the_terms( $currentID, 'series' )) > 1){ ?>
<?php foreach (get_the_terms($post->ID, 'series', '') as $season) { ?>
<?php if( $season->parent == 0 ) { ?>
<?php $parent = $season->term_id; ?>
<?php } ?>
<?php } ?>
<?php $series = is_array(get_the_terms( get_the_ID(), 'series' , '' )) ? get_the_terms( get_the_ID(), 'series' , '' ) : array() ?>
<?php    echo "<div class=\"links\">";
  foreach (is_array(get_categories(array('taxonomy'=>'series', 'hide_empty'=>0, 'parent'=>$parent))) ? get_categories(array('taxonomy'=>'series','hide_empty'=>0, 'parent'=>$parent)) : array() as $season) { ?>
  <?php if(in_array($season->term_id, wp_list_pluck( $series,'term_id' ))){ $currentSeason = $season->term_id; } ?>
<?php } ?>
<?php }else{ ?>
<?php $currentSeason = get_the_terms($post->ID, 'series', '')[0]->term_id; ?>
<?php } ?>
<?php $dowser = is_array(get_term_meta( $currentSeason, 'downloads', 1 )) ? get_term_meta( $currentSeason, 'downloads', 1 ) : [] ?>
<?php if (!empty($dowser)): ?>
<?php foreach(is_array(get_term_meta( $currentSeason, 'downloads', 1 )) ? get_term_meta( $currentSeason, 'downloads', 1 ) : [] as $downl){ ?>
<li><a rel="nofollow noopener" style="font-weight: 600;" target="_blank" href="<?=$downl['link'] ?>">
<em><?= $downl['name'] ?></em></a>
</li>
<?php } ?>
</ul>
</div>
<?php endif ?>
<?php
}

    echo "</div>";
}
echo "</div></div></div></div>";
echo get_option("Poster") != "" ? "<center>" . get_option("Poster") . "</center>" : "";
echo "<div class=\"AdIsSkiped\"></div>";
echo get_option("Poster") != "" ? "<center>" . get_option("Poster") . "</center>" : "";
echo "</div><div class=\"BorderMaster\"></div></section>";
echo "<div class=\"loadTabsInSeries\" data-slug=\"" . $sluggg . "\" data-parent=\"" . $obj->parent . "\" data-id=\"" . $obj->term_id . "\"></div>";














echo "    <section class=\"tabs\">\n        <ul>\n          <li class=\"active\" data-class=\".allepcont\">الحلقات   ";
  echo "</section>\n    <section class=\"tabContents\n ";
  echo "\">\n          <div class=\"row\">"
?>

    <?php wp_reset_query(); query_posts( array("post_type" => "post" , "posts_per_page" => -1 , "series" => get_the_terms( $post->ID, 'series' , '' )[0]->slug , 'meta_key' => 'number' , 'orderby' => 'meta_value_num' , 'order' => "DESC") ); ?>
    <?php while(have_posts()){ the_post(); ?>
      <?php
        echo "                    <a href=\"";
        echo get_the_permalink($post->ID == $currentID);
        echo "\" style=\"order:-";
        echo get_post_meta($currentID, "number", 1);
        echo "\">\n                        <div class=\"image\">";
        echo get_the_post_thumbnail($currentID);
        echo "</div>\n                      <div class=\"ep-info\">\n                        <h2>";
        echo get_the_title($currentID);
        echo "</h2>\n                      </div>\n                      <div class=\"epnum\"><span>الحلقة</span>";
        echo get_post_meta($post->ID, "number", 1);
        echo "</div>\n                    </a>\n                  ";
    }
    wp_reset_query();
    echo "</div>";



?>
