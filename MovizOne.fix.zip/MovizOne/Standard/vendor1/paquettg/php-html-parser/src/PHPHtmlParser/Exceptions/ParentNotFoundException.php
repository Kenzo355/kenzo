<?php
namespace PHPHtmlParser\Exceptions;

/**
 * Class ParentNotFoundException
 *
 * @package PHPHtmlParser\Exceptions
 */
final class ParentNotFoundException extends \Exception
{
}
