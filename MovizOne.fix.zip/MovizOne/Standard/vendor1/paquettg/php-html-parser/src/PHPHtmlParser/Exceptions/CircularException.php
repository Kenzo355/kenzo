<?php
namespace PHPHtmlParser\Exceptions;

/**
 * Class CircularException
 *
 * @package PHPHtmlParser\Exceptions
 */
final class CircularException extends \Exception
{
}
