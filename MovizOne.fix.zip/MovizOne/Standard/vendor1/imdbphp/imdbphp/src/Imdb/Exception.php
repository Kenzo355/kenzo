<?php

namespace Imdb;

/**
 * Exception thrown by the IMDbPHP library
 */
class Exception extends \Exception
{

}
