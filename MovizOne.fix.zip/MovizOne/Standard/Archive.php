<?php

ob_start();
wp_reset_query();
$obj = get_queried_object();
$schema_link = "";
$home = "الرئيسية";
$homeLink = home_url();
$delimiter = "<i class=\"fas fa-arrow-left\"></i>";

if ($obj->taxonomy == "series") {
        require get_template_directory() . "/Standard/series.php";
    } else {
{

            echo "<div class=\"archiveTitle\">";

            if (isset($_GET["taxcat"])) {
                global $wp;
                $url = home_url($wp->request) . "?taxcat=" . $_GET["taxcat"];
                echo "<div class=\"taxcat\" data-url=\"" . $url . "\"></div>";
                echo "<h1>مشاهدة و تحميل " . $_GET["taxcat"] . " " . $obj->name . "</h1>";
            } else {
                echo "<h1>مشاهدة و تحميل " . $_GET["taxcat"] . " " . $obj->name . "</h1>";
            }
            echo "</div>";

 echo "</div></div><div class=\"Sections\">";
 ?>

 <div class="MovieItemm">

           <?php                     if (have_posts()) {
                                    while (have_posts()) {
                                        the_post();
                                        $this->sectionBlock($post->ID);
                                    }
                                }

              ?>
               </div>

               <?php
               echo "</div></div>";
               ?>


           <div class="ArchivePagination">
      	<?php	$prev_arrow = is_rtl() ? '→' : '←';
      		$next_arrow = is_rtl() ? '←' : '→';
      		global $wp_query, $wp_rewrite;
      		$pag = (empty($paged) || $paged = 0) ? 1 : $paged; $pag = $pag -1;
      		$ArchivePagination = array(
      			'base' => @add_query_arg('paged','%#%'),
      			'format' => '',

      			'current' => (empty($page)) ? 1 : $page,
      			'show_all' => false,
      			'type' => 'list',

      		);
      		echo paginate_links( $ArchivePagination );
}}
      ?>
      </div>
