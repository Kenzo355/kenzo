<?php
	define('WP_USE_THEMES', false);
  $URI = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
  require_once( $URI[0] . 'wp-load.php' );
  require "../vendor1/autoload.php";
  use PHPHtmlParser\Dom;
$id = explode('-',$_GET['id']);
$code = $_GET['id'];
$lang = 'ar';
$metaData = [];
$dom = new Dom;
$dom->loadFromUrl('http://www.elcinema.com/'.$lang.'/work/'.$code.'/enrich');
if ($lang == 'ar') {
	$title = $dom->find('table.large-12',0)->find('tbody')->find('tr',0)->find('td',1)->find('span')->text;
}else{
	$title = $dom->find('table.large-12',0)->find('tbody')->find('tr',1)->find('td',1)->find('span')->text;	
}
$Rated = $dom->find('table.large-12',0)->find('tbody')->find('tr',11)->find('td',1)->text;
$rate = $dom->find('div [class=stars-rating-lg]')[0]->find('span.legend')[0]->text;
$year = explode(',', $dom->find('table.large-12')[0]->find('tbody')->find('tr')[4]->find('td')[1]->find('span')->text);
$runtime = $dom->find('table.large-12')[0]->find('tbody')->find('tr')[5]->find('td')[1]->find('span')->text;
$type = $dom->find('table.large-12')[0]->find('tbody')->find('tr')[6]->find('td')[1]->find('span')->text;
$Classification = $dom->find('table.large-12')[0]->find('tbody')->find('tr')[10]->find('td')[1]->text;
$releaseDate = 	$dom->find('table.large-12')[1]->find('tbody')->find('tr');
if(!is_null($releaseDate[0])){
	$releaseDate = $releaseDate[0]->find('td')[0]->find('a')[0]->text;
}

$genres = $dom->find('table.large-12')[2]->find('tbody')->find('tr');
$genre = [];
foreach ($genres as $key => $value) {
	$genre [] = $value->find('td')[0]->text;
}
//Start Get Cast Data   
$cast = $dom->find('#cast-actor')[0]->find('table.large-12')[0]->find('tbody')->find('tr');
$castAr = [];
foreach ($cast as $key => $value) {
	$castAr [] = $value->find('td')[1]->find('a')[1]->text;
}  
$writer = $dom->find('#cast-writer')[0]->find('table.large-12')[0]->find('tbody')->find('tr');
$writerA = [];
foreach ($writer as $key => $value) {
	$writerA [] = $value->find('td')[1]->find('a')[1]->text;
} 
$director = $dom->find('#cast-director')[0]->find('table.large-12')[0]->find('tbody')->find('tr');
$directorA = [];
foreach ($director as $key => $value) {
	$directorA [] = $value->find('td')[1]->find('a')[1]->text;
} 
$producer = $dom->find('#cast-producer')[0]->find('table.large-12')[0]->find('tbody')->find('tr');
$producerA = [];
foreach ($producer as $key => $value) {
	$producerA [] = $value->find('td')[1]->find('a')[1]->text;
}
if(!is_null($dom->find('div [class=boxed-3]')[2]->find('.large-12')[0]->find('tbody')[0]->find('tr')[0])){
    $story = $dom->find('div [class=boxed-3]')[2]->find('.large-12')[0]->find('tbody')[0]->find('tr')[0]->find('td')[1]->text;    
}else{
    $story = $title;
}
//Start Add To Array
$metaData['Title'] = $title;
$metaData['Year'] = $year;
$metaData['Rated'] = $Rated;
$metaData['Released'] = $releaseDate;
$metaData['Runtime'] = $runtime;
$metaData['Genre'] = $genre;
$metaData['Director'] = $directorA;
$metaData['Writer'] = $writerA;
$metaData['Actors'] = $castAr;
$metaData['Plot'] = $story;
$metaData['Language'] = $language;
$metaData['country'] = $countries;
$metaData['Poster'] = $poster;
$metaData['Ratings'] = $rate;
$metaData['Type'] = $type;
$metaData['Production'] = $producerA;
?>
<script>
$(document).ready(function(e) {
	$("#title").val('<?= str_replace("000", $title, "مشاهدة فيلم 000 ") ?>');
	$('#elcinemaRatings').val('<?php echo $metaData['eRate']; ?>');
	$('#elcinemaUrl').val('<?php echo "http://www.elcinema.com/work/".$_GET["id"]; ?>');
	$('#new-tag-actor').val('<?php echo implode(',',$metaData['Actors']) ?>');
	$('#new-tag-language').val('<?php echo $metaData['Language']; ?>');
	$('#released').val('<?php echo $metaData['Released']?>');
	$('#runtime').val('<?php echo $metaData['Runtime'] ?> دقيقة');
	$('#new-tag-director').val('<?php echo implode(',',$metaData['Director'])?>');
	$('#new-tag-escritor').val('<?php echo implode(',',$metaData['Writer'])?>');
	$('#new-tag-production').val('<?php echo implode(',', $metaData['Production'])?>');
	$('#new-tag-release-year').val('<?php echo implode(',', $metaData['Year'])?>');
	$('#new-tag-country').val('<?php echo $metaData['Country']?>');
	$('#new-tag-genre').val('<?php echo implode(',',$metaData['Genre']); ?>');
	$("#new-tag-post_tag").val('<?=$tags_scrape; ?>');
    $("#new-tag-post_tag").val('<?= str_replace("000", $title, " 000 كامل,  000  موفيز وان, 000  BeinCima, 000  موفيز وان, 000  موفيز 1, 000 كامل, 000 مشاهدة مباشره, 000 تحميل اون لاين, 000 تحميل مباشر,تحميل  000 موفيز وان") ?>');

});
</script>
