<?php
define('WP_USE_THEMES', false);
$URI = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $URI[0] . 'wp-load.php' );
require "../vendor1/autoload.php";
$code               = $_GET['id'];
$meta               = [];
$title              = new \Imdb\Title($code);
$meta['Awards']     = @array_keys(@$title->awards());
$meta['Plot']       = @$title->jsonLD()->description;
$meta['Language']   = @$title->languages();
$meta['Country']    = @$title->country();
$meta['Plot']       = @$title->Plot();
$meta['Poster']     = @$title->photo(TRUE);
$meta['Title']      = @$title->title();
$meta['Year']       = @$title->year();
$meta['Rated']      = @$title->rating();
$meta['Votes']      = @$title->votes();
$meta['Released']   = @$title->jsonLD()->datePublished;
$meta['Runtime']    = @$title->runtime();
$meta['Genre']      = @$title->genres();
$meta['Trailer']    = @$title->trailers(TRUE);
foreach(array_slice($meta['Trailer'], 0,1) as $t) {
  if(!empty($t['url'])) {
    $finalTrailer = $t['url'];
  }
}
$meta['Actors']     = @wp_list_pluck(@$title->cast(),'name');
$meta['Director']   = @wp_list_pluck(@$title->director(),'name');
$meta['Writer']     = @wp_list_pluck(@$title->writing(),'name');
$meta['Producer']   = @wp_list_pluck(@$title->producer(),'name');
$data = file_get_contents('https://yourcolor.net/newIMDb/api/movie.php?id='.$_GET['id'].'');
$data = json_decode($data);
$mpaa = $data->mpaa;
$data->poster;


		    
$image_url = $data->poster;
if (!empty($image_url)) {
    $upload_dir = wp_upload_dir();
    $image_data = wp_remote_fopen($image_url);
    $filename = basename($image_url);
    $filename = str_replace(".jpg", "-" . rand() . ".jpg", $filename);
    if (wp_mkdir_p($upload_dir["path"])) {
        $file = $upload_dir["path"] . "/" . $filename;
    } else {
        $file = $upload_dir["basedir"] . "/" . $filename;
    }
    file_put_contents($file, $image_data);
    $wp_filetype = wp_check_filetype($filename, NULL);
    $attachment = ["post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit"];
    $attach_id = wp_insert_attachment($attachment, $file, rand());
    require_once ABSPATH . "wp-admin/includes/image.php";
    $attach_data = wp_generate_attachment_metadata($attach_id, $file);
    wp_update_attachment_metadata($attach_id, $attach_data);
}
echo "    \$('#_thumbnail_id').val(\"";
echo $attach_id;
echo "\");\r\n    \$('#postimagediv .inside').prepend('<center><h1>تم تعيين صورة بارزة</h1></center>');\r\n    \$('#new-tag-genre').val(\"";


			    
			    
?>
<?
$langs = $meta['Language'];
$enLang = array('Afrikaans','Albanian','Arabic','Azerbaijani','Basque','Belarusian','Bengali','Bosnian','Bulgarian','Cantonese','Catalan','Chinese','Croatian','Czech','Danish','Dutch','English','Estonian','Filipino','Finnish','French','Georgian','German','Greek','Gujarati','Hebrew','Hindi','Hungarian','Icelandic','Indonesian','Irish','Italian','Japanese','Kazakh','Cambodian','Korean','Lao','Latin','Latvian','Lithuanian','Malay','Marathi','Mongolian','Nepali','Norwegian','Pashto','Persian','Polish','Portuguese','Punjabi','Romanian','Russian','Scottish Gaelic','Serbian','Slovak','Slovene','Somali','Spanish','Swahili','Swedish','Tagalog','Tamil','Telugu','Thai','Turkish','Ukrainian','Urdu','Uzbek','Vietnamese','Welsh','Zulu');
$arLang = array('الأفريكانية','الألبانية','العربية','الأذرية','الباسكية','البيلاروسية','البنغالية','البوسنية','البلغارية','الكانتونية','الكاتالونية','الصينية','الكرواتية','التشيكية','الدنماركية','الهولندية','الأنجليزية','الأستونية','الفلبينية','الفنلندية','الفرنسية','الجورجية','الألمانية','اليونانية','الغوجراتية','العبرية','الهندية','المجرية','الإيسلندية','الإندونيسية','الإيرلندية','الإيطالية','اليابانية','الكازاخية','الكمبودية','الكورية','اللاوية','اللاتينية','اللاتفية','الليتوانية','الملاوية','الماراثية','المنغولية','النيبالية','النرويجية','البشتونية','الفارسية','البولونية','البرتغالية','البنجابية','الرومانية','الروسية','الغالية السكوتلندية','الصربية','السلوفاكية','السلوفينية','الصومالية','الإسبانية','السواحيلية','السويدية','التغالوغ','التاميلية','التيلوغية','التايلندية','التركية','الأوكرانية','الأردو','الأوزبكية','الفيتنامية','الويلزية','الزولو');
foreach ($enLang as $k => $lang) {
  $langs = str_replace($lang, $arLang[$k], $langs);
}
$genres = $meta['Genre'];
$en = array('Action','Adventure','Music','Musical','Comedy','Drama','Documentary','Animation','Biography','Crime','Family','Fantasy','History','Horror','Mystery','Romance','Sci-Fi','Short','Sport','Superhero','Thriller','War','Western' );
$ar = array('اكشن','مغامرة','موسيقي','موسيقي','كوميدي','دراما','وثائقي','انيميشن','سيرة ذاتية','جريمة','عائلي','فانتازيا','تاريخي','رعب','غموض','رومانسي','خيال علمي','قصير','رياضي','خارقة','اثارة','حربي','ويسترن', );
foreach ($en as $k => $genre) {
  $genres = str_replace($genre, $ar[$k], $genres);
}
$arCountries = array('أفغانستان','ألبانيا','الجزائر','ساموا الأمريكي','أندورا','أنغولا','أنغويلا','أنتاركتيكا','أنتيغوا وبربودا','الأرجنتين','أرمينيا','أروبا','أستراليا','النمسا','أذرييجان','الباهاماس','البحرين','بنغلاديش','بربادوس','روسيا البيضاء','بلجيكا','بيليز','بنين','جزر برمود','بوتان','بوليفيا','البوسنة و الهرسك','بوتسوانا','البرازيل','بروناي','بلغاريا','بوركينا فاسو','بوروندي','كمبوديا','كاميرون','كندا','الرأس الأخضر','جمهورية أفريقيا الوسطى','تشاد','تشيلي','الصين','كولومبيا','جزر القمر','جزر كوك','كوستاريكا','كرواتيا','كوبا','قبرص','الجمهورية التشيكية','الدانمارك','جيبوتي','دومينيكا','الجمهورية الدومينيكية','تيمور الشرقية','إكوادور','مصر','إلسلفادور','غينيا الاستوائي','إريتريا','استونيا','أثيوبيا','جزر فوكلاند','جزر فارو','فيجي','فنلندا','فرنسا','غويانا الفرنسية','بولينيزيا الفرنسية','الغابون','غامبيا','جيورجيا','ألمانيا','غانا','اليونان','جرينلاند','غرينادا','جزر جوادلوب','غوام','غواتيمالا','غينيا','غينيا-بيساو','غيانا','هايتي','هندوراس','هونغ كونغ','المجر','آيسلندا','الهند','أندونيسيا','إيران','العراق','جمهورية أيرلندا','إسرائيل','إيطاليا','جمايكاs','اليابان','الأردن','كازاخستان','كينيا','كيريباتي','الكويت','قيرغيزستان','لاتفيا','لبنان','ليسوتو','ليبيا','ليختنشتين','لتوانيا','لوكسمبورغ','ماكاو','جمهورية مقدونيا','مدغشقر','مالاوي','ماليزيا','المالديف','مالي','مالطا','جزر مارشال','مارتينيك','موريتانيا','موريشيوس','المكسيك','ولايات ميكرونيسيا المتحدة','مولدافيا','موناكو','منغوليا','الجبل الأسو','مونتسيرات','المغرب','موزمبيق','ميانمار','ناميبيا','ناورو','نيبال','هولندا','كاليدونيا الجديدة','نيوزيلندا','نيكاراجوا','النيجر','نيجيريا','نييوي','كوريا الشمالية','جزر ماريانا الشمالية','النرويج','عمان','باكستان','بالاو','بنما','بابوا غينيا الجديدة','باراغواي','بيرو','الفليبين','بولندا','البرتغال','بورتوريكو','قطر','جمهورية الكونغو الديمقراطية','ريونيون','رومانيا','روسيا','رواندا','سانت كيتس كيتس','سانت لوسيا','سانت فنسنت وجزر غرينادين','ساموا','سان مارينو','ساو تومي وبرينسيبي','السنغال','جمهورية صربيا','سيشيل','تاون سيراليون','سنغافورة','سلوفاكيا','سلوفينيا','جزر سليمان','الصومال','جنوب أفريقيا','كوريا الجنوبية','جنوب السودان','إسبانيا','سريلانكا','السودان','سورينام','سوازيلند','السويد','سويسرا','سوريا','تايوان','طاجيكستان','تنزانيا','تايلندا','توغو','تونغا','ترينيداد وتوباغو','تونس','تركيا','تركمانستان','توفالو','أوغندا','أوكرانيا','الإمارات العربية المتحده','المملكة المتحدة','الولايات المتحدة الامريكية','أورغواي','أوزباكستان','فانواتو','دولة مدينة الفاتيكان','فنزويلا','فيتنام','والس وفوتونا','اليمن','زامبيا','زمبابوي');
$enCountries = array('Afghanistan','Albania','Algeria','American Samoa','Andorra','Angola','Anguilla','Antarctica','Antigua and Barbuda','Argentina','Armenia','Aruba','Australia','Austria','Azerbaijan','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgium','Belize','Benin','Bermuda','Bhutan','Bolivia','Bosnia and Herzegovina','Botswana','Brazil','Brunei','Bulgaria','Burkina Faso','Burundi','Cambodia','Cameroon','Canada','Cape Verde','Central African Republic','Chad','Chile','China','Colombia','Comoros','Cook Islands','Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Denmark','Djibouti','Dominica','Dominican Republic','East Timor','Ecuador','Egypt','El Salvador','Equatorial Guinea','Eritrea','Estonia','Ethiopia','Falkland Islands','Faroe Islands','Fiji','Finland','France','French Guiana','French Polynesia','Gabon','Gambia','Georgia','Germany','Ghana','Greece','Greenland','Grenada','Guadeloupe','Guam','Guatemala','Guinea','Guinea-Bissau','Guyana','Haiti','Honduras','Hong Kong','Hungary','Iceland','India','Indonesia','Iran','Iraq','Ireland','Israel','Italy','Jamaica','Japan','Jordan','Kazakhstan','Kenya','Kiribati','Kuwait','Kyrgyzstan','Latvia','Lebanon','Lesotho','Libya','Liechtenstein','Lithuania','Luxembourg','Macao','Macedonia','Madagascar','Malawi','Malaysia','Maldives','Mali','Malta','Marshall Islands','Martinique','Mauritania','Mauritius','Mexico','Micronesia','Moldova','Monaco','Mongolia','Montenegro','Montserrat','Morocco','Mozambique','Myanmar','Namibia','Nauru','Nepal','Netherlands','New Caledonia','New Zealand','Nicaragua','Niger','Nigeria','Niue','North Korea','Northern Mariana Islands','Norway','Oman','Pakistan','Palau','Panama','Papua New Guinea','Paraguay','Peru','Philippines','Poland','Portugal','Puerto Rico','Qatar','Republic of the Congo','Reunion','Romania','Russia','Rwanda','Saint Kitts and Nevis','Saint Lucia','Saint Vincent and the Grenadines','Samoa','San Marino','Sao Tome and Principe','Senegal','Serbia','Seychelles','Sierra Leone','Singapore','Slovakia','Slovenia','Solomon Islands','Somalia','South Africa','South Korea','South Sudan','Spain','Sri Lanka','Sudan','Suriname','Swaziland','Sweden','Switzerland','Syria','Taiwan','Tajikistan','Tanzania','Thailand','Togo','Tonga','Trinidad and Tobago','Tunisia','Turkey','Turkmenistan','Tuvalu','Uganda','Ukraine','United Arab Emirates','United Kingdom','USA','Uruguay','Uzbekistan','Vanuatu','Vatican','Venezuela','Vietnam','Wallis and Futuna','Yemen','Zambia','Zimbabwe');
$countries = $meta['Country'];
foreach ($enCountries as $k => $countr) {
  $countries = str_replace($countr, $arCountries[$k], $countries);
}
?>
<script>
  $(document).ready(function(e) {
    <? if(strtolower($Request["MainType"]) == "movie"){ ?>
    $("#title").val("مشاهدة مسلسل <?=$meta['Title']?> <?=$meta['Year']?> مترجم");
  <? } else{ ?>
    $("#title").val("مشاهدة  <?=$meta['Title']?> مترجم");
  <? } ?>
  
 
  
  
  
    $('#released').val('<?php echo $meta['Released']?>');
    $('#runtime').val('<?php echo $meta['Runtime']?> دقيقة');
    $('#imdbRating').val('<?php echo $meta['Rated']?>');
    $('#imdbVotes').val('<?php echo $meta['Votes']?>');
    $('#new-tag-actor, input[name=actor]').val('<?php echo str_replace("\"", "'", $data->cast , implode(',',$meta['Actors'])) ?>');
    $("#imdb_link").val('https://imdb.com/title/<?=$_GET['id']; ?>');
    $('#new-tag-language , input[name=language]').val('<?php echo implode(',',$langs); ?>');
  $('#new-tag-genre').val('<?php echo implode(',',$genres); ?>');
  $('#new-tag-director , input[name=director]').val('<?php echo str_replace("'", '`',implode(',',$meta['Director']))?>');
    $('#new-tag-escritor , input[name=escritor]').val('<?php echo str_replace("'", '`', implode(',',$meta['Writer']))?>');
    $('#new-tag-production , input[name=production]').val('<?php echo str_replace("'", '`', implode(',',$meta['Producer'])) ?>');
    $('#new-tag-release-year , input[name=year]').val('<?php echo $meta['Year']?>');
    $('#new-tag-country').val('<?php echo implode(',', $countries)?>');





    $('#age_meta').val('<?= $mpaa ?>');
    <? $name_YY = $meta["Title"] . " " . $meta["Year"] ?>
    <? if(strtolower($Request["MainType"]) == "movie"){ ?>
  <? } ?>
    $("#tags_scrape").val('');
    var $iframe = $('#content_ifr');
    $iframe.ready(function() {
      <? $content = $_GET['content'] ?>
      <? $content = str_replace('plot', $meta["Plot"], $content); ?>
      <?
      $tit = $_GET['title'];
      $content = str_replace('name', $meta['Title'], $content );
      $content = str_replace('year', $meta['Year'], $content );
      $content = str_replace("'", "`", $content);
    if(strtolower($Request["MainType"]) == "movie"){
$tyy = "مسلسل";
    }else{
$tyy = "";
    }

      ?>
      $iframe.contents().find("body").html("مشاهدة وتحميل  <?=$tyy?> <?=$meta["Title"] ?> <?=$meta["Year"] ?> مترجم  <?=$tyy?>  مترجم بجودة 1080p WEB-DL مشاهدة اون لاين وتحميل مباشر <?=$tyy?> <?=$meta["Title"] ?> <?=$meta["Year"] ?> مترجم اون لاين");
    });
    <? if($_GET['content2'] != ''){ ?>
      <? $Kenzo_content_texarea = $_GET['content2']; ?>
      <? $content = $_GET['content2'] ?>
      <? $content = str_replace('plot', $meta["Plot"], $content); ?>
      <? $content = str_replace('name', $tit, $content); ?>
      <? $content = str_replace('year', $meta['Year'], $content); ?>
    <? } ?>
    $("#plot_scrape").val('');
    $("#new-tag-post_tag").val('<?=$tags_scrape; ?>');

  });
</script>

