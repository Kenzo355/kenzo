<?php
require_once dirname( __FILE__ ) . '/init.php';
if ( file_exists( dirname( __FILE__ ) . '/cmb2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
}
require_once ('search-post.php');
function kenzo_show_if_front_page( $cmb ) {
	if ( $cmb->object_id !== get_option( 'page_on_front' )) {
		return false;
	}
	return true;
}
function kenzo_hide_if_no_cats( $field ) {
	if ( ! has_tag( 'cats', $field->object_id )) {
		return false;
	}
	return true;
}
function kenzo_before_row_if_2( $field_args, $field ) {
	if ( 2 == $field->object_id ) {
		echo '<p>Testing <b>"before_row"</b> parameter (on $post_id 2)</p>';
	} else {
		echo '<p>Testing <b>"before_row"</b> parameter (<b>NOT</b> on $post_id 2)</p>';
	}
}
add_action( 'cmb2_admin_init', 'kenzo_register_metabox' );
function kenzo_register_metabox() {
	$data_scr = new_cmb2_box(array(
		'id'           => 'datascrap',
		'title'        => __( 'سحب البيانات', 'kenzo' ),
		'object_types' => array( "post" ),
	));
	$data_scr->add_field( array(
		'name'        => __( 'سحب IMDB' ),
		'id'          => 'imdbID',
		'type'        => 'text',
	));
	$data_scr->add_field( array(
		'name'        => __( 'تصويتات IMDB' ),
		'id'          => 'imdbRating',
		'type'        => 'text',
	));
	$data_scr->add_field( array(
		'name'        => __( 'تصويتات IMDB' ),
		'id'          => 'imdbVotes',
		'type'        => 'text',
	));
	$data_scr->add_field( array(
		'name'        => __( 'رابط IMDB' ),
		'id'          => 'imdb_link',
		'type'        => 'text_url',
	));
	$data_scr->add_field( array(
		'name'        => __( 'سحب السينما دوت كوم' ),
		'id'          => 'ElcinemaIDTXT',
		'type'        => 'text',
	));
	$data_scr->add_field( array(
		'name'        => __( 'تصويتات السينما دوت كوم' ),
		'id'          => 'elcinemaRatings',
		'type'        => 'text',
	));
	$data_scr->add_field( array(
		'name'        => __( 'رابط السينما دوت كوم' ),
		'id'          => 'elcinemaUrl',
		'type'        => 'text_url',
	));
	/////////////////////////////////////////////////
	// Online Watch Servers
	/////////////////////////////////////////////////
	$watch_servers = new_cmb2_box(array(
		'id'           => 'watch_servers',
		'title'        => __( 'سيرفرات المشاهدة', 'kenzo' ),
		'object_types' => array( "post" ),
	));
	$watch_servers->add_field( array(
		'name'        => __( 'قائمه السيرفرات ' ),
		'id'          => 'watchlist',
		'type'        => 'textarea',
		'desc' 				=> 'ضع كل رابط فى سطر',
	));
	//////////////////////////////////////////////
	$new = new_cmb2_box(array(
		'id'           => 'download_ls',
		'title'        => __( 'سيرفرات التحميل', 'kenzo' ),
		'object_types' => array( 'post' ),
	));
	$new->add_field( array(
		'name'       => 'قائمه السيرفرات ',
		'id'         => 'downloadslist',
		'type'       => 'textarea',
	));
	/////////////////////////////////////////////////
	// Online Watch Servers
	/////////////////////////////////////////////////
	$sEmbdd = new_cmb2_box(array(
		'id'           => 'sEmbdd',
		'title'        => __( 'اعدادات السيرفر', 'kenzo' ),
		'object_types' => array( 'servers' ),
	));
	$sEmbdd->add_field( array(
		'name'       => 'كود التضمين',
		'id'         => 'serverEmbdd',
		'type'       => 'text_url',
	));
	$sEmbdd->add_field( array(
		'name'       => 'اخر رابط السيرفر',
		'id'         => 'server_end',
		'type'       => 'text',
	));
	$sEmbdd->add_field( array(
		'name'       => 'الجزء المقصوص',
		'id'         => 'serverCut',
		'type'       => 'text_url',
	));
	$cover = new_cmb2_box( array(
		'id'           => 'cover-metabox',
		'title'        => __( 'الخلفية' ),
		'object_types' => array( 'movie' ,'series' ,'season' , 'episode' , 'songs' , 'album' , 'singer' , 'assemblies' , 'game' , 'program' , 'show' , 'news' ),
	));
	$cover->add_field( array(
		'name'        => __( 'صورة الخلفية' ),
		'id'          => 'cover',
		'type'        => 'file',
	));
	/////////////////////////////////////////////////
	/////////////////////////////////////////////////
	$servvss = new_cmb2_box(array(
		'id'           => 'serOrd',
		'title'        => __( 'ترتيب السيرفر', 'kenzo' ),
		'object_types' => array( 'servers' , 'down_servers' ),
	));
	$servvss->add_field( array(
		'name'       => 'ترتيب السيرفر',
		'id'         => 'server_num',
		'type'       => 'text',
	));
	
	///////////////////////////////////////////////////////////////
	// Movie Meta Box
	///////////////////////////////////////////////////////////////
	$movie_option = new_cmb2_box( array(
		'id'           => 'movie-metabox',
		'title'        => __( 'اعدادات الفيلم' ),
		'object_types' => array( 'movie' ,'post' ),
	));
	$movie_option->add_field( array(
		'name'        => __( 'القصة' ),
		'id'          => 'story',
		'type'        => 'textarea',
	));
	$movie_option->add_field( array(
		'name'        => __( 'الملصق' ),
		'id'          => 'ribbon',
		'type'        => 'text',
	));
		$movie_option->add_field( array(
		'name'        => __( 'رقم الحلقة' ),
		'id'          => 'number',
		'type'        => 'text',
	));
	$movie_option->add_field( array(
		'name'        => __( 'موضوع مثبت' ),
		'id'          => 'pin',
		'type'        => 'checkbox',
	));
	$movie_option->add_field( array(
		'name'        => __( 'عدم العرض في الرئيسية' ),
		'id'          => 'dont_show_home',
		'type'        => 'checkbox',
	));
	$movie_option->add_field( array(
		'name'       => __( 'الحالة', 'kenzo' ),
		'id'         => 'status',
		'type'             => 'select',
		'show_option_none' => true,
		'options'          => array(
			'now'   		=> __( 'يعرض حاليا', 'kenzo' ),
			'soon'     	=> __( 'قريبا', 'kenzo' ),
		),
	));
	$movie_option->add_field( array(
		'name'        => __( 'تاريخ الاصدار' ),
		'id'          => 'released',
		'type'        => 'text',
	));
	$movie_option->add_field( array(
		'name'        => __( 'مده العرض' ),
		'id'          => 'runtime',
		'type'        => 'text',
	));
	$movie_option->add_field( array(
		'name'       		=> __( 'التصنيف العمرى', 'kenzo' ),
		'id'         		=> 'age_meta',
		'type'             	=> 'text',
	));

	/////////////////////////////////////////////////
	// Seo Meta Data Box Register
	/////////////////////////////////////////////////
	$seo_meta_box = new_cmb2_box(array(
		'id'            => 'seo_meta_box',
		'title'         => __( 'اعدادات الارشفة', 'kenzo' ),
		'object_types'  => array('movie','post','page','series','season','episode','singer','album','songs','show','program','game','news','assemblies','game_assemblies' ),
	));
	$seo_meta_box->add_field( array(
		'name'       => __( 'عنوان الموضوع', 'kenzo' ),
		'id'         => 'name_seo',
		'type'       => 'text',
	));
	$seo_meta_box->add_field(array(
		'name'       	=> __( 'وصف الموضوع', 'kenzo' ),
		'id'   				=> 'desc_seo',
		'type' 				=> 'textarea',
	));
	$seo_meta_box->add_field(array(
		'name'       	=> __( 'وسوم الموضوع', 'kenzo' ),
		'id'   				=> 'tags_seo',
		'type' 				=> 'text',
	));
	$seo_meta_box->add_field(array(
		'name'       	=> __( 'صورة الشير', 'kenzo' ),
		'id'   				=> 'img_social',
		'type' 				=> 'file',
	));
	$cmb_term = new_cmb2_box( array(
		'id'               => 'edit',
		'title'            => __( 'اعدادت الارشفة', 'cmb2' ),
		'object_types'     => array( 'term' ), 
		'taxonomies'       => array( 'series' ), 
		//'new_term_section' => true, 
	) );
	////////////////////////////////////////////////////////////
	$cmb_term->add_field( array(
		'name' => __( 'الحالة', 'cmb2' ),
		'id'   => 'status',
		'type' => 'select',
		"options" => array(
			"complate" => "مكتمل",
			"now" => "مستمر عرضة ",
		),
	) );
	$group_field_id_download = $cmb_term->add_field( array(
		'id'          => 'downloads',
		'type'        => 'group',
		'options'     => array(
			'group_title'   => __( 'سيرفر {#}', 'kenzo' ),
			'add_button'    => __( 'اضافة سيرفر جديد', 'kenzo' ),
			'remove_button' => __( 'حذف السيرفر', 'kenzo' ),
			'sortable'      => true,
		),
	));
	$cmb_term->add_group_field( $group_field_id_download, array(
		'name'       => __( 'اسم السيرفر', 'kenzo' ),
		'id'         => 'name',
		'type'       => 'text',
	));
	$cmb_term->add_group_field( $group_field_id_download, array(
		'name'        => __( 'رابط السيرفر', 'kenzo' ),
		'id'          => 'link',
		'type'        => 'text',
	));
}
