<?php

class ThemeContext extends ThemeTree
{
    private $args = NULL;
    private $_GET = NULL;
    private $_POST = NULL;
    public function __construct($args = [])
    {
        $this->args = $args;
        $this->Method = ["GETs" => $_GET, "POSTs" => $_POST];
        $this->CanonicalURL = $this->GetCanonicalURL();
        if (wp_is_mobile()) {
            $this->DataSrcAttr = "src=\"" . home_url() . "/MovizOneLogo.png\" data-src";
        } else {
            $this->DataSrcAttr = "src";
        }
    }
    public function Filter($cat, $catname)
    {
        echo "<span>" . $catname . " <i class=\"fa fa-chevron-down\"></i></span>";
    }
    public function load_chat()
    {
        echo get_option("chat");
        wp_die();
    }
    public function load_trailer()
    {
        echo get_post_meta($_POST["id"], "Trailer", 1);
        wp_die();
    }
    public function theme_fonts()
    {
        echo "<style>";
        echo "@font-face{font-family:bts;font-weight:300;src:url(" . get_template_directory_uri() . "/Standard/UI/fonts/Bahij_TheSansArabic-Plain.ttf);font-display:swap}";
        echo "@font-face{font-family:bts;font-weight:500;src:url(" . get_template_directory_uri() . "/Standard/UI/fonts/Bahij_TheSansArabic-Bold.ttf);font-display:swap}";
        echo "@font-face{font-family:bts;font-weight:700;src:url(" . get_template_directory_uri() . "/Standard/UI/fonts/Bahij_TheSansArabic-Black.ttf);font-display:swap}";
        echo "</style>";
    }
    public function gtshrt()
    {
        $args = ["post_type" => "post", "posts_per_page" => 1, "series" => $_POST["slug"], "fields" => "ids", "meta_query" => [["key" => "number", "value" => $_POST["number"], "compare" => "="]]];
        if (get_posts($args)) {
            foreach (get_posts($args) as $ep) {
                echo "              <a href=\"";
                echo get_the_permalink($ep);
                echo "\">\n                <div class=\"image\">";
                echo get_the_post_thumbnail($ep);
                echo "</div>\n                <div class=\"ep-info\">\n                  <h2>";
                echo get_the_title($ep);
                echo "</h2>\n                </div>\n                <div class=\"epnum\"><span>الحلقة</span>";
                echo get_post_meta($ep, "number", 1);
                echo "</div>\n              </a>\n          ";
            }
        } else {
            echo "<div class=\"epNoFound\">عفوا ! الحلقة رقم <span>" . $_POST["number"] . "</span> غير موجودة </div>";
        }
        wp_reset_query();
        wp_die();
    }
    public function rateFilm()
    {
        $likeArray = [];
        $rate = $_POST["rate"];
        $id = $_POST["id"];
        if ($rate == "like") {
            $liked = (int) get_post_meta($id, "like", 1);
            if (isset($_COOKIE["like" . $id])) {
                $addLike = $liked - 1 < 0 ? 0 : $liked - 1;
                update_post_meta($id, "like", $addLike);
                setcookie("like" . $id, "yes", time() - 31556926, "/");
            } else {
                $addLike = $liked + 1;
                update_post_meta($id, "like", $addLike);
                setcookie("like" . $id, "yes", time() + 31556926, "/");
            }
            if (isset($_COOKIE["disliked" . $id])) {
                $dis = (int) get_post_meta($id, "disliked", 1);
                $adddisLike = $dis - 1 < 0 ? 0 : $dis - 1;
                update_post_meta($id, "disliked", $adddisLike);
                setcookie("disliked" . $id, "yes", time() - 31556926, "/");
            }
        } else {
            $dis = (int) get_post_meta($id, "disliked", 1);
            if (isset($_COOKIE["disliked" . $id])) {
                $adddisLike = $dis - 1 < 0 ? 0 : $dis - 1;
                update_post_meta($id, "disliked", $adddisLike);
                setcookie("like" . $id, "yes", time() - 31556926, "/");
            } else {
                $adddisLike = $dis + 1;
                update_post_meta($id, "disliked", $adddisLike);
                setcookie("disliked" . $id, "yes", time() + 31556926, "/");
            }
            if (isset($_COOKIE["like" . $id])) {
                $liked = (int) get_option("like" . $id);
                $addLike = $liked - 1 < 0 ? 0 : $liked - 1;
                update_post_meta($id, "like", $addLike);
                setcookie("like" . $id, "yes", time() - 31556926, "/");
            }
        }
        $likeArray = ["likes" => (int) get_post_meta($id, "like", 1), "dislikes" => (int) get_post_meta($id, "disliked", 1)];
        echo json_encode($likeArray);
        wp_die();
    }
    public function getMoreByScroll()
    {
        $args = ["post_type" => "post", "posts_per_page" => 50, "offset" => $_POST["offset"], "fields" => "ids", "series" => $_POST["slug"], "meta_query" => [["key" => "number", "value" => "", "compare" => ">"]]];
        foreach (get_posts($args) as $post) {
            echo "        <a href=\"";
            echo get_the_permalink($post);
            echo "\" style=\"order:-";
            echo get_post_meta($post, "number", 1);
            echo "\">\n            <div class=\"image\">";
            echo get_the_post_thumbnail($post);
            echo "</div>\n          <div class=\"ep-info\">\n            <h2>";
            echo get_the_title($post);
            echo "</h2>\n          </div>\n          <div class=\"epnum\"><span>الحلقة</span>";
            echo get_post_meta($post, "number", 1);
            echo "</div>\n        </a>\n      ";
        }
        wp_die();
    }
    public function getTabsInsSeries()
    {
        $slug = $_POST["slug"];
        $parent = $_POST["parent"];
        $id = $_POST["id"];
        if ($slug != "") {
            echo "    <section class=\"tabs\">\n        <ul>\n          <li class=\"active\" data-class=\".allepcont\">الحلقات  [ ";
            echo count(get_posts(["post_type" => "post", "posts_per_page" => -1, "series" => $slug, "fields" => "ids"]));
            echo " ]</li>\n          ";
            if (get_categories(["taxonomy" => "series", "parent" => $id, "hide_empty" => 0])) {
                echo "            <li data-class=\".alls\">المواسم</li>\n          ";
            }
            echo "          ";
            if ($parent != 0) {
                echo "            <li data-class=\".otherseasons\">المواسم</li>\n          ";
            }
            echo "          </section>\n    <section class=\"tabContents\">\n      <section class=\"allepcont getMoreByScroll\" data-slug=\"";
            echo $slug;
            echo "\">\n          <div class=\"row\">\n            ";
            $args = ["post_type" => "post", "posts_per_page" => 50, "fields" => "ids", "series" => $slug, "meta_query" => [["key" => "number", "value" => "", "compare" => ">"]]];
            foreach (get_posts($args) as $post) {
                echo "                    <a href=\"";
                echo get_the_permalink($post);
                echo "\" style=\"order:-";
                echo get_post_meta($post, "number", 1);
                echo "\">\n                        <div class=\"image\">";
                echo get_the_post_thumbnail($post);
                echo "</div>\n                      <div class=\"ep-info\">\n                        <h2>";
                echo get_the_title($post);
                echo "</h2>\n                      </div>\n                      <div class=\"epnum\"><span>الحلقة</span>";
                echo get_post_meta($post, "number", 1);
                echo "</div>\n                    </a>\n                  ";
            }
            wp_reset_query();
            echo "          </div>\n      </section>\n      <section class=\"otherseasons\" style=\"display: none\">\n             <ul class=\"exploreBlocks1\">\n              ";
            $args = ["taxonomy" => "series", "hide_empty" => 0, "parent" => $parent];
            foreach (array_slice(get_categories($args), 0, 12) as $ser) {
                list($firstID) = get_posts(["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "series" => $ser->slug]);
                echo "<div class=\"MovieItem\">";

                echo "<a  href=\"" . get_term_link($ser) . "\">";
                echo "<div class=\"FrontBlock\">";
                echo "<img data-src=\"" . get_the_post_thumbnail_url($firstID) . "\">";
                echo "<div class=\"TitleBlock\">" . $ser->name . "</div>";
                echo "</div><div class=\"BackBlock\">";
                echo "<div class=\"ContentBlock\" title=\"قصة  " . $ser->name . "\" alt=\"قصة  " . $ser->name . "\">" . wp_trim_words($ser->description, 12, " [ .. ] ");
                echo "</div></div></a></div>";
            }
            echo "              <div class=\"clearfix\"></div>\n           </ul>\n      </section>\n      <section class=\"searchEpisodes\" style=\"display: none\">\n         <div class=\"searchepisode\">\n             <input type=\"number\" data-slug=\"";
            echo $obj->slug;
            echo "\" required=\"required\" placeholder=\"اكتب رقم الحلقة\">\n             <button><i class=\"fa fa-search\"></i></button>\n           </div>\n           <div class=\"row searchepresult\"></div>\n      </section>\n      <section class=\"alls\" style=\"display: none\">\n           <ul class=\"masterUlIn\">\n            ";
            if (get_categories(["taxonomy" => "series", "parent" => $id, "hide_empty" => 0])) {
                echo "                ";
                $args = ["taxonomy" => "series", "parent" => $id, "hide_empty" => 0];
                foreach (get_categories($args) as $links) {
                    echo "                  ";
                    list($postid) = get_posts(["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "series" => $links->slug]);
                    echo "                    <li class=\"MovieItem\">\n                      <a href=\"";
                    echo get_term_link($links);
                    echo "\">\n                        <div class=\"FrontBlock\">\n                          ";
                    if (get_term_meta($links->term_id, "image", 1)) {
                        echo "                            <img data-src=\"";
                        echo get_term_meta($links->term_id, "image", 1);
                        echo "\">\n                            ";
                    } else {
                        echo "                              <img data-src=\"";
                        echo get_the_post_thumbnail_url($postid);
                        echo "\">\n                          ";
                    }
                    echo "                          <div class=\"TitleBlock\">";
                    echo $links->name;
                    echo "</div>\n                        </div>\n                        </a>\n                      </li>\n                    ";
                }
                echo "            ";
            }
            echo "  \n        </ul>\n      </section>\n      <section class=\"otherser\" style=\"display: none\">\n          <ul class=\"exploreBlocks1\">\n              ";
            $id = $parent == 0 ? $id : $parent;
            $args = ["taxonomy" => "series", "hide_empty" => 0, "orderby" => "rand", "parent" => 0, "meta_query" => [["key" => "sercat", "value" => get_term_meta($id, "sercat", 1), "compare" => "="]]];
            foreach (array_slice(get_categories($args), 0, 12) as $ser) {
                list($firstID) = get_posts(["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "series" => $ser->slug]);
                echo "<div class=\"MovieItem\">";

                echo "<a  href=\"" . get_term_link($ser) . "\">";
                echo "<div class=\"FrontBlock\">";
                echo "<img data-src=\"" . get_the_post_thumbnail_url($firstID) . "\">";
                echo "<div class=\"TitleBlock\">" . $ser->name . "</div>";
                echo "</div><div class=\"BackBlock\">";
                echo "<div class=\"ContentBlock\" title=\"قصة  " . $ser->name . "\" alt=\"قصة  " . $ser->name . "\">" . wp_trim_words($ser->description, 12, " [ .. ] ");
                echo "</div></div></a></div>";
            }
            echo "              <div class=\"clearfix\"></div>\n           </ul>\n      </section>\n    </section>\n  ";
        }
        wp_die();
    }
    public function exploreUserData()
    {
        switch ($_POST["id"]) {
            case "watch":
                $terms = array_reverse(get_user_meta(wp_get_current_user()->ID, "later", 1));
                if (!empty($terms)) {
                    foreach ($terms as $post) {
                        if ("publish" == get_post_status($post)) {
                            $this->filmBlock($post);
                        }
                    }
                }
                break;
            case "followseries":
                $series = array_reverse(get_user_meta(wp_get_current_user()->ID, "subscribes", 1));
                if (!empty($series)) {
                    foreach ($series as $serid) {
                        if (trim($serid) != "") {
                            $ser = get_term($serid, "series");
                            if (is_object($ser)) {
                                $args = ["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", "ignore_sticky_posts" => 1, "series" => $ser->slug];
                                $firstID = get_posts($args);
                                $firstID = $firstID[0];
                                $imgSrc = wp_get_attachment_url(get_post_thumbnail_id($firstID));
                                echo "<div class=\"MovieItem\">";
                                echo "<span class=\"cancelSub\" data-user=\"" . wp_get_current_user()->ID . "\" data-id=\"" . $serid . "\">x</span>";
                                echo "<a  href=\"" . get_term_link($ser) . "\">";
                                echo "<div class=\"FrontBlock\">";
                                echo "<img data-src=\"" . $imgSrc . "\">";
                                if (get_post_meta($firstID, "imdbRating", true)) {
                                    echo "<span class=\"imdb\"><i class=\"fa fa-star\"></i>" . get_post_meta($firstID, "imdbRating", true) . "</span>";
                                }
                                echo "<div class=\"TitleBlock\">" . $ser->name . "</div>";
                                echo "</div><div class=\"BackBlock\">";
                                echo "<div class=\"ContentBlock\" title=\"قصة  " . $ser->name . "\" alt=\"قصة  " . $ser->name . "\">" . wp_trim_words($ser->description, 12, " [ .. ] ");
                                echo "</div></div></a></div>";
                            }
                        }
                    }
                }
                break;
            case "followch":
                $terms = array_reverse(get_user_meta(wp_get_current_user()->ID, "follow", 1));
                if (!empty($terms)) {
                    echo "<ul class=\"exploreBlocks\">";
                    foreach ($terms as $serid) {
                        $net = get_term($serid, "channel");
                        $this->exploreBlock($net);
                    }
                    echo "</ul>";
                }
                break;
            case "profile":
                echo "     <div class=\"subs setting\">\n        <div class=\"UserProfile\">\n           <script type=\"text/javascript\">\n             \$(function(){\n              \$('.uploadFile input[type=\"file\"]').on('change',function(e){\n                  var url = \$(this).data('url');\n                  var fd = new FormData();\n                  var files = \$(this)[0].files[0];\n                  fd.append('file',files);\n\n                  fd.append('action','uploadImage');\n                  \$('.imageprofile').append('<div class=\"loaderii\"><div class=\"lds-spinner\"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>');\n                  \$.ajax({\n                    type:'POST',\n                    url:url,\n                    contentType: false,\n                    processData: false,\n                    data:fd,\n                    success:function(msg){\n                      \$('.imageprofile').html(msg);\n                    }\n                  })\n              })\n             })\n           </script>\n              <form method=\"POST\"  class=\"prForm\" action=\"";
                echo home_url();
                echo "/account/\" class=\"clearfix\" enctype=\"multipart/form-data\">\n                <div class=\"right\">\n                  <div class=\"currentInfo\">\n                        <div class=\"imageprofile\">\n                        ";
                if (get_user_meta(wp_get_current_user()->ID, "image", 1) != "") {
                    echo "                            <img data-src=\"";
                    echo get_user_meta(wp_get_current_user()->ID, "image", 1);
                    echo "\">\n                        ";
                } else {
                    echo "                            <img data-src=\"";
                    echo get_template_directory_uri();
                    echo "/Standard/UI/img/def.png\">\n                        ";
                }
                echo "                        </div>\n                      <div class=\"uploadFile\">\n                        <input type=\"hidden\" name=\"image\" id=\"image\" style=\"display: none\">\n                        <input type=\"file\" name=\"image\" data-url=\"";
                echo admin_url("admin-ajax.php");
                echo "\" style=\"opacity:0\">\n                        <i class=\"fas fa-camera-retro\"></i>\n                      </div>\n                  </div>\n                  <ul class=\"someInfo\">\n                    <li>\n                      <span>الاسم الاول </span>\n                      ";
                echo wp_get_current_user()->first_name != "" ? wp_get_current_user()->first_name : "لم يتعين بعد";
                echo "                    </li>\n                    <li>\n                      <span>الاسم  الاخير </span>\n                      ";
                echo wp_get_current_user()->last_name != "" ? wp_get_current_user()->last_name : "لم يتعين بعد";
                echo "                    </li>\n                    <li>\n                      <span>الايميل</span>\n                      ";
                echo wp_get_current_user()->user_email;
                echo "                    </li>\n                \n\n                  </ul>\n                </div>\n                <div class=\"left\">\n                  <div class=\"form-group\">\n                    <label>الإسم الأول</label>\n                    <input type=\"text\" name=\"firstname\" placeholder=\"الإسم الأول\">\n                  </div>\n                  <div class=\"form-group\">\n                    <label>الإسم الأخير</label>\n                    <input type=\"text\" name=\"lastname\" placeholder=\"إسم العائلة\">\n                  </div>\n                  <div class=\"form-group\">\n                    <label>تغيير كلمة المرور</label>\n                    <input type=\"password\" name=\"newpassword\" placeholder=\"كلمة المرور الجديدة\">\n                    <input type=\"password\" name=\"renewpassword\" placeholder=\"اعادة كلمة المرور\">\n                  </div>\n                   <div class=\"form-group\">\n                    <label>تغيير الإيميل</label>\n                    <input type=\"email\" name=\"email\" placeholder=\"اكتب بريدك الإلكترونى\">\n                  </div>\n                  <div class=\"form-group\">\n                    <button type=\"submit\" name=\"profile\" id=\"profile\" data-url=\"";
                echo admin_url("admin-ajax.php");
                echo "\">تحديث البيانات الشخصية</button>\n                  </div>\n                </div>\n            </form>\n\n        </div>\n      </div>\n      ";
                break;
            default:
                wp_die();
        }
    }
    public function nextPost()
    {
        $arr = [];
        $tax = "channel";
        $slug = $_POST["slug"];
        if ($_POST["archive"] != "") {
            $tax = $_POST["archive"];
        }
        if ($_POST["slug"] == "full-series") {
            foreach (get_terms(["taxonomy" => "series", "number" => "1", "meta_query" => [["key" => "full", "value" => "on", "compare" => "="]], "orderby" => "rand"]) as $term) {
                $tax = "series";
                $slug = $term->slug;
            }
        }
        foreach (get_posts(["post_type" => "post", "posts_per_page" => 1, "fields" => "ids", $tax => $slug, "meta_key" => "Trailer", "orderby" => "rand", "post__not_in" => [$_POST["id"]]]) as $id) {
            preg_match("/src=\"([^\"]+)\"/", get_post_meta($id, "Trailer", 1), $match);
            list($iframeId) = explode("embed/", $match[1]);
            $arr["video"] = "<div id=\"ytbg\" data-ytbg-mute-button=\"true\" data-ytbg-play-button=\"true\" data-ytbg-fade-in=\"true\" data-youtube=\"https://www.youtube.com/watch?v=" . $iframeId . "\"></div>";
            $arr["title"] = get_the_title($id);
            $arr["buttons"] = " <li class=\"mute\"><i class=\"fas fa-volume\"></i></li> <li class=\"pause\"><i class=\"far fa-pause\"></i></li> <li class=\"showandhide\"><i class=\"fas fa-eye-slash\"></i></li> <li class=\"like\"><strong>" . (int) get_post_meta($id, "like", 1) . "</strong> <i class=\"fa fa-thumbs-up\"></i></li> <li class=\"dislike\"><strong>" . (int) get_post_meta($id, "disliked", 1) . "</strong><i class=\"fa fa-thumbs-down\"></i></li> <li class=\"next\" data-slug=\"" . $_POST["slug"] . "\"><i class=\"fal fa-forward\"></i>عرض اخر</li>";
            if (is_user_logged_in()) {
                if (!in_array($id, (int) get_user_meta(wp_get_current_user()->ID, "later", 1))) {
                    $btn = "<div class=\"addtomylist uselo\" data-id=\"" . $id . "\" data-user=\"" . wp_get_current_user()->ID . "\">\n                     <i class=\"fas fa-plus-circle\"></i>اضافة لقائمتي</div>";
                } else {
                    $btn = "<div class=\"addtomylist uselo\" data-id=\"" . $id . "\" data-user=\"" . wp_get_current_user()->ID . "\">\n                     <i class=\"fas fa-check\"></i>في قائمتي</div>";
                }
            } else {
                $btn = "<div class=\"addtomylist .notlogged\"> <div class=\"haveToRegister\">يجب تسجيل الدخول</div> <i class=\"fas fa-plus-circle\"></i>اضافة لقائمتي</div>";
            }
            $arr["info"] = $btn . "<div class=\"drt\"> <span>مده العرض</span> <p>" . get_post_meta($id, "runtime", 1) . "</p> </div> <div class=\"imdbBox\"> <span>IMDB</span> " . get_post_meta($id, "imdbRating", 1) . "</div> <div class=\"watchMovie\"> <a href=\"" . get_the_permalink($id) . "\"><i class=\"far fa-play\"></i> مشاهدة العرض </a></div>";
        }
        echo json_encode($arr);
        wp_die();
    }
    public function optionTax($cat, $filter, $catname)
    {
        echo "<ul class=\"" . $cat . "\" class=\"" . $filter . "\">";
        foreach (get_categories(["taxonomy" => $cat, "hide_empty" => 0]) as $c) {
            echo "<li data-name=\"" . $c->name . "\">";
            echo $c->name;
            echo "<span><i class=\"fa fa-check\"></i></span></li>";
        }
        echo "</ul>";
    }
    public function getOptionsSearch()
    {
        echo "<div class=\"container\">";
        $this->optionTax("category", "catsfilter", "اختر التصنيف");
        $this->optionTax("genre", "genrefilter", "اختر النوع");
        $this->optionTax("release-year", "yearfilter", "اختر  العام");
        $this->optionTax("quality", "Qulaityfilter", "اختر  الجودة");
        $this->optionTax("nation", "nationfilter", "اختر  الدولة");
        $this->optionTax("mpaa", "mpaafilter", "اختر  التصنيف العمري");
        echo "</div><div class=\"startSearchNow\">ابدأ البحث  الان</div>";
        wp_die();
    }
    public function historySetting()
    {
        $id = wp_get_current_user()->ID;
        $stophistory = trim(isset($_POST["stophistory"]) ? $_POST["stophistory"] : "");
        $removeHistory = trim(isset($_POST["removeHistory"]) ? $_POST["removeHistory"] : "");
        if ($removeHistory == "checked") {
            foreach (get_categories(["taxonomy" => "category", "hide_empty" => 0]) as $cat) {
                update_user_meta($id, "history" . $cat->term_id, []);
            }
        }
        if ($stophistory == "checked") {
            update_user_meta($id, "stophistory", "yes");
        } else {
            update_user_meta($id, "stophistory", "no");
        }
        echo "<h4 class=\"successmessage\">تم التحديث بنجاح</h4>";
        wp_die();
    }
    public function loginmethod()
    {
        if ($this->user_name_exists($_POST["username"]) && $this->checkPass($_POST["username"], $_POST["password"])) {
            if ($_POST["username"] != "") {
                $username = filter_var($_POST["username"], FILTER_SANITIZE_STRING);
            }
            if ($_POST["password"] != "") {
                $pass = $_POST["password"];
            }
            $creds = [];
            $creds["user_login"] = $username;
            $creds["user_password"] = $pass;
            $creds["remember"] = true;
            $user = wp_signon($creds, false);
            echo "          <script type=\"text/javascript\">\n            window.location.href = HomeURL;\n          </script>\n        ";
        } else {
            echo "<div class=\"erMsg\">عفوا هذه البيانات غير صحيحة</div>";
        }
        wp_die();
    }
    public function registermethod()
    {
        $userdata = ["user_login" => $_POST["username"], "user_pass" => $_POST["password"], "user_email" => $_POST["email"]];
        $user_id = wp_insert_user($userdata);
        if (is_wp_error($user_id)) {
            $error_string = $user_id->get_error_message();
            echo "<div id=\"message\" class=\"error\"><p>" . $error_string . "</p></div>";
        } else {
            echo "<div class=\"is_success\"></div>";
        }
        wp_die();
    }
    public function notestSetting()
    {
        $id = wp_get_current_user()->ID;
        $stopnotes = trim(isset($_POST["stopnotes"]) ? $_POST["stopnotes"] : "");
        $removeNotes = trim(isset($_POST["removeNotes"]) ? $_POST["removeNotes"] : "");
        if ($removeNotes == "checked") {
            update_user_meta($id, "notices", "");
        }
        if ($stopnotes == "checked") {
            update_user_meta($id, "stopnotes", "yes");
        } else {
            update_user_meta($id, "stopnotes", "no");
        }
        echo "<h4 class=\"successmessage\">تم التحديث بنجاح</h4>";
        wp_die();
    }
    public function uploadImage()
    {
        if (!function_exists("wp_generate_attachment_metadata")) {
            require_once ABSPATH . "wp-admin" . "/includes/image.php";
            require_once ABSPATH . "wp-admin" . "/includes/file.php";
            require_once ABSPATH . "wp-admin" . "/includes/media.php";
        }
        if (array_filter($_FILES)) {
            foreach (array_filter($_FILES) as $file => $array) {
                if ($_FILES[$file]["error"] !== UPLOAD_ERR_OK) {
                }
                if (!is_wp_error($file)) {
                    $attach_id = media_handle_upload($file, 0);
                    $image = wp_get_attachment_url($attach_id);
                }
            }
        }
        echo "<img src=\"" . $image . "\" />";
        wp_die();
    }
    public function profileSetting()
    {
        $current_user = wp_get_current_user();
        $userName = $_POST["firstname"] == "" ? $current_user->first_name : $_POST["firstname"];
        $lastName = $_POST["lastname"] == "" ? $current_user->last_name : $_POST["lastname"];
        $newPass = $_POST["newpassword"];
        $rePass = $_POST["renewpassword"];
        $image = $_POST["image"];
        $email = $_POST["email"] == "" ? $current_user->user_email : $_POST["email"];
        $erros = [];
        if ($newPass !== $rePass) {
            $erros[] = "<li>كلمة المرور غير متطابقة</li>";
        }
        if (empty($erros)) {
            $user_id = $current_user->ID;
            $user_data = wp_update_user(["ID" => $user_id, "first_name" => $userName, "last_name" => $lastName, "user_email" => $email, "user_pass" => esc_attr($newPass)]);
            if ($image != "") {
                update_user_meta($user_id, "image", $image);
            }
            echo "<div class=\"success\">تم التحديث بنجاح</div>";
        } else {
            echo "<ul class=\"errors\">";
            foreach ($erros as $error) {
                echo $error;
            }
            echo "</ul>";
        }
        wp_die();
    }
    public function addPinPostsPage()
    {
        add_menu_page("المواضيع المثبتة", "المواضيع المثبتة", "manage_options", "pinposts", [new ThemeContext(), "pinPosts"], "dashicons-sticky", 110);
    }
    public function addStyleToAdmin()
    {
        wp_enqueue_style("pinStyle", get_template_directory_uri() . "/Setup/Pin/style.css");
    }
    public function pinPosts()
    {
        require get_template_directory() . "/Setup/Pin/pin.php";
    }
    public function getInfoByID()
    {
        $id = $_POST["id"];
        $content_post = get_post($id);
        $content = $content_post->post_content;
        $content = apply_filters("the_content", $content);
        $content = str_replace("]]>", "]]&gt;", $content);
        $awards = "";
        if (get_the_terms($id, "awards", "")) {
            foreach (get_the_terms($id, "awards", "") as $aw) {
                $awards .= $aw->name . ",";
            }
        }
        $years = "";
        if (get_the_terms($id, "release-year", "")) {
            foreach (get_the_terms($id, "release-year", "") as $yy) {
                $years .= $yy->name . ",";
            }
        }
        $genre = "";
        if (get_the_terms($id, "genre", "")) {
            foreach (get_the_terms($id, "genre", "") as $gg) {
                $genre .= $gg->name . ",";
            }
        }
        $quality = "";
        if (get_the_terms($id, "quality", "")) {
            foreach (get_the_terms($id, "quality", "") as $qq) {
                $quality .= $qq->name . ",";
            }
        }
        $nation = "";
        if (get_the_terms($id, "nation", "")) {
            foreach (get_the_terms($id, "nation", "") as $nn) {
                $nation .= $nn->name . ",";
            }
        }
        $language = "";
        if (get_the_terms($id, "language", "")) {
            foreach (get_the_terms($id, "language", "") as $ll) {
                $language .= $ll->name . ",";
            }
        }
        $actor = "";
        if (get_the_terms($id, "actor", "")) {
            foreach (get_the_terms($id, "actor", "") as $aa) {
                $actor .= $aa->name . ",";
            }
        }
        $director = "";
        if (get_the_terms($id, "director", "")) {
            foreach (get_the_terms($id, "director", "") as $dd) {
                $director .= $dd->name . ",";
            }
        }
        $writers = "";
        if (get_the_terms($id, "writers", "")) {
            foreach (get_the_terms($id, "writers", "") as $ww) {
                $writers .= $ww->name . ",";
            }
        }
        $mpaa = "";
        if (get_the_terms($id, "mpaa", "")) {
            foreach (get_the_terms($id, "mpaa", "") as $ww) {
                $mpaa .= $ww->name . ",";
            }
        }
        $data = ["link" => get_the_permalink($id), "title" => get_the_title($id), "thumbnail" => get_the_post_thumbnail_url($id), "thid" => get_post_thumbnail_id($id), "content" => $content, "story" => get_post_meta($id, "story", 1), "ribbon" => get_post_meta($id, "ribbon", 1), "runtime" => get_post_meta($id, "runtime", 1), "imdbRating" => get_post_meta($id, "imdbRating", 1), "Trailer" => get_post_meta($id, "Trailer", 1), "watchlist" => get_post_meta($id, "watchlist", 1), "downloadslist" => get_post_meta($id, "downloadslist", 1), "awards" => $awards, "year" => $years, "quality" => $quality, "nation" => $nation, "language" => $language, "genre" => $genre, "mpaa" => $mpaa, "actor" => $actor, "director" => $director, "writers" => $writers];
        echo json_encode($data);
        wp_die();
    }
    public function getFilmPostInfo()
    {
        echo "<ul>";
        foreach (get_posts(["post_type" => "post", "fields" => "ids", "s" => $_GET["s"]]) as $post) {
            echo "<li class=\"postInfoId\" data-id=\"" . $post . "\">" . get_the_title($post) . "</li>";
        }
        echo "</ul>";
        wp_die();
    }
    public function updatePostDate()
    {
        $id = $_POST["id"];
        $time = current_time("mysql");
        wp_update_post(["ID" => $id, "post_date" => $time, "post_date_gmt" => get_gmt_from_date($time)]);
        wp_die();
    }
    public function filterTab()
    {
        $series = get_categories(["taxonomy" => "series", "hide_empty" => 0, "meta_query" => ["relation" => "and", ["key" => $_POST["ser"], "value" => "on", "compare" => "="], ["key" => "sercat", "value" => $_POST["name"], "compare" => "="]]]);
        foreach ($series as $ser) {
            $firstID = get_posts(["post_type" => "post", "posts_per_page" => 1, "ignore_sticky_posts" => 1, "series" => $ser->slug]);
            $firstID = $firstID[0]->ID;
            $imgSrc = wp_get_attachment_url(get_post_thumbnail_id($firstID));
            echo "\n          <div class=\"MovieItem\">\n                <a title=\"";
            echo $ser->name;
            echo "\" href=\"";
            echo get_term_link($ser);
            echo "\">\n                  <div class=\"FrontBlock\">\n                        ";
            if (get_term_meta($ser->term_id, "image", 1)) {
                echo "                          <img src=\"";
                echo get_term_meta($ser->term_id, "image", 1);
                echo "\">\n                        ";
            } else {
                echo "                          <img src=\"";
                echo $imgSrc;
                echo "\">\n                        ";
            }
            echo " \n                    <div class=\"TitleBlock\">";
            echo $ser->name;
            echo "</div>\n                  </div>\n                  <div class=\"BackBlock\">\n                    <ul class=\"BarBlock\">\n                        ";
            $rate = get_post_meta($firstID, "imdbRating", true);
            if (!empty($rate)) {
                echo "                            <li class=\"category\" title=\"\" data-herf=\"\">\n                              <i class=\"fas fa-star \"></i><span>";
                echo get_post_meta($firstID, "imdbRating", true);
                echo "</span>\n                            </li>   \n                        ";
            }
            echo "                      ";
            if (get_the_terms($firstID, "genre", "")) {
                echo "                        ";
                foreach (array_slice(is_array(get_the_terms($firstID, "genre", "")) ? get_the_terms($firstID, "genre", "") : araay(), 0, 1) as $genre) {
                    echo "                            <li class=\"category two\" title=\"";
                    echo $genre->name;
                    echo "\" data-herf=\"";
                    echo get_term_link($genre);
                    echo "\">\n                              <i class=\"fas fa-star \"></i><span>";
                    echo $genre->name;
                    echo "</span>\n                            </li>\n                        ";
                }
                echo "                      ";
            }
            echo "                    </ul>\n                    <div class=\"ContentBlock\" title=\"قصة  ";
            echo $ser->name;
            echo "\" alt=\"قصة  ";
            echo $ser->name;
            echo "\">";
            echo wp_trim_words(get_the_content(), 12, " [ .. ] ");
            echo "</div>\n                  </div>\n                </a>\n              </div>\n      ";
        }
        wp_die();
    }
    public function extra_user_profile_fields($user)
    {
        echo "      ";
        wp_enqueue_media();
        echo "        <h3>اعدادت العضو</h3>\n\n        <table class=\"form-table userCustomFields\">\n        <tr>\n            <th><label for=\"image\">";
        _e("الصورة الشخصية");
        echo "</label></th>\n            <td>\n                <input type=\"text\" name=\"image\" id=\"image\" value=\"";
        echo esc_attr(get_the_author_meta("image", $user->ID));
        echo "\" class=\"regular-text\" />\n                <button id=\"userUploadBtn\" class=\"button button-primary\">رفع صورة</button>\n                  ";
        $value = get_the_author_meta("image", $user->ID);
        echo "                  <div style=\"margin-top:20px\">\n            ";
        if (empty($value)) {
            $style = "display:none;";
        }
        echo "<img class=\"APBPreviewFile\"  style=\"" . $style . "\" src=\"" . (isset($value) ? $value : "") . "\" />";
        echo "<a style=\"" . $style . "\" href=\"javascript:void(0);\" class=\"APBRemoveButton removeImage\">حذف</a>";
        echo "                  </div>\n           \n            </td>\n        \n        </tr>\n      \n        </table>\n  ";
    }
    public function save_extra_user_profile_fields($user_id)
    {
        if (!current_user_can("edit_user", $user_id)) {
            return false;
        }
        update_user_meta($user_id, "image", $_POST["image"]);
    }
    public function noticeSeen()
    {
        update_user_meta(wp_get_current_user()->ID, "noticeCase", "seen");
        update_user_meta(wp_get_current_user()->ID, "notesNum", 0);
    }
    public function later()
    {
        $userid = $_POST["userid"];
        $id = $_POST["id"];
        $subs = (int) get_user_meta($userid, "later", 1);
        if (empty($subs)) {
            update_user_meta($userid, "later", [$id]);
        } else {
            if (!in_array($id, $subs)) {
                $subs[] = $id;
                update_user_meta($userid, "later", $subs);
            } else {
                if (($key = array_search($id, $subs)) !== false) {
                    unset($subs[$key]);
                    update_user_meta($userid, "later", $subs);
                }
            }
        }
        wp_die();
    }
    public function followTax()
    {
        $userid = $_POST["userid"];
        $id = $_POST["id"];
        $subs = (int) get_user_meta($userid, "follow", 1);
        if (empty($subs)) {
            update_user_meta($userid, "follow", [$id]);
        } else {
            if (!in_array($id, $subs)) {
                $subs[] = $id;
                update_user_meta($userid, "follow", $subs);
            } else {
                if (($key = array_search($id, $subs)) !== false) {
                    unset($subs[$key]);
                    update_user_meta($userid, "follow", $subs);
                }
            }
        }
        wp_die();
    }
    public function subscribe()
    {
        $userid = $_POST["userid"];
        $id = $_POST["id"];
        $subs = (int) get_user_meta($userid, "subscribes", 1);
        if (empty($subs)) {
            update_user_meta($userid, "subscribes", [$id]);
        } else {
            if (!in_array($id, $subs)) {
                $subs[] = $id;
                update_user_meta($userid, "subscribes", $subs);
            } else {
                if (($key = array_search($id, $subs)) !== false) {
                    unset($subs[$key]);
                    update_user_meta($userid, "subscribes", $subs);
                }
            }
        }
        wp_die();
    }
    public function History($userid, $postid, $catid)
    {
        $history = (int) get_user_meta($userid, "history" . $catid, 1);
        if (empty($history)) {
            update_user_meta($userid, "history" . $catid, [$postid]);
        } else {
            if (!in_array($postid, $history)) {
                $history[] = $postid;
                update_user_meta($userid, "history" . $catid, $history);
            }
        }
    }
    public function user_name_exists($username)
    {
        $users = [];
        foreach (get_users() as $user) {
            $users[] = $user->user_login;
        }
        if (in_array($username, $users)) {
            return true;
        }
        return false;
    }
    public function checkPass($username, $password)
    {
        $userdata = get_user_by("login", $username);
        return wp_check_password($password, $userdata->user_pass, $userdata->ID);
    }
    public function infoLoad()
    {
        echo "<div class=\"info\">";
        echo "<h1><a href=\"" . get_the_permalink($_POST["id"]) . "\">" . get_the_title($_POST["id"]) . "</a></h1>";
        echo "<div class=\"simpleInfo\"><div class=\"breadcrumbs\"><div class=\"breadcrumb clearfix\"><div id=\"mpbreadcrumbs\"><span>";
        echo "<a  href=\"" . home_url() . "\">";
        echo "<span>الرئيسية</span></a></span>";
        if (get_the_terms($_POST["id"], "category", 1)) {
            foreach (array_slice(is_array(get_the_terms($_POST["id"], "category", "")) ? get_the_terms($_POST["id"], "category", "") : [], 0, 1) as $category) {
                echo $delimiter;
                echo "<span>";
                echo "<a  href=\"" . get_term_link($category) . "\">";
                echo "<span>" . $category->name . "</span>";
                echo "</a></span>";
            }
        }
        if (get_the_terms($_POST["id"], "series", 1)) {
            foreach (get_the_terms($_POST["id"], "series", "") as $series) {
                echo $delimiter;
                if ($series->parent == 0) {
                    echo "<span>";
                    echo "<a  href=\"" . get_term_link($series) . "\">";
                    echo "<span>" . $series->name . "</span>";
                    echo "</a></span>";
                }
            }
            foreach (get_the_terms($_POST["id"], "series", "") as $series) {
                echo $delimiter;
                if ($series->parent != 0) {
                    echo "<span>";
                    echo "<a  href=\"" . get_term_link($series) . "\">";
                    echo "<span>" . $series->name . "</span>";
                    echo "</a></span>";
                }
            }
        }
        echo $delimiter;
        echo "<span>";
        echo "<a itemprop=\"url\" href=\"" . get_the_permalink($_POST["id"]) . "\">";
        echo "<span>" . get_the_title($_POST["id"]) . "</span>";
        echo "</a></span></div></div></div></div></div>";
        wp_die();
    }
    public function getFullWatchServers()
    {
        echo "<div class=\"serverCont\">";
        foreach (get_the_terms($_POST["id"], "series", 1) as $ser) {
            if ($ser->parent == 0) {
                if (!get_categories(["taxonomy" => "series", "parent" => $ser->term_id])) {
                    $slug = $ser->slug;
                    $serID = $ser->term_id;
                    $ser = $ser->name;
                    $fullName = "المسلسل كامل";
                }
            } else {
                $slug = $ser->slug;
                $serID = $ser->term_id;
                $ser = $ser->name;
                $fullName = "الموسم كامل";
            }
        }
        echo "<ul class=\"WatchServers\"><h2 class=\"single-title\">سيرفرات المشاهدة</h2>";
        $newServers = (new ThemeContext())->get_new_server(get_post_meta($_POST["id"], "watchlist", true));
            if (!empty($Post_servers)) {
                foreach ($Post_servers as $post_server) {
                    echo "<li class=\"serverItem\" data-id=\"" . $_POST["id"] . "\" data-server=\"" . $post_server["link"] . "\">" . $post_server["name"] . "</li>  ";
                }
            }

        echo "</ul>";
        echo "<div id=\"EmbedCode\" " . (!get_post_meta($_POST["id"], "number", 1) ? "style=\"border-radius: 25px!important\"" : "") . ">";
        echo "<div class=\"iframeHolder\"></div><ul class=\"buttons\">";
        if (get_the_terms($_POST["id"], "series", 1)) {
        }
        echo "<li class=\"lightOff\">اطفاء الانوار</li>";
        echo "<li  class=\"light bacdetails\"><a href=\"" . get_the_permalink($_POST["id"]) . "\"> الرجوع  للتفاصيل  </a> </li>";
        echo "</ul></div>";
        $servS = false;
        wp_reset_postdata();
        $download_servers = new WP_Query(["posts_per_page" => -1, "post_status" => "publish", "post_type" => "download_servers", "meta_key" => "server_num", "orderby" => "meta_value", "order" => "ASC"]);
        $hasServers = [];
        while ($download_servers->have_posts()) {
            $download_servers->the_post();
            $server = get_post_meta($post->ID, "download_server_" . get_the_ID(), true);
            if (!empty($server)) {
                $hasServers[] = get_the_ID();
            }
            wp_reset_postdata();
        }
        if (1 < count($hasServers)) {
            $servS = true;
        }
        echo "</div><div class=\"DownloadContents\">";
        $download_links_list = $this->get_down_server(get_post_meta($_POST["id"], "downloadslist", true));
        if (!empty($download_links_list) || $hasServers || $servS) {
            echo "<h2 class=\"single-title\">سيرفرات التحميل</h2>";
            $download_links_list = (new ThemeContext())->get_down_server(get_post_meta($_POST["id"], "downloadslist", true));
            if (!empty($download_links_list)) {
                foreach ($download_links_list as $key) {
                    echo "<a target=\"_blank\" href=\"" . $key["link"] . "\" class=\"btn download_btn col-md-1\"><i class=\"far fa-file-download\"></i>" . $key["name"] . "";
                    echo "</a>";
                }
            }
        }
        echo "</div>           <script type=\"text/javascript\">\n             window.history.pushState(\"";
        echo get_the_title($_POST["id"]);
        echo "\", \"Title\", \"";
        echo get_the_permalink($_POST["id"]);
        echo "watch\");\n             \$('title').html(\"";
        echo get_the_title($_POST["id"]);
        echo "\");\n           </script>\n           ";
        wp_die();
    }
    public function getServer()
    {
        echo get_option("videoAds");
        echo "<iframe src=\"" . $_POST["server"] . "\" scrolling=\"no\" frameborder=\"0\" width=\"100%\" height=\"100%\" allowfullscreen=\"true\" webkitallowfullscreen=\"true\" mozallowfullscreen=\"true\"></iframe>";
        wp_die();
    }
    public function Espoblock()
    {
        $postID = $_POST["id"];
        $offset = $_POST["offset"];
        global $post;
        $args = ["post_type" => "post", "posts_per_page" => 18, "fields" => "ids", "offset" => $offset, "tax_query" => ["relation" => "AND"]];
        foreach (is_array(get_the_terms($postID, "category", "")) ? get_the_terms($postID, "category", "") : [] as $category) {
            if (!empty($category)) {
                $args["tax_query"][] = ["taxonomy" => "category", "terms" => $category->term_id, "field" => "id", "include_children" => true, "operator" => "IN"];
            }
        }
        foreach (is_array(get_the_terms($postID, "genre", "")) ? get_the_terms($postID, "genre", "") : [] as $genre) {
            if (!empty($genre)) {
                $args["tax_query"][] = ["taxonomy" => "genre", "terms" => $genre->term_id, "field" => "id", "include_children" => true, "operator" => "IN"];
            }
        }
        foreach (is_array(get_the_terms($postID, "release-year", "")) ? get_the_terms($postID, "release-year", "") : [] as $release_year) {
            if (!empty($release_year)) {
                $args["tax_query"][] = ["taxonomy" => "release-year", "terms" => $release_year->term_id, "field" => "id", "include_children" => true, "operator" => "IN"];
            }
        }
        foreach (is_array(get_the_terms($postID, "quality", "")) ? get_the_terms($postID, "quality", "") : [] as $quality) {
            if (!empty($quality)) {
                $args["tax_query"][] = ["taxonomy" => "quality", "terms" => $quality->term_id, "field" => "id", "include_children" => true, "operator" => "IN"];
            }
        }
        if (get_post_meta($postID, "number", 1)) {
            $args["meta_key"] = "number";
        } else {
            $args["meta_query"][] = ["key" => "number", "compare" => "NOT EXISTS"];
        }
        if (!get_posts($args)) {
            foreach (get_posts($args) as $post) {
                $this->filmBlock($post);
            }
        } else {
            echo "    <script type=\"text/javascript\">\n    \$('.MainRelated').attr('data-loading', 'true');\n    \$('.MoreLoaded').remove();\n    </script>\n    <h2 class=\"noMorePosts\">لا يوجد نتائج اخري</h2>\n   ";
        }
        wp_die();
    }
    public function EpisodesList()
    {
        global $post;
        foreach (get_posts(["post_type" => "post", "series" => get_term($_POST["serie"], "series")->slug, "posts_per_page" => -1, "meta_key" => "number", "order" => "ASC", "orderby" => "meta_value_num"]) as $post) {
            echo "<a href=\"" . get_the_permalink($post) . "\">";
            echo "<em>" . get_post_meta($post, "number", true) . "</em>";
            echo "الحلقة</a>";
        }
        wp_die();
    }
    public function homeFilter()
    {
        $filter = $_POST["filter"];
        global $post;
        $args = ["post_type" => "post", "posts_per_page" => 12, "fields" => "ids"];
        if ($filter == "pin") {
            $args["meta_key"] = "pin";
        } else {
            if ($filter == "stars") {
                $args["orderby"] = "meta_value_num";
                $args["meta_key"] = "ratings_average";
            } else {
                if ($filter == "views") {
                    $args["orderby"] = "meta_value_num";
                    $args["meta_key"] = "views";
                } else {
                    if ($filter == "imdb") {
                        $args["orderby"] = "meta_value_num";
                        $args["meta_key"] = "imdbRating";
                    }
                }
            }
        }
        echo "<ul>";
        foreach (get_posts($args) as $post) {
            echo "<li>";
            echo "<a href=\"" . get_the_permalink($post) . "\">";
            the_post_thumbnail();
            echo "</a>";
            if (get_post_meta($post, "imdbRating", true) != "") {
                echo "<div class=\"ImdbRating\"><span>imdb</span>";
                echo get_post_meta($post, "imdbRating", true);
                echo "</div>";
            }
            foreach (array_slice(get_the_terms($post, "quality", ""), 0, 1) as $quality) {
                echo "<span class=\"ribbon r3\">";
                echo "<span><a href=\"" . get_term_link($quality) . "\">" . $quality->name . "</a></span>";
                echo "</span>";
            }
            foreach (array_slice(get_the_terms($post, "genre", ""), 0, 1) as $genre) {
                echo "<span class=\"genre\">" . $genre->name . "</span>";
            }
            echo "<a href=\"" . get_the_permalink($post) . "\"><h1 class=\"SlideTitle\">" . get_the_title($post) . "</h1></a>";
            echo "</li>";
        }
        echo "</ul>";
        wp_die();
    }
    public function getSeasons()
    {
        global $post;
        foreach (get_posts(["post_type" => "post", "posts_per_page" => -1, "series" => $_POST["slug"], "fields" => "ids"]) as $post) {
            echo "<li data-id=\"" . $post . "\" style=\"order:" . (int) get_post_meta($post, "number", 1) . "\" class=\"" . ($post == $id ? "active" : "") . "\"><a href=\"" . get_the_permalink($post) . "\"><span>الحلقة</span>" . get_post_meta($post, "number", 1) . "</a></li>";
        }
        wp_die();
    }
    public function str_contains($needle, $haystack, $offset = 0)
    {
        return (int) strpos($haystack, $needle, $offset);
    }
    public function check_watch_server($Input_server)
    {
        $servers = ["posts_per_page" => -1, "post_status" => "publish", "post_type" => "servers", "meta_key" => "server_num", "orderby" => "meta_value", "order" => "ASC"];
        $serverCut = get_post_meta($server->ID,'serverCut',true);
        $serverEmbdd = get_post_meta($server->ID,'serverEmbdd',true);
        $serverNumber = get_post_meta($server->ID,'server_num',true);
        $serverName = get_the_title($server->ID);
        $thum = wp_get_attachment_url(get_post_thumbnail_id($server->ID));
        $htts = ['http://','https://'];
        if(strpos($InputServer,strtolower(str_replace($htts,['',''],$serverCut)))) {
            $rmhttp = str_replace('http://','',$serverCut);
            $rmhttp = str_replace('https://','',$serverCut);
            $emhttp = str_replace('http://','',$serverEmbdd);
            $emhttp = str_replace('https://','',$serverEmbdd);
            $link = str_replace('http://','https://',str_replace($rmhttp,$emhttp,$InputServer)) ;
            if (strtolower($serverName) == 'ok.ru') {
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>str_replace('.html','',$link)];
            } elseif (strtolower($serverName) == 'rapidvideo') {
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>str_replace('.html','',$link)];
            } elseif (strtolower($serverName) == 'mystream' || $serverName == 'yourupload') {
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>str_replace('.html','',$link)];
            } elseif(strtolower($serverName) == 'clipwatching'){
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>substr(str_replace('.html','',$link), 0,43).'.html'];
            }elseif(strtolower($serverName) == 'letsupload'){
                $lInkss = explode('/', $link);
                $lInkss = 'https://letsupload.co/plugins/mediaplayer/site/'.$lInkss[6];
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=> str_replace('.html','',$lInkss) ];
            } elseif(strtolower($serverName) == 'vup'){
                $link = str_replace('emb.html?', '', $link);
                $link = str_replace('.html', '', $link);
                $lInkss = explode('/', $link);
                $lInkss = 'https://vup.to/emb.html?'.$lInkss[3];
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=> $lInkss ];
            } elseif(strtolower($serverName) == 'linkbox'){
                $link = str_replace('player.html?id=', '', $link);
                $link = str_replace('.html', '', $link);
                $lInkss = explode('/', $link);
                $lInkss = 'https://www.linkbox.to/player.html?id='.$lInkss[3];
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=> $lInkss ];
            } elseif(strtolower($serverName) == 'uppom'){
                $link = getstringss($link , "embed-/" , "/");
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=> "https://uppom.live/embed-".$link.".html" ];
            } else {
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>str_replace('.html','',$link).get_post_meta( $server->ID, "server_end", 1)];
            }
        }
    }

    public function get_new_server($value)
    {
        $servers = [];
    if (!empty($value)) {
        @$value = preg_split('/\r\n|[\r\n]/', $value);
        if (!empty($value)) {
            foreach ($value as $server) {
                if (!is_null($server) and !is_null(@CheckWatchServer($server)['server'])) {
                    $data = [];
                    $data['name'] = @CheckWatchServer($server)['server'];
                    $data['link'] = @CheckWatchServer($server)['link'];
                    $data['order'] = @CheckWatchServer($server)['order'];
                    $data['icon'] = @CheckWatchServer($server)['ico'];
                    $data['qua'] = @CheckWatchServer($server)['qua'];
                    $servers[] = $data;
                }
            }
        }
    }
        usort($servers, [$this, "cmp"]);
        return $servers;
    }
    public function check_server($Input_server)
    {
        $servers = ["posts_per_page" => -1, "post_status" => "publish", "post_type" => "servers", "meta_key" => "server_num", "orderby" => "meta_value", "order" => "ASC"];
        $servers = get_posts($servers);
        foreach ($servers as $server) {
            $serverCut = get_post_meta($server->ID, "serverCut", true);
            $serverEmbdd = get_post_meta($server->ID, "serverEmbdd", true);
            $serverNumber = get_post_meta($server->ID, "server_num", true);
            $serverName = get_the_title($server->ID);
            $htts = array("http://", "https://");
            if (strpos($Input_server, strtolower(str_replace($htts, array("", ""), $serverCut)))) {
                $rmhttp = str_replace("http://", "", $serverCut);
                $rmhttp = str_replace("https://", "", $serverCut);
                $emhttp = str_replace("http://", "", $serverEmbdd);
                $emhttp = str_replace("https://", "", $serverEmbdd);
                $link = str_replace("http://", "https://", str_replace($rmhttp, $emhttp, $Input_server));
                if ($serverName == "ok") {
                    return array("order" => $serverNumber, "server" => $serverName, "link" => str_replace(".html", "", $link));
                }
                if ($serverName == "rapidvideo") {
                    return array("order" => $serverNumber, "server" => $serverName, "link" => str_replace(".html", "", $link));
                }
                return array("order" => $serverNumber, "server" => $serverName, "link" => str_replace(".html", "", $link) . ".html");
            }
        }
    }

    public function get_server($value)
    {
        $servers = array();
        if (!empty($value)) {
            foreach ($value as $server) {
                if (!is_null($this->check_server($server["code"])["server"]) && !is_null($this->check_server($server["code"])["order"])) {
                    $data = array();
                    $data["name"] = $this->check_serverr($server["code"])["server"];
                    $data["order"] = $this->check_server($server["code"])["order"];
                    $data["link"] = $this->check_server($server["code"])["link"];
                    $servers[] = $data;
                }
            }
        }
        usort($servers, [$this, "cmp"]);
        return $servers;
    }
    public function cmp($a, $b)
    {
        if ($a["order"] == $b["order"]) {
            return 0;
        }
        return $a["order"] < $b["order"] ? -1 : 1;
    }
    public function check_down_server($Input_server)
    {
        $servers = ["posts_per_page" => -1, "post_status" => "publish", "post_type" => "download_servers", "meta_key" => "server_num", "orderby" => "meta_value", "order" => "ASC"];
        $servers = get_posts($servers);
        foreach ($servers as $server) {
            $thum = wp_get_attachment_url(get_post_thumbnail_id($server));
            $serverNumber = get_post_meta($server, "server_num", true);
            $serverName = get_the_title($server);
            $htts = array("http://", "https://");
            if (strpos($Input_server, strtolower(str_replace($htts, array("", ""), $serverName)))) {
                return array("order" => $serverNumber, "ico" => $thum, "server" => $serverName, "link" => $Input_server);
            }
        }
    }
    public function get_down_server($value)
    {
        $servers = array();
        if (!empty($value)) {
            $value = preg_split("/\\r\\n|[\\r\\n]/", $value);
            foreach ($value as $server) {
                if (!is_null($server) && !is_null($this->check_down_server($server)["server"])) {
                    $data = array();
                    $data["name"] = $this->check_down_server($server)["server"];
                    $data["link"] = $this->check_down_server($server)["link"];
                    $data["thum"] = $this->check_down_server($server)["ico"];
                    $data["order"] = $this->check_down_server($server)["order"];
                    $servers[] = $data;
                }
            }
        }
    usort($servers, 'cmp');
    return $servers;
}
public function cmm_down($a, $b)
    {
        if ($a["order"] == $b["order"]) {
            return 0;
        }
        return $a["order"] < $b["order"] ? -1 : 1;
    }
public function getstringss($a,$b,$c){
    $y = explode($b,$a);
    $x = explode($c,$y[1]);
    return $x[0];
}


        public function oldArchive()
    {
        if (is_singular()) {
            return NULL;
        }
        global $wp_query;
        if ($wp_query->max_num_pages <= 1) {
            return NULL;
        }
        $paged = get_query_var("paged") ? absint(get_query_var("paged")) : 1;
        $max = intval($wp_query->max_num_pages);
        if (1 <= $paged) {
            $links[] = $paged;
        }
        if (4 <= $paged) {
            $links[] = $paged - 1;
            $links[] = $paged - 2;
            $links[] = $paged - 3;
        }
        if ($paged + 3 <= $max) {
            $links[] = $paged + 3;
            $links[] = $paged + 2;
            $links[] = $paged + 1;
        }
        echo "<div class=\"navigation\"><ul>\n";
        if (get_previous_posts_link()) {
            printf("<li class=\"prebtn\">%s</li>\n", get_previous_posts_link());
        }
        if (!in_array(1, $links)) {
            $class = 1 == $paged ? " class=\"active\"" : "";
            printf("<li%s><a href=\"%s\">%s</a></li>\n", $class, esc_url(get_pagenum_link(1)), "1");
            if (!in_array(2, $links)) {
                echo "<li class=\"Separator\">…</li>";
            }
        }
        sort($links);
        foreach ( $links as $link) {
            $class = $paged == $link ? " class=\"active\"" : "";
            printf("<li%s><a href=\"%s\">%s</a></li>\n", $class, str_replace("?page", "&page", esc_url(get_pagenum_link(1))), $link);
        }
        if (!in_array($max, $links)) {
            if (!in_array($max - 1, $links)) {
                echo "<li class=\"Separator\">…</li>\n";
            }
            $class = $paged == $max ? " class=\"active\"" : "";
            printf("<li%s><a href=\"%s\">%s</a></li>\n", $class, esc_url(get_pagenum_link($max)), $max);
        }
        if (get_next_posts_link()) {
            printf("<li>%s</li>\n", get_next_posts_link());
        }
        echo "</ul></div>\n";
    }
    public function YC_SearchPagination()
    {
        if (is_singular()) {
            return NULL;
        }
        global $wp_query;
        if ($wp_query->max_num_pages <= 1) {
            return NULL;
        }
        $paged = get_query_var("paged") ? absint(get_query_var("paged")) : 1;
        $max = intval($wp_query->max_num_pages);
        if (1 <= $paged) {
            $links[] = $paged;
        }
        if (4 <= $paged) {
            $links[] = $paged - 1;
            $links[] = $paged - 2;
            $links[] = $paged - 3;
        }
        if ($paged + 3 <= $max) {
            $links[] = $paged + 3;
            $links[] = $paged + 2;
            $links[] = $paged + 1;
        }
        echo "<div class=\"navigation\"><ul>\n";
        if (get_previous_posts_link()) {
            printf("<li class=\"prebtn\">%s</li>\n", str_replace("?page", "&page", get_previous_posts_link()));
        }
        if (!in_array(1, $links)) {
            $class = 1 == $paged ? " class=\"active\"" : "";
            printf("<li%s><a href=\"%s\">%s</a></li>\n", $class, str_replace("?page", "&page", esc_url(get_pagenum_link(1))), "1");
            if (!in_array(2, $links)) {
                echo "<li class=\"Separator\">…</li>";
            }
        }
        sort($links);
        foreach ((int) $links as $link) {
            $class = $paged == $link ? " class=\"active\"" : "";
            printf("<li%s><a href=\"%s\">%s</a></li>\n", $class, str_replace("?page", "&page", esc_url(get_pagenum_link(1))), $link);
        }
        if (!in_array($max, $links)) {
            if (!in_array($max - 1, $links)) {
                echo "<li class=\"Separator\">…</li>\n";
            }
            $class = $paged == $max ? " class=\"active\"" : "";
            printf("<li%s><a href=\"%s\">%s</a></li>\n", $class, str_replace("?page", "&page", esc_url(get_pagenum_link($max))), $max);
        }
        if (get_next_posts_link()) {
            printf("<li>%s</li>\n", get_next_posts_link());
        }
        echo "</ul></div>\n";
    }
    public function rightList($name, $post, $id, $img, $tax = true)
    {
        if (!$tax && get_post_meta($post, $id, 1) != "") {
            echo "<li>";
            echo "<i class=\"" . $img . "\"></i>";
            echo "<span>" . $name . "</span>";
            if ($tax) {
                if (get_the_terms($post, $id, "")) {
                    foreach (array_slice(get_the_terms($post, $id, ""), 0, 3) as $na) {
                        echo "<a  href=\"" . get_term_link($na) . "\">" . $na->name . "</a> ";
                    }
                }
            } else {
                if ($id == "imdbRating") {
                    if (get_post_meta($post, "number", 1) != "") {
                        echo "<strong><a href=\"" . home_url() . "/rateser\">" . get_post_meta($post, $id, 1) . "</a></strong>";
                    } else {
                        echo "<strong><a href=\"" . home_url() . "/rate\">" . get_post_meta($post, $id, 1) . "</a></strong>";
                    }
                } else {
                    echo "<strong>" . get_post_meta($post, $id, 1) . "</strong>";
                }
            }
            echo "</li>";
        } else {
            if ($tax && get_the_terms($post, $id, 1)) {
                echo "<li>";
                echo "<i class=\"" . $img . "\"></i>";
                echo "<span>" . $name . "</span>";
                foreach (array_slice(get_the_terms($post, $id, ""), 0, 3) as $na) {
                    echo "<a  href=\"" . get_term_link($na) . "\">" . $na->name . "</a> ";
                }
                echo "</li>";
            }
        }
    }
    public function listTax($name, $post, $tax)
    {
        $category = get_the_terms($post, $tax, "");
        if (!empty($category)) {
            echo "<li> ";
            echo "<span>" . $name . "</span>";
            foreach (array_slice(is_array($category) ? $category : [], 0, 3) as $cat) {
                echo "<a  href=\"" . get_term_link($cat) . "\">";
                echo $cat->name;
                echo "</a>";
            }
            echo "</li>";
        }
    }
    public function filmBlock($id)
    {
        echo "<div class=\"MovieItem\">";
        echo "<a title=\"" . get_the_title($id) . "\" href=\"" . get_the_permalink($id) . "\" alt=\"" . get_the_title($id) . "\">";
        if (get_post_meta($id, "ribbon", 1)) {
            echo "<div class=\"reboon\">" . get_post_meta($id, "ribbon", 1) . "</div>";
        }
        if (get_the_terms($id, "category", 1)) {
            echo "<div class=\"cat\">";
            foreach (array_slice(is_array(get_the_terms($id, "category", 1)) ? get_the_terms($id, "category", 1) : [], 0, 1) as $cat) {
                echo "<strong>" . $cat->name . "</strong>";
            }
            echo "</div>";
        }
        echo "<div class=\"FrontBlock\">";
        echo "<img data-src=\"" . get_the_post_thumbnail_url($id, "mysize") . "\">";
        if (get_post_meta($id, "imdbRating", true)) {
            echo "<span class=\"imdb\"><i class=\"fa fa-star\"></i>" . get_post_meta($id, "imdbRating", true) . "</span>";
        }
        echo "<div class=\"TitleBlock\"><ul class=\"cats\">";
        if (get_the_terms($id, "genre", "")) {
            foreach (array_slice(get_the_terms($id, "genre", ""), 0, 3) as $cat) {
                echo "<li>" . $cat->name . "</li>";
            }
        }
        echo "</ul>";
        echo get_the_title($id) . "</div>";
        echo "</div><div class=\"BackBlock\">";
        echo "<div class=\"ContentBlock\" title=\"قصة  " . get_the_title($id) . "\" alt=\"قصة  " . get_the_title($id) . "\">" . wp_trim_words(get_the_content(), 12, " [ .. ] ");
        echo "</div></div></a></div>";
    }
    public function serBlock($term)
    {
        echo "<div class=\"MovieItem\">";
        list($id) = get_posts(["post_type" => "post", "fields" => "ids", "posts_per_page" => 1, "series" => $term->slug]);

        if (get_post_meta($id, "ribbon", 1)) {
            echo "<div class=\"reboon\">" . get_post_meta($id, "ribbon", 1) . "</div>";
        }
        if (get_the_terms($id, "category", 1)) {
            echo "<div class=\"cat\">";
            foreach (array_slice(is_array(get_the_terms($id, "category", 1)) ? get_the_terms($id, "category", 1) : [], 0, 1) as $cat) {
                echo "<strong>" . $cat->name . "</strong>";
            }
            echo "</div>";
        }
        echo "<div class=\"FrontBlock\">";
        if (get_term_meta($term->term_id, "image", 1)) {
            echo "<img data-src=\"" . get_term_meta($term->term_id, "image", 1) . "\">";
        } else {
            echo "<img data-src=\"" . get_the_post_thumbnail_url($id) . "\">";
        }
        if (get_post_meta($id, "imdbRating", true)) {
            echo "<span class=\"imdb\"><i class=\"fa fa-star\"></i>" . get_post_meta($id, "imdbRating", true) . "</span>";
        }
        echo "<div class=\"TitleBlock\"><ul class=\"cats\">";
        if (get_the_terms($id, "genre", "")) {
            foreach (array_slice(get_the_terms($id, "genre", ""), 0, 3) as $cat) {
                echo "<li>" . $cat->name . "</li>";
            }
        }
        echo "</ul>";
        echo $term->name . "</div>";
        echo "</div><div class=\"BackBlock\">";
        echo "<div class=\"ContentBlock\">" . wp_trim_words($term->description, 12, ".. ");
        echo "</div></div></a></div>";
    }
    public function sectionBlock($id)
    {
       $post  = get_post($post->ID); ?>
    <div class="MovieItem">
	<a href="<?php the_permalink(); ?>">
		 <?php
        echo "<img data-src=\"" . get_the_post_thumbnail_url($post, "mysize") . "\">";
        echo "<div class=\"TitleBlock\"><ul class=\"cats\">";
        if (get_the_terms($post, "genre", "")) {
            foreach (array_slice(get_the_terms($post, "genre", ""), 0, 3) as $cat) {
                echo "<li>" . $cat->name . "</li>";
            }
        }
        echo "</ul>";
        echo get_the_title($post) . "</div>";
		 if (get_the_terms($id, "category", 1)) {
            echo "<div class=\"cat\">";
            foreach (array_slice(is_array(get_the_terms($post, "category", 1)) ? get_the_terms($post, "category", 1) : [], 0, 1) as $cat) {
                echo "<strong>" . $cat->name . "</strong>";
            }
            echo "</div>";
        }
		 if(!empty(get_the_terms($post->ID,"genre"))){ ?>
			<?php foreach(array_slice(get_the_terms($post->ID,"genre"), 0,1) as $term){ ?>
				<span class="genre"><?= $term->name ?></span>
			<?php } ?>
		<?php } ?>
		<?php if(!empty(get_the_terms($post->ID,"quality"))){ ?>
			<?php foreach(array_slice(get_the_terms($post->ID,"quality"), 0,1) as $term){ ?>
				<span class="quality"><?= $term->name ?></span>
			<?php } ?>
		<?php } ?>
		<?php 	if(!empty(get_post_meta( $post->ID, 'number', 1 ))){ ?>
			<div class="number"><span>الحلقة</span><em><?=get_post_meta( $post->ID, 'number', 1 ) ?></em></div>
		<?php } ?>
		<?php if(!empty(get_post_meta( $post->ID, 'ribbon', 1 ))){ ?>
			<div class="ribbon"><?=get_post_meta( $post->ID, 'ribbon', 1 ) ?></div>
		<?php } ?>
			<div class="SectionTitle">
			<p><?= wp_trim_words( get_the_content($post->ID), 10, " ...." ); ?></p>
			<h4><? the_title(); ?></h4>
		</div>
	</a>
</div>
<?php
}
    public function AddComment()
    {
        $time = current_time("mysql");
        $data = ["comment_post_ID" => $_POST["postID"], "comment_author" => $_POST["name"], "comment_author_email" => $_POST["email"], "comment_content" => $_POST["message"], "comment_parent" => 0, "comment_date" => $time];
        $data["comment_approved"] = 0;
        if (is_user_logged_in()) {
            $data["user_id"] = wp_get_current_user()->ID;
            if (current_user_can("editor") || current_user_can("administrator") || current_user_can("author")) {
                $data["comment_approved"] = 1;
            }
        }
        $cid = wp_insert_comment($data);
        $this->CommentItem(get_comment($cid), $_POST["postID"]);
        wp_die();
    }
    public function Reaction()
    {
        $id = $_POST["id"];
        $type = $_POST["type"];
        $emote = $_POST["emote"];
        $userkey = $type == "term" ? "emotes_" . $emote . "_term" : "emotes_" . $emote . "_posts";
        $v = $type == "term" ? get_term_meta($id, "emotes", true) : get_post_meta($id, "emotes", true);
        $emotes = is_array($v) ? $v : [];
        if (is_user_logged_in()) {
            global $current_user;
            $userlist = get_user_meta($current_user->ID, $userkey, true);
            if (in_array($id, $userlist)) {
                $emotes[$emote] = $emotes[$emote] - 1;
            } else {
                if (isset($emotes[$emote])) {
                    $emotes[$emote] = $emotes[$emote] + 1;
                } else {
                    $emotes[$emote] = 1;
                }
            }
            $restemotes = ["great", "good", "okay", "bad", "terrible"];
            foreach ($restemotes as $emt) {
                if ($emt != $emote) {
                    $userkey2nd = $type == "term" ? "emotes_" . $emt . "_term" : "emotes_" . $emt . "_posts";
                    $userlist2nd = get_user_meta($current_user->ID, $userkey2nd, true);
                    if (isset($userlist2nd[$id])) {
                        $emotes[$emt] = $emotes[$emt] - 1;
                        unset($userlist2nd[$id]);
                        update_user_meta($current_user->ID, $userkey2nd, $userlist2nd);
                    }
                }
            }
        } else {
            if (isset($emotes[$emote])) {
                $emotes[$emote] = $emotes[$emote] + 1;
            } else {
                $emotes[$emote] = 1;
            }
        }
        if ($type == "term") {
            update_term_meta($id, "emotes", $emotes);
        } else {
            update_post_meta($id, "emotes", $emotes);
        }
        if (is_user_logged_in()) {
            $v = get_user_meta($current_user->ID, $userkey, true);
            $list = is_array($v) ? $v : [];
            if (isset($list[$id])) {
                unset($list[$id]);
            } else {
                $list[$id] = $id;
            }
            update_user_meta($current_user->ID, $userkey, $list);
        }
        $this->ReactionStats($id, $type);
        wp_die();
    }
    public function ReactionStats($id, $type)
    {
        if ($type == "term") {
            $v = get_term_meta($id, "emotes", true);
        } else {
            $v = get_post_meta($id, "emotes", true);
        }
        $names = ["great" => "رائع", "good" => "جيد", "okay" => "مقبول", "bad" => "سيء", "terrible" => "مزعج"];
        echo "<ul>";
        $found = false;
        foreach ($names as $emo => $name) {
            if (isset($v[$emo])) {
                $found = true;
                $count = $v[$emo];
                if (0 < $count) {
                    echo "<li class=\"" . $emo . "\">";
                    if ($emo == "great") {
                        echo "<i class=\"fas fa-smile-beam\"></i>";
                    } else {
                        if ($emo == "good") {
                            echo "<i class=\"fas fa-smile-wink\"></i>";
                        } else {
                            if ($emo == "okay") {
                                echo "<i class=\"fas fa-grin-alt\"></i>";
                            } else {
                                if ($emo == "bad") {
                                    echo "<i class=\"fas fa-meh\"></i>";
                                } else {
                                    if ($emo == "terrible") {
                                        echo "<i class=\"fas fa-tired\"></i>";
                                    }
                                }
                            }
                        }
                    }
                    echo "<span>" . $name . "</span>";
                    echo "<em>" . $count . "</em>";
                    echo "</li>";
                }
            }
        }
        if (!$found) {
            echo "<p>كن اول من يضع تقييم !..</p>";
        }
        echo "</ul>";
    }
    public function VisitorReview($postID)
    {
        echo "<div class=\"VisitorReview\">";
        $meta = "post";
        if (!isset(get_post($postID)->post_title)) {
            $meta = "term";
        }
        if ($meta == "post") {
            $rates = is_array(get_post_meta($postID, "rateHistor", true)) ? get_post_meta($postID, "rateHistor", true) : [];
        } else {
            $rates = is_array(get_term_meta($postID, "rateHistor", true)) ? get_term_meta($postID, "rateHistor", true) : [];
        }
        echo "<div class=\"Stars\" data-post=\"" . $postID . "\">";
        echo "<div class=\"Star\" data-num=\"2\" data-values=\"love\" data-star=\"احببتة\"><svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 512.009 512.009\" style=\"enable-background:new 0 0 512.009 512.009;\" xml:space=\"preserve\"> <circle style=\"fill:#F7B239;\" cx=\"256.004\" cy=\"256.004\" r=\"256.004\"></circle> <path style=\"fill:#E09B2D;\" d=\"M121.499,390.501C29.407,298.407,22.15,153.608,99.723,53.204 c-8.593,6.638-16.861,13.895-24.743,21.777c-99.974,99.974-99.974,262.065,0,362.038s262.065,99.974,362.038,0 c7.881-7.881,15.138-16.15,21.777-24.743C358.392,489.85,213.593,482.593,121.499,390.501z\"></path> <g> <path style=\"fill:#4D4D4D;\" d=\"M196.533,242.016c-3.23,0-6.379-1.65-8.155-4.623c-8.571-14.347-23.667-22.913-40.38-22.913 s-31.809,8.566-40.38,22.913c-2.687,4.499-8.511,5.968-13.012,3.279c-4.499-2.688-5.966-8.513-3.279-13.012 c12.03-20.136,33.215-32.156,56.671-32.156s44.641,12.022,56.671,32.156c2.688,4.499,1.22,10.325-3.279,13.012 C199.867,241.582,198.189,242.016,196.533,242.016z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M412.536,242.016c-3.23,0-6.379-1.65-8.155-4.623c-8.571-14.347-23.667-22.913-40.38-22.913 s-31.809,8.566-40.38,22.913c-2.687,4.499-8.512,5.968-13.012,3.279c-4.499-2.688-5.966-8.513-3.279-13.012 c12.03-20.136,33.215-32.156,56.671-32.156c23.456,0,44.641,12.022,56.671,32.156c2.688,4.499,1.22,10.325-3.279,13.012 C415.87,241.582,414.192,242.016,412.536,242.016z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M273.729,402.311c-5.24,0-9.489-4.248-9.489-9.489c0-5.24,4.248-9.489,9.489-9.489 c11.041,0,20.022-8.981,20.022-20.021s-8.981-20.022-20.022-20.022c-5.24,0-9.489-4.248-9.489-9.489 c0-5.24,4.248-9.489,9.489-9.489c11.041,0,20.022-8.983,20.022-20.022c0-11.04-8.981-20.021-20.022-20.021 c-5.24,0-9.489-4.248-9.489-9.489c0-5.24,4.248-9.489,9.489-9.489c21.505,0,39,17.495,39,38.998 c0,11.779-5.248,22.354-13.53,29.511c8.282,7.157,13.53,17.732,13.53,29.511C312.729,384.816,295.234,402.311,273.729,402.311z\"></path> </g> <path style=\"fill:#F95428;\" d=\"M409.54,288.494L409.54,288.494c-10.123-19.386-34.043-26.896-53.429-16.773l0,0 c-19.386,10.123-26.896,34.043-16.773,53.429l0,0l36.655,70.202l70.202-36.655l0,0c19.386-10.123,26.896-34.043,16.773-53.429l0,0 C452.846,285.881,428.925,278.371,409.54,288.494L409.54,288.494z\"></path> </svg><span>احببتة</span>";
        echo "<em>" . (isset($rates["love"]) ? $rates["love"] : "0") . "</em>";
        echo "</div><div class=\"Star\" data-num=\"3\" data-values=\"funny\" data-star=\"اضحكني \"><svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 512.009 512.009\" style=\"enable-background:new 0 0 512.009 512.009;\" xml:space=\"preserve\"> <circle style=\"fill:#F7B239;\" cx=\"256.004\" cy=\"256.004\" r=\"256.004\"></circle> <path style=\"fill:#E09B2D;\" d=\"M121.499,390.501C29.407,298.407,22.15,153.608,99.723,53.204 c-8.593,6.638-16.861,13.895-24.743,21.777c-99.974,99.974-99.974,262.065,0,362.038s262.065,99.974,362.038,0 c7.881-7.881,15.138-16.15,21.777-24.743C358.392,489.85,213.593,482.593,121.499,390.501z\"></path> <path style=\"fill:#FFFFFF;\" d=\"M126.955,264.261h258.092c0,14.486-2.391,28.415-6.794,41.421H133.749 C129.346,292.676,126.955,278.747,126.955,264.261z\"></path> <path style=\"fill:#A81004;\" d=\"M133.749,305.682h244.504c-8.679,25.632-25.189,47.633-46.684,63.182 c-9.033-15.22-25.632-25.417-44.622-25.417c-11.602,0-22.305,3.808-30.946,10.248c-8.641-6.44-19.357-10.248-30.958-10.248 c-18.977,0-35.589,10.197-44.609,25.417C158.938,353.315,142.428,331.314,133.749,305.682z\"></path> <path style=\"fill:#F95428;\" d=\"M332.606,370.686c-0.329-0.62-0.683-1.227-1.037-1.822c-9.033-15.22-25.632-25.417-44.622-25.417 c-11.602,0-22.305,3.808-30.946,10.248c-8.641-6.44-19.357-10.248-30.958-10.248c-18.977,0-35.589,10.197-44.609,25.417 c-0.354,0.595-0.708,1.202-1.037,1.822v6.414c0,42.308,34.297,76.605,76.605,76.605l0,0c42.308,0,76.605-34.297,76.605-76.605 L332.606,370.686L332.606,370.686z\"></path> <path style=\"fill:#E54728;\" d=\"M331.568,368.863c-9.033-15.22-25.632-25.417-44.622-25.417c-11.602,0-22.305,3.808-30.946,10.248 c-8.641-6.44-19.357-10.248-30.958-10.248c-18.977,0-35.589,10.197-44.609,25.417c-0.354,0.595-0.708,1.202-1.037,1.822v6.414 c0,7.137,0.997,14.037,2.823,20.59c9.328-13.656,25.036-22.615,42.824-22.615c11.601,0,22.317,3.808,30.958,10.248 c8.641-6.44,19.344-10.248,30.946-10.248c17.801,0,33.5,8.96,42.837,22.617c1.826-6.555,2.823-13.455,2.823-20.593v-6.414 C332.277,370.066,331.923,369.457,331.568,368.863z\"></path> <g> <path style=\"fill:#4D4D4D;\" d=\"M205.155,212.645c0.858-3.756-0.64-7.659-3.793-9.876l-56.299-39.589 c-4.286-3.014-10.205-1.982-13.22,2.304c-3.014,4.286-1.982,10.205,2.304,13.22l37.322,26.244l-78.323,12.931 c-5.171,0.854-8.67,5.737-7.816,10.908c0.767,4.647,4.79,7.944,9.351,7.944c0.514,0,1.034-0.042,1.557-0.128l101.213-16.71 C201.252,219.266,204.297,216.401,205.155,212.645z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M418.853,217.88l-78.323-12.931l37.322-26.244c4.286-3.015,5.319-8.933,2.304-13.22 c-3.015-4.288-8.935-5.319-13.22-2.304l-56.299,39.589c-3.153,2.217-4.651,6.118-3.793,9.876c0.858,3.758,3.903,6.621,7.705,7.248 l101.213,16.71c0.524,0.086,1.044,0.128,1.557,0.128c4.56,0,8.583-3.297,9.351-7.944 C427.524,223.616,424.024,218.733,418.853,217.88z\"></path> </g>                </svg><span>اضحكني </span>";
        echo "<em>" . (isset($rates["funny"]) ? $rates["funny"] : "0") . "</em>";
        echo "</div><div class=\"Star\" data-num=\"4\" data-values=\"wow\" data-star=\"ادهشني \"><svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 512.009 512.009\" style=\"enable-background:new 0 0 512.009 512.009;\" xml:space=\"preserve\"> <circle style=\"fill:#F7B239;\" cx=\"256.004\" cy=\"256.004\" r=\"256.004\"></circle> <path style=\"fill:#E09B2D;\" d=\"M121.499,390.501C29.407,298.407,22.15,153.608,99.723,53.204 c-8.593,6.638-16.861,13.895-24.743,21.777c-99.974,99.974-99.974,262.065,0,362.038s262.065,99.974,362.038,0 c7.881-7.881,15.138-16.15,21.777-24.743C358.392,489.85,213.593,482.593,121.499,390.501z\"></path> <path style=\"fill:#A81004;\" d=\"M304.789,362.943c0,12.93-2.72,25-7.414,35.209c-8.616,18.75-23.924,31.211-41.371,31.211 s-32.755-12.462-41.371-31.211c-4.706-10.21-7.426-22.279-7.426-35.209c0-36.677,21.849-66.421,48.797-66.421 S304.789,326.266,304.789,362.943z\"></path> <path style=\"fill:#F95428;\" d=\"M297.375,398.152c-8.616,18.75-23.924,31.211-41.371,31.211s-32.755-12.462-41.371-31.211 c3.365-0.683,6.844-1.05,10.412-1.05c4.296,0,8.471,0.522,12.466,1.507c12.123,2.99,24.863,2.987,36.986-0.003 c3.989-0.983,8.159-1.506,12.453-1.506C290.518,397.102,294.01,397.469,297.375,398.152z\"></path> <g> <path style=\"fill:#4D4D4D;\" d=\"M142.673,190.646c-19.358,0-35.107,15.749-35.107,35.107s15.749,35.107,35.107,35.107 s35.107-15.749,35.107-35.107S162.031,190.646,142.673,190.646z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M369.327,190.646c-19.358,0-35.107,15.749-35.107,35.107s15.749,35.107,35.107,35.107 s35.107-15.749,35.107-35.107S388.685,190.646,369.327,190.646z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M369.326,115.171c-23.455,0-44.64,12.022-56.67,32.156c-2.687,4.499-1.22,10.325,3.279,13.012 c4.501,2.688,10.326,1.22,13.012-3.279c8.571-14.347,23.666-22.912,40.379-22.913c16.714,0,31.81,8.566,40.381,22.913 c1.776,2.974,4.925,4.623,8.154,4.623c1.656,0,3.334-0.434,4.858-1.345c4.499-2.688,5.966-8.513,3.279-13.012 C413.967,127.191,392.782,115.171,369.326,115.171z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M199.344,147.327c-12.03-20.135-33.215-32.156-56.67-32.156c-0.001,0,0.001,0-0.001,0 c-23.453,0-44.641,12.023-56.671,32.156c-2.687,4.499-1.22,10.325,3.279,13.012c1.525,0.911,3.201,1.345,4.858,1.345 c3.229,0,6.378-1.65,8.154-4.623c8.571-14.347,23.667-22.913,40.381-22.913c16.713,0,31.807,8.566,40.379,22.913 c2.688,4.499,8.514,5.966,13.012,3.279C200.564,157.652,202.032,151.826,199.344,147.327z\"></path> </g></svg><span>ادهشني </span>";
        echo "<em>" . (isset($rates["wow"]) ? $rates["wow"] : "0") . "</em>";
        echo "</div><div class=\"Star\" data-num=\"5\" data-values=\"sad\" data-star=\"احزنني\"><svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 512.009 512.009\" style=\"enable-background:new 0 0 512.009 512.009;\" xml:space=\"preserve\"> <circle style=\"fill:#F7B239;\" cx=\"256.004\" cy=\"256.004\" r=\"256.004\"></circle> <path style=\"fill:#E09B2D;\" d=\"M121.499,390.501C29.407,298.407,22.15,153.608,99.723,53.204 c-8.593,6.638-16.861,13.895-24.743,21.777c-99.974,99.974-99.974,262.065,0,362.038s262.065,99.974,362.038,0 c7.881-7.881,15.138-16.15,21.777-24.743C358.392,489.85,213.593,482.593,121.499,390.501z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M304.789,362.943c0,12.93-2.72,25-7.414,35.209c-8.616,18.75-23.924,31.211-41.371,31.211 s-32.755-12.462-41.371-31.211c-4.706-10.21-7.426-22.279-7.426-35.209c0-36.677,21.849-66.421,48.797-66.421 S304.789,326.266,304.789,362.943z\"></path> <path style=\"fill:#F2F2F2;\" d=\"M214.621,327.734c8.616-18.75,23.924-31.211,41.371-31.211s32.755,12.462,41.371,31.211 c-1.519,0.309-23.6,8.918-41.371,8.947C234.413,336.718,216.466,328.108,214.621,327.734z\"></path> <g> <path style=\"fill:#2197D8;\" d=\"M428.977,431.138c0,5.946-0.696,10.944-1.872,15.283c-26.657,23.962-58.362,42.408-93.331,53.541 c2.391-31.907,26.733-33.641,26.733-68.824c0-37.006-26.923-37.006-26.923-74.012s26.923-37.006,26.923-74.012 c0-36.563-26.303-36.993-26.91-72.721c24.734,1.594,50.328,7.996,70.406,14.284c6.161,22.444,24.974,27.517,24.974,58.438 c0,37.006-26.923,37.006-26.923,74.012S428.977,394.132,428.977,431.138z\"></path> <path style=\"fill:#2197D8;\" d=\"M151.49,283.114c0,37.006,26.923,37.006,26.923,74.012s-26.923,37.006-26.923,74.012 c0,35.184,24.342,36.917,26.733,68.824c-34.969-11.133-66.674-29.579-93.331-53.541c-1.177-4.34-1.872-9.337-1.872-15.283 c0-37.006,26.923-37.006,26.923-74.012S83.02,320.12,83.02,283.114c0-30.92,18.813-35.994,24.974-58.438 c20.078-6.288,45.672-12.69,70.406-14.284C177.792,246.121,151.49,246.551,151.49,283.114z\"></path> </g> <g> <path style=\"fill:#4D4D4D;\" d=\"M70.221,247.971c-3.646,0-7.123-2.113-8.687-5.664c-2.114-4.795,0.059-10.396,4.854-12.51 c0.653-0.288,16.245-7.128,38.772-14.176c18.093-5.667,35.14-9.763,50.929-12.248c-14.317-5.477-33.393-10.439-55.509-10.439 c-5.242,0-9.489-4.248-9.489-9.489s4.247-9.489,9.489-9.489c55.615,0,93.247,27.258,94.822,28.418 c3.3,2.432,4.666,6.708,3.386,10.601c-1.28,3.894-4.915,6.527-9.014,6.527c-3.541,0-7.157,0.12-10.746,0.358 c-19.981,1.288-42.919,5.954-68.198,13.871c-21.524,6.734-36.634,13.364-36.784,13.431C72.8,247.711,71.5,247.971,70.221,247.971z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M441.775,247.971c-1.278,0-2.576-0.259-3.821-0.807l0,0c-0.151-0.067-15.341-6.722-36.784-13.431 c-25.282-7.917-48.22-12.583-68.184-13.87c-3.606-0.239-7.216-0.359-10.75-0.359c-4.099,0-7.734-2.633-9.014-6.527 c-1.28-3.894,0.085-8.17,3.386-10.601c1.575-1.16,39.207-28.418,94.808-28.418c5.242,0,9.489,4.248,9.489,9.489 s-4.247,9.489-9.489,9.489c-22.111,0-41.182,4.962-55.499,10.44c15.782,2.484,32.828,6.581,50.921,12.248 c22.526,7.048,38.117,13.888,38.77,14.176c4.795,2.114,6.968,7.715,4.854,12.51C448.897,245.858,445.42,247.971,441.775,247.971z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M94.139,154.726c-1.657,0-3.334-0.433-4.858-1.345c-4.499-2.688-5.966-8.513-3.279-13.012 c12.03-20.135,33.218-32.156,56.671-32.156c0.003,0,0,0,0.001,0c23.455,0,44.64,12.022,56.67,32.156 c2.687,4.499,1.22,10.325-3.279,13.012c-4.498,2.688-10.325,1.22-13.012-3.279c-8.571-14.347-23.666-22.912-40.379-22.913 c-16.714,0-31.81,8.566-40.381,22.913C100.517,153.076,97.368,154.726,94.139,154.726z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M320.793,154.726c-1.657,0-3.334-0.433-4.858-1.345c-4.499-2.688-5.966-8.513-3.279-13.012 c12.03-20.135,33.218-32.156,56.671-32.156c0.003,0,0,0,0.001,0c23.455,0,44.64,12.022,56.67,32.156 c2.687,4.499,1.22,10.325-3.279,13.012c-4.498,2.688-10.325,1.22-13.012-3.279c-8.571-14.347-23.666-22.912-40.379-22.913 c-16.714,0-31.81,8.566-40.381,22.913C327.171,153.076,324.021,154.726,320.793,154.726z\"></path></g></svg><span>احزنني</span>";
        echo "<em>" . (isset($rates["sad"]) ? $rates["sad"] : "0") . "</em>";
        echo "</div><div class=\"Star\" data-num=\"8\" data-values=\"lol\" data-star=\"لول\"><svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 512.009 512.009\" style=\"enable-background:new 0 0 512.009 512.009;\" xml:space=\"preserve\"> <circle style=\"fill:#F7B239;\" cx=\"256.004\" cy=\"256.004\" r=\"256.004\"></circle> <path style=\"fill:#E09B2D;\" d=\"M121.499,390.501C29.407,298.407,22.15,153.608,99.723,53.204 c-8.593,6.638-16.861,13.895-24.743,21.777c-99.974,99.974-99.974,262.065,0,362.038s262.065,99.974,362.038,0 c7.881-7.881,15.138-16.15,21.777-24.743C358.392,489.85,213.593,482.593,121.499,390.501z\"></path> <path style=\"fill:#333333;\" d=\"M256.001,182.226L256.001,182.226c15.091,0,30.096-2.051,44.698-5.859 c55.461-14.463,116.542-5.486,154.612,3.301c20.299,4.686,32.012,25.969,25.059,45.608l-21.436,60.535 c-4.927,13.912-18.308,23.021-33.057,22.502l-97.657-3.439c-16.458-0.579-30.369-12.376-33.628-28.519l-4.934-24.431 c-3.235-16.018-17.314-27.535-33.654-27.532l0,0l0,0c-16.343,0-30.421,11.519-33.656,27.539l-4.933,24.425 c-3.26,16.142-17.171,27.938-33.628,28.519l-97.657,3.439c-14.749,0.52-28.132-8.589-33.057-22.502l-21.436-60.535 c-6.955-19.639,4.76-40.921,25.059-45.608c38.07-8.787,99.15-17.764,154.612-3.301C225.905,180.175,240.91,182.226,256.001,182.226 L256.001,182.226z\"></path> <path style=\"fill:#4D4D4D;\" d=\"M256.279,396.633c-2.816,0-5.645-0.053-8.489-0.161c-44.544-1.684-83.5-16.515-106.882-40.691 c-3.644-3.768-3.542-9.775,0.224-13.417c3.768-3.645,9.775-3.542,13.417,0.224c41.719,43.137,143.226,47.322,193.95,7.993 c2.599-2.014,7.528-6.636,9.208-8.246c3.782-3.626,9.787-3.501,13.416,0.282c3.627,3.783,3.501,9.789-0.282,13.416 c-0.691,0.662-6.861,6.559-10.713,9.546C334.44,385.493,296.96,396.633,256.279,396.633z\"></path></svg><span>لول</span>";
        echo "<em>" . (isset($rates["lol"]) ? $rates["lol"] : "0") . "</em>";
        echo "</div></div></div>";
    }
    public function exploreBlock($net)
    {
        if (is_object($net)) {
            echo "<li style=\"order:" . get_term_meta($net->term_id, "order", 1) . "\"><a href=\"" . get_term_link($net) . "\">";
            echo "<span class=\"follow\">متابعة  <span class=\"num\">" . $net->count . " موضوع</span></span>";
            if (get_term_meta($net->term_id, "image", 1)) {
                echo "<img data-src=\"" . get_term_meta($net->term_id, "image", 1) . "\">";
            } else {
                echo "<img data-src=\"" . get_option("eximage")["url"] . "\" />";
            }
            echo "<h2>" . $net->name . "</h2>";
            echo "</a></li>";
        }
    }
    public function sliderBlock($id)
    {
        echo "<li class=\"item\">";
        echo "<a href=\"" . get_the_permalink($id) . "\">";
        if (get_post_meta($id, "imdbRating", 1) != "") {
            echo "<div class=\"imdbS\"><span><i class=\"fa fa-star\"></i></span>";
            echo "<strong>" . get_post_meta($id, "imdbRating", 1) . "</strong>";
            echo "</div>";
        }
        if (get_the_terms($id, "category", 1)) {
            echo "<div class=\"cat\">";
            foreach (array_slice(is_array(get_the_terms($id, "category", 1)) ? get_the_terms($id, "category", 1) : [], 0, 1) as $cat) {
                echo "<strong>" . $cat->name . "</strong>";
            }
            echo "</div>";
        }
         if (get_the_terms($id, "quality", 1)) {
            echo "<div class=\"qualityPase\">";
            foreach (array_slice(is_array(get_the_terms($id, "quality", 1)) ? get_the_terms($id, "quality", 1) : [], 0, 1) as $quality) {
                echo "<strong>" . $quality->name . "</strong>";
            }
               echo "</div>";
        }
        if (get_post_meta($id, "number", 1)) {
            echo "<div class=\"numberPase\"><span>الحلقة </span><em>" . get_post_meta($id, "number", 1) . "</em></div>";
        }

        echo "<div class=\"PosterBG\" data-style=\"background-image: url(" . get_the_post_thumbnail_url($id) . ");\"></div>";
        echo "<i class=\"fa fa-play\"></i><div class=\"TitleItem\">";
        echo " <h1 alt=\"" . get_the_title($id) . "\" title=\"" . get_the_title($id) . "\">";
        if (get_the_terms($id, "genre", "")) {
            echo "<ul class=\"cats\">";
            foreach (array_slice(get_the_terms($id, "genre", ""), 0, 3) as $cat) {
                echo "<li>" . $cat->name . "</li>";
            }
            echo "</ul>";
        }
        echo get_the_title($id) . "</h1>";
        echo "</div></a></li>";
    }
    public function siteColor()
    {
        $mainStyle = $_POST["color"];
        setcookie("themeColor", $mainStyle, time() + 31556926, "/");
        echo $mainStyle;
        wp_die();
    }
    public function SearchComplete()
    {
        if (get_posts(["post_type" => "post", "posts_per_page" => 15, "s" => $_GET["search"], "fields" => "ids"])) {
            foreach (get_posts(["post_type" => "post", "posts_per_page" => 15, "s" => $_GET["search"], "fields" => "ids"]) as $post) {
                echo "<li><div class=\"SearchThumb\">";
                echo "<a href=\"" . get_the_permalink($post) . "\">";
                echo get_the_post_thumbnail($post, "full");
                echo " </a></div><div class=\"SearchResultInner\">";
                echo "<h1><a href=\"" . get_the_permalink($post) . "\">" . get_the_title($post) . "</a></h1>";
                echo "</div></li>";
            }
            echo "<a href=\"" . home_url() . "/search/" . $_GET["search"] . "\">مشاهدة المزيد</a>";
        } else {
            echo "<div class=\"NoSearchResults\">لا يوجد نتائج لكلمة البحث <strong>" . $_GET["search"] . "</strong></div>";
        }
        wp_die();
    }
    public function series_slug($post)
    {
        $series_info = [];
        $series = get_the_terms($post, "series", "");
        if (!empty($series)) {
            foreach ($series as $ser) {
                if ($ser->parent == 0) {
                    $series_info["parent"] = $ser->term_id;
                    if (!get_categories(["taxonomy" => "series", "series" => $ser->term_id])) {
                        $series_info["slug"] = $ser->slug;
                        $series_info["hasseason"] = 0;
                    }
                } else {
                    $series_info["slug"] = $ser->slug;
                    $series_info["hasseason"] = 1;
                }
            }
        }
        return $series_info;
    }
    public function post_schema($post)
    {
        $Schema = "";
        $series = get_the_terms($post, "series", "");
        if (!empty($series)) {
            $Schema == "serie";
        } else {
            $Schema = "movie";
        }
        echo "<span itemprop=\"video\" itemscope itemtype=\"http://schema.org/VideoObject\">";
        echo "<meta itemprop=\"name\" content=\"" . get_the_title($post) . "\">";
        echo "<link itemprop=\"thumbnailUrl\" href=\"" . wp_get_attachment_url(get_post_thumbnail_id($post)) . "\">";
        echo "<meta itemprop=\"description\" content=\"" . get_the_title($post) . "\">";
        echo "<meta itemprop=\"uploadDate\" content=\"" . date("Y-m-d", strtotime(get_post($post)->post_date)) . "T04:56:26\">";
        echo "<link itemprop=\"embedURL\" href=\"" . get_the_permalink($post) . "\">";
        echo "<meta itemprop=\"duration\" content=\"PT120M00S\"></span><div class=\"overlay\"></div>";
        if ($Schema == "movie") {
            echo "<div itemscope style=\"display: none;\" itemtype=\"http://schema.org/Movie\">";
            echo "<h1 itemprop=\"name\">" . get_the_title() . "</h1>";
            echo "<img src=\"" . wp_get_attachment_url(get_post_thumbnail_id($post)) . "\" itemprop=\"image\" />";
            echo "<span itemprop=\"description\">" . wp_trim_words(get_post($post)->post_content, 20, "...") . "</span>";
            echo "Director:";
            foreach (is_array(get_the_terms($post, "director", "")) ? get_the_terms($post, "director", "") : [] as $director) {
                echo "<div itemprop=\"director\" itemscope itemtype=\"http://schema.org/Person\">";
                echo "<span itemprop=\"name\">" . $director->name . "</span>";
                echo "</div>";
            }
            echo "Writers:";
            foreach (is_array(get_the_terms($post, "writers", "")) ? get_the_terms($post, "writers", "") : [] as $writers) {
                echo "<div itemprop=\"author\" itemscope itemtype=\"http://schema.org/Person\">";
                echo "<span itemprop=\"name\">" . $writers->name . "</span>";
                echo "</div>";
            }
            echo "Stars:";
            foreach (is_array(get_the_terms($post, "actor", "")) ? get_the_terms($post, "actor", "") : [] as $actor) {
                echo "<div itemprop=\"actor\" itemscope itemtype=\"http://schema.org/Person\">";
                echo "<span itemprop=\"name\">" . $actor->name . "</span>";
                echo "</div>";
            }
            echo "<div itemprop=\"aggregateRating\" itemscope itemtype=\"http://schema.org/AggregateRating\"><span itemprop=\"ratingValue\">8</span>/<span itemprop=\"bestRating\">10</span> stars from<span itemprop=\"ratingCount\">200</span> users.Reviews: <span itemprop=\"reviewCount\">50</span>.</div>";
            echo "<span itemprop=\"datePublished\" content=\"" . date("d-m-Y", strtotime(get_post($post)->post_date)) . "\" class=\"runtime\">";
            echo date("d-m-Y", strtotime(get_post($post)->post_date));
            echo "</span></div>";
        } else {
            if ($Schema == "serie") {
                foreach (get_the_terms($post, "series", "") as $serie) {
                    if ($serie->parent == 0) {
                        echo "<div itemscope itemtype=\"http://schema.org/TVSeries\" style=\"display: none;\">";
                        echo "<a itemprop=\"url\" href=\"" . get_term_link($serie) . "\">";
                        echo "<span itemprop=\"name\">" . $serie->name . "</span></a>,";
                        foreach (get_the_terms($post, "series", "") as $season) {
                            if (0 < $season->parent) {
                                echo "<div itemprop=\"containsSeason\" itemscope itemtype=\"http://schema.org/TVSeason\">";
                                echo "<a itemprop=\"url\" href=\"" . get_term_link($season) . "\">";
                                echo "<span itemprop=\"name\">" . $season->name . "</span></a>,";
                                echo "<div itemprop=\"number\" itemscope itemtype=\"http://schema.org/TVEpisode\">";
                                echo "<a itemprop=\"url\" href=\"" . get_the_permalink($post) . "\">";
                                echo "<span itemprop=\"name\">" . get_the_title($post) . "</span></a>,";
                                echo " number <span itemprop=\"position\">" . get_post_meta($post, "number", true) . "</span>, ";
                                echo "</div></div>";
                            }
                        }
                        echo "</div>";
                    }
                }
            }
        }
    }
    public function GetCanonicalURL()
    {
        $pageURL = "http";
        if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {
            $pageURL .= "s";
        }
        $pageURL .= "://";
        $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
        return $pageURL;
    }
    public function SingleHead($post)
    {
        $sitename = get_option("SiteName") == "" ? get_bloginfo("name") : get_option("SiteName");
        $facebook = get_option("facebook");
        $title = $post->post_title;
        $image = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
        $ogimage = !isset(get_post_meta($post->ID, "ogimage", true)["url"]) && empty(get_post_meta($post->ID, "ogimage", true)["url"]) ? $image : get_post_meta($post->ID, "ogimage", true)["url"];
        $content = $post->post_content;
        $metadescription = get_post_meta($post->ID, "metadescription", true) == "" ? $content : get_post_meta($post->ID, "metadescription", true);
        $metadescription = wp_trim_words($metadescription, 30, "");
        $metatitle = get_post_meta($post->ID, "metatitle", true) == "" ? $title : get_post_meta($post->ID, "metatitle", true);
        if (get_query_var("download")) {
            $metatitle .= " - تحميل";
        }
        $canonical = $this->CanonicalURL;
        if ($post->post_type == "post") {
            $cats = is_array(get_the_terms($post->ID, "category", "")) ? get_the_terms($post->ID, "category", "") : [];
        } else {
            if ($post->post_type == "news") {
                $cats = is_array(get_the_terms($post->ID, "catnews", "")) ? get_the_terms($post->ID, "catnews", "") : [];
            } else {
                $cats = is_array(get_the_terms($post->ID, "progcategories", "")) ? get_the_terms($post->ID, "progcategories", "") : [];
            }
        }
        $category = "";
        foreach (array_slice($cats, 0, 1) as $term) {
            $category = $term->name;
        }
        $publishedtime = date("c", strtotime($post->post_date));
        $modifiedtime = date("c", strtotime($post->post_modified));
        echo "<title>" . $metatitle . " Moviz One -  موفيز وان</title>";
        echo "<meta name=\"title\" content=\"" . $metatitle . "\" />";
        echo "<meta name=\"description\" content=\"" . $metadescription . "\" />";
        echo "<meta name=\"robots\" content=\"follow,index\" />";
        echo "<link rel=\"canonical\" href=\"" . $canonical . "\" />";
        echo "<meta property=\"og:locale\" content=\"ar_AR\" /><meta property=\"og:type\" content=\"article\" />";
        echo "<meta property=\"og:title\" content=\"" . $metatitle . "\" />";
        echo "<meta property=\"og:description\" content=\"" . $metadescription . "\" />";
        echo "<meta property=\"og:url\" content=\"" . $canonical . "\" />";
        echo "<meta property=\"og:site_name\" content=\"" . $sitename . "\" />";
        echo "<meta property=\"article:publisher\" content=\"" . $facebook . "\" />";
        echo "<meta property=\"article:section\" content=\"" . $category . "\" />";
        echo "<meta property=\"article:published_time\" content=\"" . $publishedtime . "\" />";
        echo "<meta property=\"article:modified_time\" content=\"" . $modifiedtime . "\" />";
        echo "<meta property=\"og:updated_time\" content=\"" . $modifiedtime . "\" />";
        echo "<meta property=\"og:image\" content=\"" . $ogimage . "\" />";
        echo "<meta property=\"og:image:secure_url\" content=\"" . $ogimage . "\" />";
        echo "<meta property=\"og:image:width\" content=\"1200\" /><meta property=\"og:image:height\" content=\"800\" /><meta name=\"twitter:card\" content=\"summary_large_image\" />";
        echo "<meta name=\"twitter:description\" content=\"" . $metadescription . "\" />";
        echo "<meta name=\"twitter:title\" content=\"" . $metatitle . "\" />";
        echo "<meta name=\"twitter:image\" content=\"" . $ogimage . "\" />";
    }
    public function PageHead($post)
    {
        $sitename = get_option("SiteName") == "" ? get_bloginfo("name") : get_option("SiteName");
        $facebook = get_option("facebook");
        $title = $post->post_title;
        $image = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
        $ogimage = !isset(get_post_meta($post->ID, "ogimage", true)["url"]) && empty(get_post_meta($post->ID, "ogimage", true)["url"]) ? $image : get_post_meta($post->ID, "ogimage", true)["url"];
        $content = $post->post_content;
        $metadescription = get_post_meta($post->ID, "metadescription", true) == "" ? $content : get_post_meta($post->ID, "metadescription", true);
        $metadescription = wp_trim_words($metadescription, 30, "");
        $metatitle = get_post_meta($post->ID, "metatitle", true) == "" ? $title : get_post_meta($post->ID, "metatitle", true);
        $canonical = $this->CanonicalURL;
        $cats = is_array(get_the_terms($post->ID, "progcategories", "")) ? get_the_terms($post->ID, "progcategories", "") : [];
        $category = "";
        foreach (array_slice($cats, 0, 1) as $term) {
            $category = $term->name;
        }
        $publishedtime = date("c", strtotime($post->post_date));
        $modifiedtime = date("c", strtotime($post->post_modified));
        if (is_page("advsearch")) {
            $res = " نتائج البحث";
            if (isset($_GET["cat"])) {
                $res .= "/قسم  " . str_replace(",", " ", $_GET["cat"]);
            }
            if (isset($_GET["yr"])) {
                $res .= "/عام " . str_replace(",", " ", $_GET["yr"]);
            }
            if (isset($_GET["qlty"])) {
                $res .= "/جودة " . str_replace(",", " ", $_GET["qlty"]);
            }
            if (isset($_GET["mpa"])) {
                $res .= "/فئة عمرية  " . str_replace(",", " ", $_GET["mpa"]);
            }
            if (isset($_GET["gnr"])) {
                $res .= "/نوع  " . str_replace(",", " ", $_GET["gnr"]);
            }
            if (isset($_GET["ntn"])) {
                $res .= "/دولة  " . str_replace(",", " ", $_GET["ntn"]);
            }
            if (isset($_GET["offset"])) {
                $res .= " صفحة " . $_GET["offset"];
            }
            echo "<title>" . $res . "</title>";
        } else {
            echo "<title>" . $metatitle . "</title>";
        }
        echo "\n        <meta name=\"title\" content=\"" . $metatitle . "\" />\n        <meta name=\"description\" content=\"" . $metadescription . "\" />\n        <meta name=\"robots\" content=\"follow,index\" />\n        <link rel=\"canonical\" href=\"" . $canonical . "\" />\n        <meta property=\"og:locale\" content=\"ar_AR\" />\n        <meta property=\"og:type\" content=\"article\" />\n        <meta property=\"og:title\" content=\"" . $metatitle . "\" />\n        <meta property=\"og:description\" content=\"" . $metadescription . "\" />\n        <meta property=\"og:url\" content=\"" . $canonical . "\" />\n        <meta property=\"og:site_name\" content=\"" . $sitename . "\" />\n        <meta property=\"article:publisher\" content=\"" . $facebook . "\" />\n        <meta property=\"article:section\" content=\"" . $category . "\" />\n        <meta property=\"article:published_time\" content=\"" . $publishedtime . "\" />\n        <meta property=\"article:modified_time\" content=\"" . $modifiedtime . "\" />\n        <meta property=\"og:updated_time\" content=\"" . $modifiedtime . "\" />\n        <meta property=\"og:image\" content=\"" . $ogimage . "\" />\n        <meta property=\"og:image:secure_url\" content=\"" . $ogimage . "\" />\n        <meta property=\"og:image:width\" content=\"1200\" />\n        <meta property=\"og:image:height\" content=\"800\" />\n        <meta name=\"twitter:card\" content=\"summary_large_image\" />\n        <meta name=\"twitter:description\" content=\"" . $metadescription . "\" />\n        <meta name=\"twitter:title\" content=\"" . $metatitle . "\" />\n        <meta name=\"twitter:image\" content=\"" . $ogimage . "\" />";
    }
    public function ArchiveHead($obj)
    {
        $sitename = get_option("SiteName") == "" ? get_bloginfo("name") : get_option("SiteName");
        $secondname = get_bloginfo("name");
        $title = $obj->name . " ";
        if (get_query_var("paged")) {
            $paged = get_query_var("paged");
        } else {
            if (get_query_var("page")) {
                $paged = get_query_var("page");
            } else {
                $paged = 1;
            }
        }
        if (1 < $paged) {
            $title .= " - صفحة " . $paged;
        }
        if (isset($_GET["offset"])) {
            $title .= " - صفحة " . $_GET["offset"];
        }
        if (isset($_GET["filter"])) {
            $title .= " - " . $_GET["filter"];
        }
        if (isset($_GET["gnr"])) {
            $title .= " " . $_GET["gnr"];
        }
        if (isset($_GET["cat"])) {
            $title .= " " . $_GET["cat"];
        }
        if (isset($_GET["key"])) {
            switch ($_GET["key"]) {
                case "views":
                    $title .= "الاكثر مشاهدة ";
                    break;
                case "imdb":
                    $title .= "الاعلي تقييما ";
                    break;
                case "likes":
                    $title .= "الاكثر اعجابا ";
                    break;
                case "year":
                    $title .= " " . date("Y");
                    break;
            }
        }
        $title .= " - " . $sitename;
        $description = strip_tags($obj->description);
        $canonical = get_term_link($obj);
        echo "<title>" . $title . "</title>\n          <meta name=\"title\" content=\"" . $title . "\" />\n          <meta name=\"description\" content=\"" . $description . "\" />\n          <meta name=\"robots\" content=\"follow,index\" />\n          <link rel=\"canonical\" href=\"" . $canonical . "\" />\n          <meta property=\"og:locale\" content=\"ar_AR\" />\n          <meta property=\"og:type\" content=\"object\" />\n          <meta property=\"og:title\" content=\"" . $title . "\" />\n          <meta property=\"og:description\" content=\"" . $description . "\" />\n          <meta property=\"og:url\" content=\"" . $canonical . "\" />\n          <meta property=\"og:site_name\" content=\"" . $sitename . "\" />\n          <meta name=\"twitter:card\" content=\"summary_large_image\" />\n          <meta name=\"twitter:description\" content=\"" . $description . "\" />\n          <meta name=\"twitter:title\" content=\"" . $title . "\" />";
    }
    public function HomeHead()
    {
        $title = get_bloginfo("name");
        if (get_query_var("paged")) {
            $paged = get_query_var("paged");
        } else {
            if (get_query_var("page")) {
                $paged = get_query_var("page");
            } else {
                $paged = 1;
            }
        }
        if (1 < $paged) {
            $title .= " - صفحة " . $paged;
        }
        $description = get_option("SiteName") == "" ? get_bloginfo("description") : get_option("descSite");
        $canonical = home_url();
        $sitename = get_option("SiteName") != "" ? get_option("SiteName") : get_bloginfo("name");
        echo "<title>" . $sitename . "</title>\n        <meta name=\"title\" content=\"" . $sitename . "\" />\n        <meta name=\"description\" content=\"" . $description . "\" />\n        <meta name=\"robots\" content=\"follow,index\" />\n        <meta property=\"og:locale\" content=\"ar_AR\" />\n        <meta property=\"og:type\" content=\"website\" />\n        <meta property=\"og:title\" content=\"" . $title . "\" />\n        <meta property=\"og:description\" content=\"" . $description . "\" />\n        <meta property=\"og:url\" content=\"" . $canonical . "\" />\n        <meta property=\"og:site_name\" content=\"" . $sitename . "\" />\n        <meta name=\"twitter:card\" content=\"summary_large_image\" />\n        <meta name=\"twitter:description\" content=\"" . $description . "\" />\n        <meta name=\"twitter:title\" content=\"" . $title . "\" />";
    }
    public function SearchHead()
    {
        $title = get_search_query();
        if (get_query_var("paged")) {
            $paged = get_query_var("paged");
        } else {
            if (get_query_var("page")) {
                $paged = get_query_var("page");
            } else {
                $paged = 1;
            }
        }
        if (1 < $paged) {
            $title .= " - صفحة " . $paged;
        }
        $description = get_option("descSite") == "" ? get_bloginfo("descSite") : get_option("description");
        $canonical = home_url();
        $sitename = get_option("SiteName") == "" ? get_bloginfo("name") : get_option("SiteName");
        $title = "نتائج البحث عن " . get_search_query() . " | " . $sitename;
        echo "<title>" . $title . "</title>\n          <meta name=\"title\" content=\"" . $title . "\" />\n          <meta name=\"description\" content=\"" . $description . "\" />\n          <meta name=\"robots\" content=\"follow,index\" />\n          <link rel=\"canonical\" href=\"" . $canonical . "\" />\n          <meta property=\"og:locale\" content=\"ar_AR\" />\n          <meta property=\"og:type\" content=\"website\" />\n          <meta property=\"og:title\" content=\"" . $title . "\" />\n          <meta property=\"og:description\" content=\"" . $description . "\" />\n          <meta property=\"og:url\" content=\"" . $canonical . "\" />\n          <meta property=\"og:site_name\" content=\"" . $sitename . "\" />\n          <meta name=\"twitter:card\" content=\"summary_large_image\" />\n          <meta name=\"twitter:description\" content=\"" . $description . "\" />\n          <meta name=\"twitter:title\" content=\"" . $title . "\" />";
    }
    public function Meta()
    {
        if (get_option("showMeta") == "yes") {
            global $post;
            if (is_single()) {
                $this->SingleHead($post);
            } else {
                if (is_home() || is_front_page()) {
                    $this->HomeHead();
                } else {
                    if (is_search()) {
                        $this->SearchHead();
                    } else {
                        if (is_page()) {
                            $this->PageHead($post);
                        } else {
                            if (is_archive() || is_tax() || is_category()) {
                                $obj = get_queried_object();
                                $this->ArchiveHead($obj);
                            }
                        }
                    }
                }
            }
        }
    }
    public function CommentItem($comment, $post)
    {
        $class = "";
        $status = "زائر";
        if (0 < $comment->user_id) {
            $user = get_userdata($comment->user_id);
            if (in_array("administrator", $user->roles) || in_array("editor", $user->roles) || in_array("author", $user->roles)) {
                $status = "الدعم";
                $class = "featured";
            } else {
                $status = "عضو";
            }
        }
        echo "<li id=\"comment-" . $comment->comment_ID . "\">\n\t\t\t<div class=\"UserAvatar " . $class . "\"></div>\n\t\t\t<div class=\"NameArea\">\n\t\t\t\t<span>" . $comment->comment_author . "</span>\n\t\t\t\t<em>" . $status . "</em>\n\t\t\t</div>\n\t\t\t<div class=\"CommentContent\">" . $comment->comment_content . "</div>\n\t\t\t<div class=\"CommentInfo\">\n\t\t\t\t<div class=\"CommentDate\">\n\t\t\t\t\t" . date("d/m/Y", strtotime($comment->comment_date)) . "\n\t\t\t\t</div>\n\t\t\t\t<a href=\"javascript:void(0);\" data-comment=\"" . $comment->comment_ID . "\" data-id=\"" . $post . "\" onClick=\"ReplyComment(this);\">رد</a>\n\t\t\t</div>\n\t\t</li>";
        $arguments = ["status" => "approve", "number" => "10", "post_id" => $post, "parent" => $comment->comment_ID];
        $comments = get_comments($arguments);
        if (!empty($comments)) {
            echo "<ul class=\"ChildComments\">";
            foreach ($comments as $comment) {
                $this->CommentItem($comment, $post);
            }
            echo "</ul>";
        }
    }
    public function Header($num = "")
    {
        if (is_404()) {
            header("Location: " . home_url());
            exit;
        }
        require get_template_directory() . "/Standard/header" . $num . ".php";
    }
    public function Footer($num = "")
    {
        require get_template_directory() . "/Standard/footer" . $num . ".php";
    }
    public function Page($headernum = "")
    {
        $this->Header($headernum);
        if (!is_home()) {
            $post = get_post($this->args->ID);
            setup_postdata($post);
            if (get_post_meta($post->ID, "recent", true) != "") {
                $this->Archive("category", get_post_meta($post->ID, "recent", true)[0], "post", $post->post_title);
            }
        } else {
            global $wp_query;
            global $wp_rewrite;
            require get_template_directory() . "/Standard/Home.php";
        }
        $this->Footer();
    }
    public function GenerateData()
    {
        $id = $_POST["id"];
        $type = $_POST["type"];
        $data = file_get_contents("http://yourcolor.net/newIMDb/api/" . $type . ".php?id=" . $id);
        $data = json_decode($data, 1);
        $fields = explode("|", $_POST["fields"]);
        if ($type == "name") {
            if (in_array("image", $fields)) {
                $image_url = $data["image"];
                if (!empty($image_url)) {
                    $post_id = "";
                    $upload_dir = wp_upload_dir();
                    $image_data = wp_remote_fopen($image_url);
                    $filename = basename($image_url);
                    $filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
                    if (wp_mkdir_p($upload_dir["path"])) {
                        $file = $upload_dir["path"] . "/" . $filename;
                    } else {
                        $file = $upload_dir["basedir"] . "/" . $filename;
                    }
                    file_put_contents($file, $image_data);
                    $wp_filetype = wp_check_filetype($filename, NULL);
                    $attachment = ["post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit"];
                    $attach_id = wp_insert_attachment($attachment, $file, $post_id);
                    require_once ABSPATH . "wp-admin/includes/image.php";
                    $attach_data = wp_generate_attachment_metadata($attach_id, $file);
                    wp_update_attachment_metadata($attach_id, $attach_data);
                }
            }
            echo "<script type=\"text/javascript\">";
            if (in_array("image", $fields)) {
                echo "\$(\".apb-field-image input\").val(\"" . wp_get_attachment_url($attach_id) . "\");";
                echo "\$(\".apb-field-image .APBPreviewFile\").attr(\"src\", \"" . wp_get_attachment_url($attach_id) . "\");";
            }
            if (in_array("about", $fields)) {
                echo "\$(\"#description\").val(\"" . str_replace("\"", "'", $data["about"]) . "\");";
            }
            echo "</script><div class=\"DataSuccess\">\n\t\t\t\t<span class=\"dashicons dashicons-smiley\"></span>\n\t\t\t\t<div class=\"alert alert-success\">تم سحب البيانات المطلوبة .. مقال سعيد :)</div>\n\t\t\t</div>";
        } else {
            if (in_array("poster", $fields)) {
                $image_url = $data["poster"];
                if (!empty($image_url)) {
                    $post_id = "";
                    $upload_dir = wp_upload_dir();
                    $image_data = wp_remote_fopen($image_url);
                    $filename = basename($image_url);
                    $filename = str_replace(".jpg", "-" . $post_id . ".jpg", $filename);
                    if (wp_mkdir_p($upload_dir["path"])) {
                        $file = $upload_dir["path"] . "/" . $filename;
                    } else {
                        $file = $upload_dir["basedir"] . "/" . $filename;
                    }
                    file_put_contents($file, $image_data);
                    $wp_filetype = wp_check_filetype($filename, NULL);
                    $attachment = ["post_mime_type" => $wp_filetype["type"], "post_title" => sanitize_file_name($filename), "post_content" => "", "post_status" => "inherit"];
                    $attach_id = wp_insert_attachment($attachment, $file, $post_id);
                    require_once ABSPATH . "wp-admin/includes/image.php";
                    $attach_data = wp_generate_attachment_metadata($attach_id, $file);
                    wp_update_attachment_metadata($attach_id, $attach_data);
                }
            }
            echo "\t\t\t<script type=\"text/javascript\">\n\t\t\t\t";
            if (in_array("poster", $fields)) {
                echo "\t\t\t\t\t\t\$('#_thumbnail_id').val(\"";
                echo $attach_id;
                echo "\");\n\t\t\t\t\t\t\$('#postimagediv .inside > center').remove();\n\t\t\t\t\t\t\$('#postimagediv .inside').prepend('<center><h1>تم تعيين صورة بارزة</h1></center>');\n\t\t\t\t";
            }
            echo "\t\t\t\t";
            if (isset($data["released"]) && in_array("released", $fields)) {
                echo "\t\t\t\t\t\t\$('#Released').val(\"";
                echo str_replace("\"", "'", $data["released"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\n          ";
            if (isset($data["title"]) && in_array("title", $fields)) {
                echo "            \$('#title').val(\"";
                echo str_replace("\"", "'", $data["title"]);
                echo "\");\n          ";
            }
            echo "\n\t\t\t\t\t";
            if (isset($data["trailer"]) && in_array("trailer", $fields)) {
                echo "\t\t\t\t\t\t\$('#Trailer').val(\"";
                echo str_replace("\"", "'", $data["trailer"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["mpaa"]) && in_array("mpaa", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-mpaa').val(\"";
                echo str_replace("\"", "'", $data["mpaa"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["awards"]) && in_array("awards", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-awards').val(\"";
                echo str_replace("\"", "'", $data["awards"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["runtime"]) && in_array("runtime", $fields)) {
                echo "\t\t\t\t\t\t\$('#runtime').val(\"";
                echo str_replace("\"", "'", $data["runtime"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["rating"]) && in_array("rating", $fields)) {
                echo "\t\t\t\t\t\t\$('#imdbRating').val(\"";
                echo str_replace("\"", "'", $data["rating"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["votes"]) && in_array("votes", $fields)) {
                echo "\t\t\t\t\t\t\$('#imdbVotes').val(\"";
                echo str_replace("\"", "'", $data["votes"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["cast"]) && in_array("cast", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-actor').val(\"";
                echo str_replace("\"", "'", $data["cast"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["mpaa"]) && in_array("mpaa", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-mpaa').val(\"";
                echo str_replace("\"", "'", $data["mpaa"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t";
            if (in_array("genre", $fields)) {
                echo "\t\t\t\t\t";
                $genres = str_replace("\"", "'", $data["genre"]);
                $en = ["Action", "Adventure", "Music", "Musical", "Comedy", "Drama", "Documentary", "Animation", "Biography", "Crime", "Family", "Fantasy", "History", "Horror", "Mystery", "Romance", "Sci-Fi", "Short", "Sport", "Superhero", "Thriller", "War", "Western"];
                $ar = ["اكشن", "مغامرة", "موسيقي", "موسيقي", "كوميدي", "دراما", "وثائقي", "انيميشن", "سيرة ذاتية", "جريمة", "عائلي", "فانتازيا", "تاريخي", "رعب", "غموض", "رومانسي", "خيال علمي", "قصير", "رياضي", "خارقة", "اثارة", "حربي", "ويسترن"];
                foreach ($en as $k => $genre) {
                    $genres = str_replace($genre, $ar[$k], $genres);
                }
                echo "\t\t\t\t\t\t\$('#new-tag-genre').val(\"";
                echo $genres;
                echo "\");\n\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["directors"]) && in_array("directors", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-director').val(\"";
                echo str_replace("\"", "'", $data["directors"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["writers"]) && in_array("writers", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-writers').val(\"";
                echo str_replace("\"", "'", $data["writers"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["story"]) && in_array("story", $fields)) {
                echo "\t\t\t\t\t\t\$('#story').val(\"";
                echo str_replace("\"", "'", $data["story"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["country"]) && in_array("country", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-nation').val(\"";
                echo str_replace("\"", "'", $data["country"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["year"]) && in_array("year", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-release-year').val(\"";
                echo str_replace("\"", "'", $data["year"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t\t\t";
            if (isset($data["language"]) && in_array("language", $fields)) {
                echo "\t\t\t\t\t\t\$('#new-tag-language').val(\"";
                echo str_replace("\"", "'", $data["language"]);
                echo "\");\n\t\t\t\t\t";
            }
            echo "\t\t\t</script>\n\t\t\t<div class=\"DataSuccess\">\n\t\t\t\t<span class=\"dashicons dashicons-smiley\"></span>\n\t\t\t\t<div class=\"alert alert-success\">تم سحب البيانات المطلوبة .. مقال سعيد :)</div>\n\t\t\t</div>\n\t\t\t";
        }
        wp_die();
    }
    public function Archive($taxonomy, $id, $title = NULL, $order = "recent", $hasheader = false)
    {
        global $wp_query;
        global $wp_rewrite;
        global $post;
        if ($hasheader) {
            $this->Header();
        }
        $obj = get_term($id, $taxonomy);
        if ($taxonomy == "actor" || $taxonomy == "director" || $taxonomy == "writers") {
            require get_template_directory() . "/Standard/Actors.php";
        } else {
            require get_template_directory() . "/Standard/Archive.php";
        }
        if ($hasheader) {
            $this->Footer();
        }
    }
    public function Search($searchtxt = "", $perpage = 15)
    {
        global $wp_query;
        global $wp_rewrite;
        global $post;
        global $wpdb;
        $this->Header();
        require get_template_directory() . "/Standard/Search.php";
        $this->Footer();
    }
    public function SearchFilter($query)
    {
        if (!is_admin() && $query->is_main_query() && $query->is_search) {
            $query->set("post_type", ["post"]);
        }
    }
    public function getActorSearch($clauses, $taxonomies, $args)
    {
        if (!empty($args["surname"])) {
            global $wpdb;
            $surname_like = $wpdb->esc_like($args["surname"]);
            if (!isset($clauses["where"])) {
                $clauses["where"] = "1=1";
            }
            $clauses["where"] .= $wpdb->prepare(" AND t.name LIKE %s OR t.name LIKE %s", $surname_like . "%", "% " . $surname_like . "%");
        }
        return $clauses;
    }
    public function ArchivePagination($wp_query, $wp_rewrite)
    {
        echo "<div class=\"pagination\">";
        if (1 < $wp_query->query_vars["paged"]) {
            $current = $wp_query->query_vars["paged"];
        } else {
            $current = 1;
            $pagination = ["base" => @add_query_arg("page", "%#%"), "format" => "", "total" => $wp_query->max_num_pages, "current" => $current, "show_all" => false, "type" => "list", "next_text" => "&laquo;", "prev_text" => "&raquo;", "range" => 10];
            if ($wp_rewrite->using_permalinks()) {
                $pagination["base"] = user_trailingslashit(trailingslashit(remove_query_arg("page", get_pagenum_link(1))) . "?page=%#%/", "paged");
            }
            if (!empty($wp_query->query_vars["s"])) {
                $pagination["add_args"] = ["s" => get_query_var("s")];
            }
            echo paginate_links($pagination);
            echo "</div>";
        }
    }
    public function customsssss()
    {
        $args = json_decode(stripslashes($_POST["args"]), 1);
        $args["paged"] = $_POST["num"];
        foreach (get_posts($args) as $post) {
            $this->filmBlock($post);
        }
        wp_die();
    }
    public function TaxPagination($args)
    {
        if (40 < count(get_categories($args))) {
            echo "<div class=\"pagination\">";
            if (1 < $_GET["offset"]) {
                $current = $_GET["offset"];
            } else {
                $current = 1;
                $pagination = ["base" => @add_query_arg("offset", "%#%"), "format" => "", "total" => ceil(count(get_categories($args)) / 40), "current" => $current, "show_all" => false, "type" => "list", "next_text" => "&laquo;", "prev_text" => "&raquo;", "range" => 10];
                echo paginate_links($pagination);
                echo "</div>";
            }
        }
    }
    public function Breadcrumb()
    {
        global $post;
        $schema_link = "";
        $home = "الرئيسية";
        $delimiter = "<span class=\"seprator\">&raquo;</span>";
        $homeLink = get_bloginfo("url");
        if (!(is_home() || is_front_page())) {
            echo "<div id=\"mpbreadcrumbs\">";
            if (!is_single()) {
                echo "انت هنا : ";
            }
            echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . $homeLink . "\">" . "<span itemprop=\"title\">" . $home . "</span>" . "</a></span>" . $delimiter . " ";
            if (get_page_by_path("blog") && !is_page("blog")) {
                echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_permalink(get_page_by_path("blog")) . "\">" . "<span itemprop=\"title\">Blog</span></a></span>" . $delimiter . " ";
            }
            if (is_category()) {
                $thisCat = get_category(get_query_var("cat"), false);
                if ($thisCat->parent != 0) {
                    $category_link = get_category_link($thisCat->parent);
                    echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . $category_link . "\">" . "<span itemprop=\"title\">" . get_cat_name($thisCat->parent) . "</span>" . "</a></span>" . $delimiter . " ";
                }
                $category_id = get_cat_ID(single_cat_title("", false));
                $category_link = get_category_link($category_id);
                echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . $category_link . "\">" . "<span itemprop=\"title\">" . single_cat_title("", false) . "</span>" . "</a></span>";
            } else {
                if (is_single() && !is_attachment()) {
                    $category = get_the_category();
                    if (empty($category)) {
                        $category = get_the_terms($post->ID, "progcategories", "");
                    }
                    if ($category) {
                        foreach ($category as $cat) {
                            echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_category_link($cat->term_id) . "\">" . "<span itemprop=\"title\">" . $cat->name . "</span>" . "</a></span>" . $delimiter . " ";
                        }
                    }
                    echo get_the_title();
                } else {
                    if (is_tax()) {
                        $category = get_queried_object();
                        if (0 < $category->parent) {
                            $category = get_term($category->parent, $category->taxonomy);
                            echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_term_link($category) . "\">" . "<span itemprop=\"title\">" . $category->name . "</span>" . "</a></span>" . $delimiter . "";
                            $category = get_queried_object();
                        }
                        echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_term_link($category) . "\">" . "<span itemprop=\"title\">" . $category->name . "</span>" . "</a></span>";
                    } else {
                        if (!is_single() && !is_page() && get_post_type() != "post" && !is_404()) {
                            $post_type = get_post_type_object(get_post_type());
                            echo $post_type->labels->singular_name;
                        } else {
                            if (is_attachment()) {
                                $parent = get_post($post->post_parent);
                                $cat = get_the_category($parent->ID);
                                $cat = $cat[0];
                                echo get_category_parents($cat, true, " " . $delimiter . " ");
                                echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_permalink($parent) . "\">" . "<span itemprop=\"title\">" . $parent->post_title . "</span>" . "</a></span>";
                                echo " " . $delimiter . " " . get_the_title();
                            } else {
                                if (is_page() && !$post->post_parent) {
                                    $get_post_slug = $post->post_title;
                                    $post_slug = str_replace("-", " ", $get_post_slug);
                                    echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_permalink() . "\">" . "<span itemprop=\"title\">" . ucfirst($post_slug) . "</span>" . "</a></span>";
                                } else {
                                    if (is_page() && $post->post_parent) {
                                        $parent_id = $post->post_parent;
                                        $breadcrumbs = [];
                                        while ($parent_id) {
                                            $page = get_page($parent_id);
                                            $breadcrumbs[] = "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_permalink($page->ID) . "\">" . "<span itemprop=\"title\">" . get_the_title($page->ID) . "</span>" . "</a></span>";
                                            $parent_id = $page->post_parent;
                                        }
                                        $breadcrumbs = array_reverse($breadcrumbs);
                                        for ($i = 0; $i < count($breadcrumbs); $i++) {
                                            echo $breadcrumbs[$i];
                                            if ($i != count($breadcrumbs) - 1) {
                                                echo " " . $delimiter . " ";
                                            }
                                        }
                                        echo $delimiter . "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_permalink() . "\">" . "<span itemprop=\"title\">" . the_title_attribute("echo=0") . "</span>" . "</a></span>";
                                    } else {
                                        if (is_tag()) {
                                            $tag_id = get_term_by("name", single_cat_title("", false), "post_tag");
                                            if ($tag_id) {
                                                $tag_link = get_tag_link($tag_id->term_id);
                                            }
                                            echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . $tag_link . "\">" . "<span itemprop=\"title\">" . single_cat_title("", false) . "</span>" . "</a></span>";
                                        } else {
                                            if (is_author()) {
                                                global $author;
                                                $userdata = get_userdata($author);
                                                echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_author_posts_url($userdata->ID) . "\">" . "<span itemprop=\"title\">" . $userdata->display_name . "</span>" . "</a></span>";
                                            } else {
                                                if (is_404()) {
                                                    echo "Error 404";
                                                } else {
                                                    if (is_search()) {
                                                        echo "نتائج البحث عن \"" . get_search_query() . "\"";
                                                    } else {
                                                        if (is_day()) {
                                                            echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_year_link(get_the_time("Y")) . "\">" . "<span itemprop=\"title\">" . get_the_time("Y") . "</span>" . "</a></span>" . $delimiter . " ";
                                                            echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_month_link(get_the_time("Y"), get_the_time("m")) . "\">" . "<span itemprop=\"title\">" . get_the_time("F") . "</span>" . "</a></span>" . $delimiter . " ";
                                                            echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_day_link(get_the_time("Y"), get_the_time("m"), get_the_time("d")) . "\">" . "<span itemprop=\"title\">" . get_the_time("d") . "</span>" . "</a></span>";
                                                        } else {
                                                            if (is_month()) {
                                                                echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_year_link(get_the_time("Y")) . "\">" . "<span itemprop=\"title\">" . get_the_time("Y") . "</span>" . "</a></span>" . $delimiter . " ";
                                                                echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_month_link(get_the_time("Y"), get_the_time("m")) . "\">" . "<span itemprop=\"title\">" . get_the_time("F") . "</span>" . "</a></span>";
                                                            } else {
                                                                if (is_year()) {
                                                                    echo "<span itemscope itemtype=\"" . $schema_link . "\"><a itemprop=\"url\" href=\"" . get_year_link(get_the_time("Y")) . "\">" . "<span itemprop=\"title\">" . get_the_time("Y") . "</span>" . "</a></span>";
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (get_query_var("paged")) {
                if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) {
                    echo " (";
                }
                echo __("صفحة") . " " . get_query_var("paged");
                if (is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author()) {
                    echo ")";
                }
            }
            echo "</div>";
        }
    }
    public function CommentsArea($id)
    {
        $post = get_post($id);
        setup_postdata($post);
        require get_template_directory() . "/Setup/Comments/Interface.php";
    }
    public function Single()
    {
        global $post;
        $category = is_array(get_the_terms($post->ID, "category", true)) ? get_the_terms($post->ID, "category", true) : [];
        $post_tag = is_array(get_the_terms($post->ID, "post_tag", true)) ? get_the_terms($post->ID, "post_tag", true) : [];
        $years = is_array(get_the_terms($post->ID, "release-year", true)) ? get_the_terms($post->ID, "release-year", true) : [];
        $quality = is_array(get_the_terms($post->ID, "quality", true)) ? get_the_terms($post->ID, "quality", true) : [];
        $genre = is_array(get_the_terms($post->ID, "genre", true)) ? get_the_terms($post->ID, "genre", true) : [];
        $actor = is_array(get_the_terms($post->ID, "actor", true)) ? get_the_terms($post->ID, "actor", true) : [];
        $this->Header();
        require get_template_directory() . "/Standard/Singles/" . $post->post_type . ".php";
        $this->Footer();
    }
    public function IMDbOptions()
    {
    }
}
class ThemeQueries
{
    private $args = NULL;
    public function __construct($args = [])
    {
        $this->args = $args;
    }
    public function Query()
    {
        global $post;
        $query = get_posts($this->args);
        return $query;
    }
    public function Categories($tax = "category", $hempty = 1, $orderby = "id", $order = "ASC", $fields = "all", $search = "", $number = "", $offset = "", $parent = 0)
    {
        global $post;
        $args = ["taxonomy" => $tax, "orderby" => $orderby, "order" => $order, "hide_empty" => $hempty, "fields" => $fields, "parent" => $parent];
        if (!empty($search)) {
            $args["name__like"] = $search;
        }
        if (!empty($offset) && is_numeric($offset)) {
            if (!empty($number) && is_numeric($number)) {
                $terms = array_slice(get_terms($args), $offset, $number);
            } else {
                $terms = array_slice(get_terms($args), $offset);
            }
        } else {
            if (!empty($number) && is_numeric($number)) {
                $terms = array_slice(get_terms($args), 0, $number);
            } else {
                $terms = get_terms($args);
            }
        }
        return $terms;
    }
}

?>
