jQuery(function($){
	$('body').on('click', '.APBUploadButton', function(e){
		var field = $(this).data('field');
		var name = $(this).data('name');
		var datamultiple = $(this).data('multiple');
		e.preventDefault();
     		var button = $(this),
    		    custom_uploader = wp.media({
			title: $(this).data('rlname'),
			library : {
				type : $(this).data('type')
			},
			button: {
				text: UploadButtonText
			},
			multiple: $(this).data('multiple')
		}).on('select', function() {
			if( datamultiple == true ) {
				var attachments = custom_uploader.state().get('selection'),
				    attachment_ids = new Array(),
				    i = 0;
				attachments.each(function(attachment) {
	 				attachment_ids[i] = attachment['id'];
	 				var attachment = attachment.toJSON();
					$(field+'_preview').append('<span><input type="hidden" name="'+name+'['+attachment.id+']" value="'+attachment.url+'" /><em onClick="this.parent().remove();"><span></span><span></span></em><img src="'+attachment.url+'" /></span>');
					i++;
				});
			}else {
				var attachment = custom_uploader.state().get('selection').first().toJSON();
				$(field+'_id').val(attachment.id);
				$(field).val(attachment.url);
				$(field+'_preview').attr('src', attachment.url).show();
				$(field+'_remove').show();
			}
		})
		.open();
	});
 
	$('body').on('click', '.APBRemoveButton', function(){
		if( $(this).data('multiple') == false ) {
			$(this).prev().attr('src', '').hide();
			$(this).prev().prev().prev().val('');
			$(this).prev().prev().prev().prev().val('');
			$(this).remove();
		}else {
			$(this).prev().html('');
			$(this).remove();
		}
		return false;
	});

  ////////////////////////////
    var mediaUploader;
  	$('#userUploadBtn').on('click', function(e){
	   e.preventDefault();
		var button = $(this);
	      if (mediaUploader) {
	      mediaUploader.open();
	      return;
	    }
	    mediaUploader = wp.media.frames.file_frame = wp.media({
	      title: 'Choose Image',
	      button: {
	      text: 'Choose Image'
	    }, multiple: false });
	    mediaUploader.on('select', function() {
	      	var attachment = mediaUploader.state().get('selection').first().toJSON();
			$('.APBPreviewFile').show().attr('src',attachment.url);
			$('.APBRemoveButton').show();
			$('#image').val(attachment.url);
	    });
	    mediaUploader.open();
	});
   
   $('.APBRemoveButton.removeImage').click(function(e){
   		e.preventDefault();
   		$('.APBPreviewFile').parent().remove();
   		$('#image').val('')
   })


   $('#updatePost').click(function(e){
   	e.preventDefault();
   	var url = $(this).data('url');
   	var id = $(this).data('id');
   	 $.ajax({
   	 	type:'POST',
   	 	url:url,
   	 	data:{
   	 		action:'updatePostDate',
   	 		id:id
   	 	},
   	 	success:function(){
   	 		$('#publish').click();
   	 	}
   	 })
   })
});

