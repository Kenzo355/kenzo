<?php

function WatchServers() {
    $labels = array(
        'name'                  => __( 'سيرفرات المشاهده' , 'kenzo' ),
        'singular_name'         => __( 'السيرفر' , 'kenzo' ),
        'add_new'               => __( 'اضافة سيرفر ' , 'kenzo' ),
        'add_new_item'          => __( 'اضافة سيرفر جديده' , 'kenzo' ),
        'edit'                  => __( 'تعديل' , 'kenzo' ),
        'edit_item'             => __( 'تعديل' , 'kenzo' ),
        'new_item'              => __( 'سيرفر جديد'  , 'kenzo'),
        'search_items'          => __( 'بحث فى سيرفرات المشاهده' , 'kenzo' ),
        'not_found'             => __( 'لا يوجد سيرفرات المشاهده'  , 'kenzo'),
        'not_found_in_trash'    => __( 'لا يوجد سيرفرات المشاهده فى سلة المهملات' , 'kenzo' ),
        'parent'                => __( 'سلاسل الالعاب' , 'kenzo' )
    );
    register_post_type(
        'servers',
        array(
            'labels'                => $labels,
            'public'                => true,
            'show_ui'               => true,
            'publicly_queryable'    => true,
            'show_in_nav_menus'     => false,
            'has_archive'           => true,
            'hierarchical'          => false,
            'rewrite'               => array( 'slug' => 'server_watch' ),
            'supports'              => array('title','thumbnail' ),
        )
    );
    flush_rewrite_rules();
}add_action( 'init', 'WatchServers' );
function DownServers() {
    $labels = array(
        'name'                      => __( 'سيرفرات التحميل' , 'kenzo' ),
        'singular_name'             => __( 'السيرفر' , 'kenzo' ),
        'add_new'                   => __( 'اضافة سيرفر ' , 'kenzo' ),
        'add_new_item'              => __( 'اضافة سيرفر جديده' , 'kenzo' ),
        'edit'                      => __( 'تعديل' , 'kenzo' ),
        'edit_item'                 => __( 'تعديل' , 'kenzo' ),
        'new_item'                  => __( 'سيرفر جديد'  , 'kenzo'),
        'search_items'              => __( 'بحث فى سيرفرات التحميل' , 'kenzo' ),
        'not_found'                 => __( 'لا يوجد سيرفرات التحميل'  , 'kenzo'),
        'not_found_in_trash'        => __( 'لا يوجد سيرفرات التحميل فى سلة المهملات' , 'kenzo' ),
        'parent'                    => __( 'سلاسل الالعاب' , 'kenzo' )
    );
    register_post_type(
        'down_servers',
        array(
            'labels'                => $labels,
            'public'                => true,
            'show_ui'               => true,
            'publicly_queryable'    => true,
            'show_in_nav_menus'     => false,
            'has_archive'           => true,
            'hierarchical'          => false,
            'rewrite'               => array( 'slug' => 'servdown' ),
            'supports'              => array('title','thumbnail' ),
        )
    );
    flush_rewrite_rules();
}

function getstringss($a,$b,$c){ 
    $y = explode($b,$a);
    $x = explode($c,$y[1]);
    return $x[0];
}

add_action( "init", "DownServers", 10, 1 );
function CheckWatchServer($InputServer) {
    $servers = array(
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'post_type' => 'servers',
        'meta_key' => 'server_num',
        'orderby' => 'meta_value',
        'order' => 'ASC',
    );  
    $servers = get_posts($servers);
    foreach($servers as $server){
        $serverCut = get_post_meta($server->ID,'serverCut',true);
        $serverEmbdd = get_post_meta($server->ID,'serverEmbdd',true);
        $serverNumber = get_post_meta($server->ID,'server_num',true);
        $serverName = get_the_title($server->ID);
        $thum = wp_get_attachment_url(get_post_thumbnail_id($server->ID));
        $htts = ['http://','https://']; 
        if(strpos($InputServer,strtolower(str_replace($htts,['',''],$serverCut)))) {
            $rmhttp = str_replace('http://','',$serverCut);
            $rmhttp = str_replace('https://','',$serverCut);
            $emhttp = str_replace('http://','',$serverEmbdd);
            $emhttp = str_replace('https://','',$serverEmbdd);
            $link = str_replace('http://','https://',str_replace($rmhttp,$emhttp,$InputServer)) ;
            if (strtolower($serverName) == 'ok.ru') {
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>str_replace('.html','',$link)];
            } elseif (strtolower($serverName) == 'rapidvideo') {
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>str_replace('.html','',$link)];
            } elseif (strtolower($serverName) == 'mystream' || $serverName == 'yourupload') {
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>str_replace('.html','',$link)];
            } elseif(strtolower($serverName) == 'clipwatching'){
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>substr(str_replace('.html','',$link), 0,43).'.html'];
            }elseif(strtolower($serverName) == 'letsupload'){
                $lInkss = explode('/', $link);
                $lInkss = 'https://letsupload.co/plugins/mediaplayer/site/'.$lInkss[6];
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=> str_replace('.html','',$lInkss) ];
            } elseif(strtolower($serverName) == 'vup'){
                $link = str_replace('emb.html?', '', $link);
                $link = str_replace('.html', '', $link);
                $lInkss = explode('/', $link);
                $lInkss = 'https://vup.to/emb.html?'.$lInkss[3];
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=> $lInkss ];
            } elseif(strtolower($serverName) == 'linkbox'){
                $link = str_replace('player.html?id=', '', $link);
                $link = str_replace('.html', '', $link);
                $lInkss = explode('/', $link);
                $lInkss = 'https://www.linkbox.to/player.html?id='.$lInkss[3];
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=> $lInkss ];    
            } elseif(strtolower($serverName) == 'uppom'){
                $link = getstringss($link , "embed-/" , "/");
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=> "https://uppom.live/embed-".$link.".html" ];
            } else {
                return ['order'=>$serverNumber,'ico' =>$thum ,'server'=>$serverName,'link'=>str_replace('.html','',$link).get_post_meta( $server->ID, "server_end", 1)];
            }
        }
    }
}
function GetWatchServer($value) {
    $servers = [];
    if (!empty($value)) {
        @$value = preg_split('/\r\n|[\r\n]/', $value);
        if (!empty($value)) {
            foreach ($value as $server) {
                if (!is_null($server) and !is_null(@CheckWatchServer($server)['server'])) {
                    $data = [];
                    $data['name'] = @CheckWatchServer($server)['server'];
                    $data['link'] = @CheckWatchServer($server)['link'];
                    $data['order'] = @CheckWatchServer($server)['order'];
                    $data['icon'] = @CheckWatchServer($server)['ico'];
                    $data['qua'] = @CheckWatchServer($server)['qua'];
                    $servers[] = $data;
                }
            }
        }
    }
    usort($servers, 'cmp');
    return $servers;
}
function CheckDownLoadServer($InputServer) {
    $servers = array(
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'post_type' => 'down_servers',
        'meta_key' => 'server_num',
        'orderby' => 'meta_value',
        'order' => 'ASC',
    );  
    $servers = get_posts($servers);
    foreach($servers as $server){
        $thum = wp_get_attachment_url(get_post_thumbnail_id($server->ID));
        $serverNumber = get_post_meta($server->ID,'server_num',true);
        $serverName = get_the_title($server->ID);   
        $htts = ['http://','https://']; 
        if(strpos($InputServer,strtolower(str_replace($htts,['',''],$serverName)))) {
            return ['order'=>$serverNumber,'ico' => $thum,'server'=>$serverName,'link'=> $InputServer];
        }
    }
}
function GetDownLoadServer($value) {
    $servers = [];
    if (!empty($value)) {
        $value = preg_split('/\r\n|[\r\n]/', $value);
        foreach ($value as $server) {
            if (!is_null($server) and !is_null(@CheckDownLoadServer($server)['server'])) {
                $data = [];
                $data['name'] = @CheckDownLoadServer($server)['server'];
                $data['link'] = @CheckDownLoadServer($server)['link'];
                $data['thum'] = @CheckDownLoadServer($server)['ico'];
                $data['order'] = @CheckDownLoadServer($server)['order'];
                $servers[] = $data;
            }
        }
    }
    usort($servers, 'cmp');
    return $servers;
}
 function cmp($a, $b)
    {
        if ($a["order"] == $b["order"]) {
            return 0;
        }
        return $a["order"] < $b["order"] ? -1 : 1;
    }