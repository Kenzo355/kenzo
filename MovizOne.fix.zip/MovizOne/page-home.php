<?php
(new ThemeContext())->Header();
// Template Name: Home


if (!wp_is_mobile()) {
    $nums = get_option("homeslidenums") != "" ? get_option("homeslidenums") : 10;
    echo "<div class=\"HomeSlider\"> <div class=\"sliderCont\"><span class=\"next\"><i class=\"fal fa-chevron-right\"></i></span><span class=\"prev\"><i class=\"fal fa-chevron-left\"></i></span><ul class=\"SlidesList owl-carousel owl-theme\">";
    foreach (get_posts(["post_type" => "post", "posts_per_page" => $nums, "meta_key" => "pin", "fields" => "ids"]) as $post) {
        (new ThemeContext())->sliderBlock($post);
    }
    wp_reset_query();

}

echo "</div></div><div class=\"Sections\">";
 ?>


<div class="container">
<div class="filterTabs">
<div class="titleArea">
<div class="icon"></div>
<span>المضاف حديثاََ</span>
</div>

<div style="clear: both;"></div>
</div>


	<? 
function ArchivePagination()
{
	if (is_singular()) {
		return NULL;
	}
	global $wp_query;
	if ($wp_query->max_num_pages <= 1) {
		return NULL;
	}
	$paged = get_query_var("paged") ? absint(get_query_var("paged")) : 1;
	$max = intval($wp_query->max_num_pages);
	if (1 <= $paged) {
		$links[] = $paged;
	}
	if (3 <= $paged) {
		$links[] = $paged - 1;
		$links[] = $paged - 2;
	}
	if ($paged + 2 <= $max) {
		$links[] = $paged + 2;
		$links[] = $paged + 1;
	}
	echo "<div class=\"pagination\"><ul>" . "\n";
	if (get_previous_posts_link()) {
		printf("<li class=\"prebtn\">%s</li>" . "\n", get_previous_posts_link());
	}
	if (!in_array(1, $links)) {
		$class = 1 == $paged ? " class=\"active\"" : "";
		printf("<li%s><a href=\"%s\">%s</a></li>" . "\n", $class, esc_url(get_pagenum_link(1)), "1");
		if (!in_array(2, $links)) {
			echo "<li>…</li>";
		}
	}
	sort($links);
	foreach ((array) $links as $link) {
		$class = $paged == $link ? " class=\"active\"" : "";
		printf("<li%s><a href=\"%s\">%s</a></li>" . "\n", $class, esc_url(get_pagenum_link($link)), $link);
	}
	if (!in_array($max, $links)) {
		if (!in_array($max - 1, $links)) {
			echo "<li>…</li>" . "\n";
		}
		$class = $paged == $max ? " class=\"active\"" : "";
		printf("<li%s><a href=\"%s\">%s</a></li>" . "\n", $class, esc_url(get_pagenum_link($max)), $max);
	}
	if (get_next_posts_link()) {
		printf("<li>%s</li>" . "\n", get_next_posts_link());
	}
	echo "</ul></div>" . "\n";

}



?>

		<?
		if ( get_query_var('paged') ) {
			$paged = get_query_var('paged');
		} elseif ( get_query_var('page') ) {
			$paged = get_query_var('page');
		} else {
			$paged = $_GET['page'];
		}
	  $url = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	  $paged = (is_numeric(end(array_filter(explode("/", $url))))) ? end(array_filter(explode("/", $url))) : 1;
		?>
			<? query_posts( array("post_type" => "post", "posts_per_page" => 42, "fields" => "ids", $tax => $slug, "meta_query" => [["key" => "dont_show_home", "value" => "", "compare" => "NOT EXISTS"]], "paged" => $paged ) ); ?>
			<? while ($wp_query->have_posts()) {
               $wp_query->the_post(); ?>
				<?  (new ThemeContext())->sectionBlock($post); ?>
			<? } ?>
		</div>
		<?=ArchivePagination() ?>
	</div>
</section>
<?
(new ThemeContext())->Footer();

?>
