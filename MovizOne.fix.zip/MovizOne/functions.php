<?php

if (get_option("showMeta") != "yes") {
    add_theme_support("title-tag");
}
require get_template_directory() . "/Setup/Core.php";
require get_template_directory() . "/Setup/Context.php";
(new ThemeTree())->Setup();
require get_template_directory() . "/Setup/Servers.php";
add_action("wp_enqueue_scripts", "wpassist_remove_block_library_css");
remove_action("wp_head", "print_emoji_detection_script", 7);
remove_action("wp_print_styles", "print_emoji_styles");
add_action("init", "wpse_318560_en_endpoint");
add_action("admin_init", "redirect_non_admin_user");
add_action("after_setup_theme", "remove_admin_bar");
add_action("wp_logout", "auto_redirect_after_logout");
add_action("template_redirect", "wpse_128636_redirect_post");
add_action("login_head", "customlogincss");
add_action("save_post", "updateTaxonomyTime", 10, 3);
add_action("transition_post_status", function ($new_status, $old_status, $post) {
    if ("publish" == $new_status && "publish" != $old_status && $post->post_type == "post" && get_the_terms($post->ID, "series", "")) {
        $time = get_post_time("U", false, $post_id);
        foreach (get_the_terms($post_id, "series", 1) as $ser) {
            update_term_meta($ser->term_id, "time", $time);
        }
    }
}, 10, 3);
class ThemeTree
{
    private $args = NULL;
    private $_GET = NULL;
    private $_POST = NULL;
    public function __construct($args = [])
    {
        $this->args = $args;
        $this->Method = ["GETs" => $_GET, "POSTs" => $_POST];
    }
    public function PTypesSetup()
    {
        (new ThemeCore())->AddPType("شرائح الرئيسية", "شريحة", "", "sections", true, ["slug" => "filter"], ["title"]);

    }
    public function TaxonomySetup()
    {
        (new ThemeCore())->AddTaxonomy("channel", ["post"], "قنوات المشاهدة", ["slug" => "channel"], true);
        (new ThemeCore())->AddTaxonomy("awards", ["post"], "الجوائز", ["slug" => "awards"], false);
        (new ThemeCore())->AddTaxonomy("release-year", ["post"], "سنة الاصدار", ["slug" => "release-year"], false);
        (new ThemeCore())->AddTaxonomy("quality", ["post"], "الجودة", ["slug" => "quality"], false);
        (new ThemeCore())->AddTaxonomy("nation", ["post"], "الدولة", ["slug" => "nation"], false);
        (new ThemeCore())->AddTaxonomy("language", ["post"], "اللغة", ["slug" => "language"], false);
        (new ThemeCore())->AddTaxonomy("genre", ["post"], "الانواع", ["slug" => "genre"], false);
        (new ThemeCore())->AddTaxonomy("actor", ["post"], "الممثلين", ["slug" => "actor"], false);
        (new ThemeCore())->AddTaxonomy("director", ["post"], "المخرجين", ["slug" => "director"], false);
        (new ThemeCore())->AddTaxonomy("writers", ["post"], "الكاتبين", ["slug" => "writers"], false);
        (new ThemeCore())->AddTaxonomy("movseries", ["post"], "سلاسل الافلام", ["slug" => "movseries"], false);
        (new ThemeCore())->AddTaxonomy("series", ["post"], "المسلسلات", ["slug" => "series"], true);
        (new ThemeCore())->AddTaxonomy("sercat", ["post"], "اقسام المسلسلات", ["slug" => "sercat"], true);
        (new ThemeCore())->AddTaxonomy("mpaa", ["post"], "التصنيف العمري", ["slug" => "mpaa"], false);
    }
    public function widgetsetup()
    {
    }
    public function Setup()
    {
        add_action("init", [$this, "PTypesSetup"]);
        add_action("widgets_init", [$this, "widgetsetup"]);
        add_action("init", [new ThemeCore(), "ThemeSetup"]);
        add_action("init", [$this, "TaxonomySetup"]);
        add_action("pre_get_posts", [new ThemeContext(), "SearchFilter"]);
        add_filter("terms_clauses", [new ThemeContext(), "getActorSearch"], 10, 3);
        add_action("admin_menu", [new ThemeContext(), "addPinPostsPage"]);
        add_action("admin_init", [new ThemeContext(), "addStyleToAdmin"]);
        add_action("show_user_profile", [new ThemeContext(), "extra_user_profile_fields"]);
        add_action("edit_user_profile", [new ThemeContext(), "extra_user_profile_fields"]);
        add_action("personal_options_update", [new ThemeContext(), "save_extra_user_profile_fields"]);
        add_action("edit_user_profile_update", [new ThemeContext(), "save_extra_user_profile_fields"]);
        add_filter("manage_posts_columns", [new ThemeCore(), "PostColumns"]);
        add_action("manage_posts_custom_column", [new ThemeCore(), "PostColumnsContent"], 10, 2);
        add_action("wp_ajax_nopriv_SearchComplete", [new ThemeContext(), "SearchComplete"]);
        add_action("wp_ajax_SearchComplete", [new ThemeContext(), "SearchComplete"]);
        add_action("wp_ajax_nopriv_siteColor", [new ThemeContext(), "siteColor"]);
        add_action("wp_ajax_siteColor", [new ThemeContext(), "siteColor"]);
        add_action("wp_ajax_nopriv_getSeasons", [new ThemeContext(), "getSeasons"]);
        add_action("wp_ajax_getSeasons", [new ThemeContext(), "getSeasons"]);
        add_action("wp_ajax_nopriv_homeFilter", [new ThemeContext(), "homeFilter"]);
        add_action("wp_ajax_homeFilter", [new ThemeContext(), "homeFilter"]);
        add_action("wp_ajax_nopriv_EpisodesList", [new ThemeContext(), "EpisodesList"]);
        add_action("wp_ajax_EpisodesList", [new ThemeContext(), "EpisodesList"]);
        add_action("wp_ajax_nopriv_Espoblock", [new ThemeContext(), "Espoblock"]);
        add_action("wp_ajax_Espoblock", [new ThemeContext(), "Espoblock"]);
        add_action("wp_ajax_nopriv_getServer", [new ThemeContext(), "getServer"]);
        add_action("wp_ajax_getServer", [new ThemeContext(), "getServer"]);
        add_action("wp_ajax_nopriv_getFullWatchServers", [new ThemeContext(), "getFullWatchServers"]);
        add_action("wp_ajax_getFullWatchServers", [new ThemeContext(), "getFullWatchServers"]);
        add_action("wp_ajax_nopriv_GenerateData", [new ThemeContext(), "GenerateData"]);
        add_action("wp_ajax_GenerateData", [new ThemeContext(), "GenerateData"]);
        add_action("wp_ajax_nopriv_loadcomments", [new ThemeContext(), "loadcomments"]);
        add_action("wp_ajax_loadcomments", [new ThemeContext(), "loadcomments"]);
        add_action("wp_ajax_nopriv_infoLoad", [new ThemeContext(), "infoLoad"]);
        add_action("wp_ajax_infoLoad", [new ThemeContext(), "infoLoad"]);
        add_action("wp_ajax_nopriv_subscribe", [new ThemeContext(), "subscribe"]);
        add_action("wp_ajax_subscribe", [new ThemeContext(), "subscribe"]);
        add_action("wp_ajax_nopriv_later", [new ThemeContext(), "later"]);
        add_action("wp_ajax_later", [new ThemeContext(), "later"]);
        add_action("wp_ajax_nopriv_noticeSeen", [new ThemeContext(), "noticeSeen"]);
        add_action("wp_ajax_noticeSeen", [new ThemeContext(), "noticeSeen"]);
        add_action("wp_ajax_nopriv_filterTab", [new ThemeContext(), "filterTab"]);
        add_action("wp_ajax_filterTab", [new ThemeContext(), "filterTab"]);
        add_action("wp_ajax_updatePostDate", [new ThemeContext(), "updatePostDate"]);
        add_action("wp_ajax_getFilmPostInfo", [new ThemeContext(), "getFilmPostInfo"]);
        add_action("wp_ajax_getInfoByID", [new ThemeContext(), "getInfoByID"]);
        add_action("wp_ajax_myAccount", [new ThemeContext(), "myAccount"]);
        add_action("wp_ajax_historySetting", [new ThemeContext(), "historySetting"]);
        add_action("wp_ajax_notestSetting", [new ThemeContext(), "notestSetting"]);
        add_action("wp_ajax_profileSetting", [new ThemeContext(), "profileSetting"]);
        add_action("wp_ajax_uploadImage", [new ThemeContext(), "uploadImage"]);
        add_action("wp_ajax_loginmethod", [new ThemeContext(), "loginmethod"]);
        add_action("wp_ajax_nopriv_loginmethod", [new ThemeContext(), "loginmethod"]);
        add_action("wp_ajax_registermethod", [new ThemeContext(), "registermethod"]);
        add_action("wp_ajax_nopriv_registermethod", [new ThemeContext(), "registermethod"]);
        add_action("wp_ajax_getExploreBlocks", [new ThemeContext(), "getExploreBlocks"]);
        add_action("wp_ajax_nopriv_getExploreBlocks", [new ThemeContext(), "getExploreBlocks"]);
        add_action("wp_ajax_getOptionsSearch", [new ThemeContext(), "getOptionsSearch"]);
        add_action("wp_ajax_nopriv_getOptionsSearch", [new ThemeContext(), "getOptionsSearch"]);
        add_action("wp_ajax_nextPost", [new ThemeContext(), "nextPost"]);
        add_action("wp_ajax_nopriv_nextPost", [new ThemeContext(), "nextPost"]);
        add_action("wp_ajax_followTax", [new ThemeContext(), "followTax"]);
        add_action("wp_ajax_rateFilm", [new ThemeContext(), "rateFilm"]);
        add_action("wp_ajax_nopriv_rateFilm", [new ThemeContext(), "rateFilm"]);
        add_action("wp_ajax_exploreUserData", [new ThemeContext(), "exploreUserData"]);
        add_action("wp_ajax_nopriv_exploreUserData", [new ThemeContext(), "exploreUserData"]);
        add_action("wp_ajax_Reaction", [new ThemeContext(), "Reaction"]);
        add_action("wp_ajax_nopriv_Reaction", [new ThemeContext(), "Reaction"]);
        add_action("wp_ajax_AddComment", [new ThemeContext(), "AddComment"]);
        add_action("wp_ajax_nopriv_AddComment", [new ThemeContext(), "AddComment"]);
        add_action("wp_ajax_gtshrt", [new ThemeContext(), "gtshrt"]);
        add_action("wp_ajax_nopriv_gtshrt", [new ThemeContext(), "gtshrt"]);
        add_action("wp_ajax_getTabsInsSeries", [new ThemeContext(), "getTabsInsSeries"]);
        add_action("wp_ajax_nopriv_getTabsInsSeries", [new ThemeContext(), "getTabsInsSeries"]);
        add_action("wp_ajax_getMoreByScroll", [new ThemeContext(), "getMoreByScroll"]);
        add_action("wp_ajax_nopriv_getMoreByScroll", [new ThemeContext(), "getMoreByScroll"]);
        add_action("wp_ajax_customsssss", [new ThemeContext(), "customsssss"]);
        add_action("wp_ajax_nopriv_customsssss", [new ThemeContext(), "customsssss"]);
        add_action("wp_ajax_load_chat", [new ThemeContext(), "load_chat"]);
        add_action("wp_ajax_nopriv_load_chat", [new ThemeContext(), "load_chat"]);
        add_action("wp_ajax_load_trailer", [new ThemeContext(), "load_trailer"]);
        add_action("wp_ajax_nopriv_load_trailer", [new ThemeContext(), "load_trailer"]);
    }
}
function YCResizeImage($url, $width, $height = NULL, $crop = NULL, $single = true)
{
    if (!empty($url)) {
        if (!$url || !$width) {
            return false;
        }
        $upload_info = wp_upload_dir();
        $upload_dir = $upload_info["basedir"];
        $upload_url = $upload_info["baseurl"];
        if (strpos($url, $upload_url) === false) {
            return false;
        }
        $rel_path = str_replace($upload_url, "", $url);
        $img_path = $upload_dir . $rel_path;
        if (!file_exists($img_path) || !getimagesize($img_path)) {
            return false;
        }
        $info = pathinfo($img_path);
        $ext = $info["extension"];
        list($orig_w, $orig_h) = getimagesize($img_path);
        $dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
        list($dst_w, $dst_h) = $dims;
        $suffix = $dst_w . "x" . $dst_h;
        $dst_rel_path = str_replace("." . $ext, "", $rel_path);
        $destfilename = $upload_dir . $dst_rel_path . "-" . $suffix . "." . $ext;
        if (!$dst_h) {
            $img_url = $url;
            $dst_w = $orig_w;
            $dst_h = $orig_h;
        } else {
            if (file_exists($destfilename) && getimagesize($destfilename)) {
                $img_url = $upload_url . $dst_rel_path . "-" . $suffix . "." . $ext;
            } else {
                if (function_exists("wp_get_image_editor")) {
                    $editor = wp_get_image_editor($img_path);
                    if (is_wp_error($editor) || is_wp_error($editor->resize($width, $height, $crop))) {
                        return false;
                    }
                    $resized_file = $editor->save();
                    if (!is_wp_error($resized_file)) {
                        $resized_rel_path = str_replace($upload_dir, "", $resized_file["path"]);
                        $img_url = $upload_url . $resized_rel_path;
                    } else {
                        return false;
                    }
                } else {
                    $resized_img_path = image_resize($img_path, $width, $height, $crop);
                    if (!is_wp_error($resized_img_path)) {
                        $resized_rel_path = str_replace($upload_dir, "", $resized_img_path);
                        $img_url = $upload_url . $resized_rel_path;
                    } else {
                        return false;
                    }
                }
            }
        }
        if ($single) {
            $image = $img_url;
        } else {
            $image = [$img_url, $dst_w, $dst_h];
        }
    } else {
        $image = get_template_directory_uri() . "/Inc/img/no-image.png";
    }
    return $image;
}
function wpassist_remove_block_library_css()
{
    wp_dequeue_style("wp-block-library");
}
function wpse_318560_en_endpoint()
{
    add_rewrite_endpoint("watch", EP_ALL);
    add_rewrite_endpoint("searchcenter", EP_ALL);
    add_rewrite_endpoint("page", EP_ALL);
    add_rewrite_endpoint("advcat", EP_ALL);
    add_rewrite_endpoint("advyear", EP_ALL);
    add_rewrite_endpoint("advquality", EP_ALL);
    add_rewrite_endpoint("advnation", EP_ALL);
    add_rewrite_endpoint("advgenre", EP_ALL);
    add_rewrite_endpoint("advmpaa", EP_ALL);
}
function redirect_non_admin_user()
{
    if (!defined("DOING_AJAX") && !current_user_can("administrator")) {
        wp_redirect(site_url());
        exit;
    }
}
function remove_admin_bar()
{
    if (!(current_user_can("administrator") || current_user_can("uploader"))) {
        show_admin_bar(false);
    }
}
function auto_redirect_after_logout()
{
    wp_safe_redirect(home_url());
    exit;
}
function wpse_128636_redirect_post()
{
    if (is_singular("breaks")) {
        wp_redirect(home_url(), 301);
        exit;
    }
}
function ISPageSpeed()
{
    if (strpos($_SERVER["HTTP_USER_AGENT"], "Lighthouse") !== false) {
        $return = true;
    } else {
        $return = false;
    }
    return $return;
}
function customlogincss()
{
    echo "<link href=\"" . get_template_directory_uri() . "/Standard/UI/css/login.css\" rel=\"stylesheet\">";
}
function updateTaxonomyTime($post_id, $post, $update)
{
    if (get_the_terms($post_id, "series", 1)) {
        $time = get_post_time("U", false, $post_id);
        foreach (get_the_terms($post_id, "series", 1) as $ser) {
            update_term_meta($ser->term_id, "time", $time);
        }
    }
}



function MediaUploader($value='')
{
  wp_enqueue_media();
  ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
  <script type="text/javascript">''
    jQuery(document).ready(function($) {
      $(".cmb-row.cmb-type-text.cmb2-id-imdbID.table-layout .cmb-td").append('<button id="getFromIMDB" type="button" class="button green">سحب البيانات</button>');
      $(".cmb-row.cmb-type-text.cmb2-id-ElcinemaIDTXT.table-layout .cmb-td").append('<button id="getFromElcinema" type="button" class="button green">سحب البيانات</button>');
      $("#getFromElcinema").click(function(){
        $.ajax({
          url: '<?=str_replace('http://', 'https://', STANDARD_URL) ?>APIs/ElCinema.php',
          type:'GET',
          async:true,
          data:'id='+$("#ElcinemaIDTXT").val()+'&pid='+$('#post_ID').val(),
          success: function(msg) {
            $('body').append(msg);
          },
          error: function(){
          }
        });
      });
      $('#getFromIMDB').click(function(){
        $.ajax({
          url: '<?=str_replace('http://', 'https://', STANDARD_URL) ?>APIs/IMDB.php',
          type:'GET',
          async:true,
          data:'id='+$("#imdbID").val()+'&pid='+$('#post_ID').val(),
          success: function(msg) {
            $('body').append(msg);
          },
          error: function(){
          }
        });
      });
    });
  </script>
  <style type="text/css">
    @import url(https://fonts.googleapis.com/css?family=Changa:400,700,800);
    .cmb-row.cmb-type-text.cmb2-id-ElcinemaIDTXT.table-layout input#ElcinemaIDTXT,.cmb-row.cmb-type-text.cmb2-id-imdbID.table-layout input#imdbID{width:calc(100% - 190px)}button.button.green{margin:0!important;width:180px!important;height:40px!important;font-family:Changa!important;padding:0 10px!important;margin-right:10px!important;font-weight:700!important;color:#3c3c3c!important;background:#e8e8e8!important;border:0!important}a.toplevel_page_kenzoPanel.menu-top-first.menu-top-last{background:#ec1f1f!important;font-family:Changa;font-weight:700!important}#toplevel_page_kenzoPanel.wp-menu-open>ul>li>a{border-bottom:1px solid #40464c;font-family:Changa;padding:9px 12px!important;color:#b8bdc3!important}#toplevel_page_kenzoPanel.wp-menu-open>ul>li:last-child a{border:0!important}#toplevel_page_kenzoPanel.wp-menu-open>ul>li>a.current,#toplevel_page_kenzoPanel.wp-menu-open>ul>li>a:hover{color:#fff!important}.postbox.cmb2-postbox{font-family:Changa;position:relative}.postbox.cmb2-postbox h2.hndle.ui-sortable-handle{font-family:Changa;background:linear-gradient(to left,rgb(27 177 0 / 34%),rgba(26,119,244,0));padding:14px!important;font-family:Changa;color:#2e4f7b;border-color:rgba(0,0,0,.1)!important}.postbox.cmb2-postbox button.handlediv{top:8px;position:relative;left:7px}.postbox.cmb2-postbox .cmb-th{display:block;float:right;width:20%;height:40px;font-family:Changa;text-align:right;line-height:40px;font-size:15px;font-weight:700;color:#545658;margin-left:0!important;padding-left:0!important}.postbox.cmb2-postbox .inside *{position:relative}.postbox.cmb2-postbox .inside{padding:0 20px}.postbox.cmb2-postbox .cmb2-metabox.cmb-field-list>div{padding:0 0;margin:10px 0;border:0}.postbox.cmb2-postbox .inside .cmb-td input:not([type=checkbox]),.postbox.cmb2-postbox .inside .cmb-td select,.postbox.cmb2-postbox .inside .cmb-td textarea{margin:0;width:100%;height:40px;font-family:Changa;padding:0 10px;border:1px solid #ddd}.postbox.cmb2-postbox .inside .cmb-td textarea{height:150px;max-height:200px}.cmb-th label{padding:0}.postbox.cmb2-postbox .inside .cmb-td .cmb2-upload-file{width:calc(100% - 170px)!important}.postbox.cmb2-postbox .inside .cmb-td .cmb2-upload-button{float:left!important;width:160px!important;font-weight:700;color:#525252!important}.postbox.cmb2-postbox .inside .cmb-td p.cmb2-metabox-description{display:block;width:100%;font-size:12px;font-style:normal;font-weight:700}
    h3.cmb-group-title.cmbhandle-title {
      font-family: Changa !important;
      background: #f1f1f1;
    }
    button.cmb-remove-group-row.cmb-remove-group-row-button.alignright.button-secondary {
      font-family: Changa;
      font-weight: bold;
      border: 0;
      background: #f1f1f1;
      color: #222;
      border: 1px solid #DDD;
      padding: 5px 30px;
    }
    .cmb-row.cmb-remove-field-row {
      padding: 0;
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" integrity="sha256-FdatTf20PQr/rWg+cAKfl6j4/IY3oohFAJ7gVC3M34E=" crossorigin="anonymous" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
    $("#parent").select2();

    });
  </script>
  <?php
}
add_action('admin_enqueue_scripts','MediaUploader');
flush_rewrite_rules( true );

function extLinkOn() {
extLinks("_blank");
}

?>
