<?
(new ThemeContext())->Header();
 // Template Name: Series ?>
 <?
 


 echo "\n";
 wp_reset_query();
 echo "<div class=\"archiveTitle\">\n    <h1 class=\"title\">";
 the_title();
 echo "</div></div><div class=\"Sections\">";

 
 
function ArchivePagination()
{
	if (is_singular()) {
		return NULL;
	}
	global $wp_query;
	if ($wp_query->max_num_pages <= 1) {
		return NULL;
	}
	$paged = get_query_var("paged") ? absint(get_query_var("paged")) : 1;
	$max = intval($wp_query->max_num_pages);
	if (1 <= $paged) {
		$links[] = $paged;
	}
	if (3 <= $paged) {
		$links[] = $paged - 1;
		$links[] = $paged - 2;
	}
	if ($paged + 2 <= $max) {
		$links[] = $paged + 2;
		$links[] = $paged + 1;
	}
	echo "<div class=\"pagination\"><ul>" . "\n";
	if (get_previous_posts_link()) {
		printf("<li class=\"prebtn\">%s</li>" . "\n", get_previous_posts_link());
	}
	if (!in_array(1, $links)) {
		$class = 1 == $paged ? " class=\"active\"" : "";
		printf("<li%s><a href=\"%s\">%s</a></li>" . "\n", $class, esc_url(get_pagenum_link(1)), "1");
		if (!in_array(2, $links)) {
			echo "<li>…</li>";
		}
	}
	sort($links);
	foreach ((array) $links as $link) {
		$class = $paged == $link ? " class=\"active\"" : "";
		printf("<li%s><a href=\"%s\">%s</a></li>" . "\n", $class, esc_url(get_pagenum_link($link)), $link);
	}
	if (!in_array($max, $links)) {
		if (!in_array($max - 1, $links)) {
			echo "<li>…</li>" . "\n";
		}
		$class = $paged == $max ? " class=\"active\"" : "";
		printf("<li%s><a href=\"%s\">%s</a></li>" . "\n", $class, esc_url(get_pagenum_link($max)), $max);
	}
	if (get_next_posts_link()) {
		printf("<li>%s</li>" . "\n", get_next_posts_link());
	}
	echo "</ul></div>" . "\n";

}

	  $url = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	  $paged = (is_numeric(end(array_filter(explode("/", $url))))) ? end(array_filter(explode("/", $url))) : 1;
		$allSeries = get_terms(array("taxonomy" => "series" , "hide_empty" => true , "parent" => 0));
		$allSeries = array_chunk($allSeries, 40);
		?>
		<? $pag = (empty($paged) || $paged == 0) ? 1 : $paged; $pag = $pag -1; ?>
		<? foreach ($allSeries[$pag] as $series) { ?>
			<? $post = get_posts(array("post_type" => "post" , "series" => $series->slug , "posts_per_page" => 1))[0]; ?>
			<? $post  = get_post($post->ID); ?>
		<?	echo "<div class=\"MovieItem\">";
                echo "<a  href=\"" . get_term_link($series) . "\">";


        echo "<img data-src=\"" . get_the_post_thumbnail_url($post, "mysize") . "\">"; ?>
     			<div class="TitleBlock">
						<h4><?= $series->name  ?></h4>
		</div>
	</a>
</div>
		<? } ?>



</div>




		 <div class="ArchivePagination"> 
	<?	$prev_arrow = is_rtl() ? '→' : '←';
		$next_arrow = is_rtl() ? '←' : '→';
		global $wp_query, $wp_rewrite;
		$pag = (empty($paged) || $paged == 0) ? 1 : $paged; $pag = $pag -1;
		$ArchivePagination = array(
			'base' => @add_query_arg('paged','%#%'),
			'format' => '',
			'total' => count($allSeries),
			'current' => (empty($paged)) ? 1 : $paged,
			'show_all' => false,
			'type' => 'list',
    
		);
		echo paginate_links( $ArchivePagination );
		
?>
</div>

	<?

(new ThemeContext())->Footer();

?>

